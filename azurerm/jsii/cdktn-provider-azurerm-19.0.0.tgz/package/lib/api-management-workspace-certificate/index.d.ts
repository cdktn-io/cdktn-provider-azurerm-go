/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiManagementWorkspaceCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#api_management_workspace_id ApiManagementWorkspaceCertificate#api_management_workspace_id}
    */
    readonly apiManagementWorkspaceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#certificate_data_base64 ApiManagementWorkspaceCertificate#certificate_data_base64}
    */
    readonly certificateDataBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#id ApiManagementWorkspaceCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#key_vault_secret_id ApiManagementWorkspaceCertificate#key_vault_secret_id}
    */
    readonly keyVaultSecretId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#name ApiManagementWorkspaceCertificate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#password ApiManagementWorkspaceCertificate#password}
    */
    readonly password?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#user_assigned_identity_client_id ApiManagementWorkspaceCertificate#user_assigned_identity_client_id}
    */
    readonly userAssignedIdentityClientId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#timeouts ApiManagementWorkspaceCertificate#timeouts}
    */
    readonly timeouts?: ApiManagementWorkspaceCertificateTimeouts;
}
export interface ApiManagementWorkspaceCertificateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#create ApiManagementWorkspaceCertificate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#delete ApiManagementWorkspaceCertificate#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#read ApiManagementWorkspaceCertificate#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#update ApiManagementWorkspaceCertificate#update}
    */
    readonly update?: string;
}
export declare function apiManagementWorkspaceCertificateTimeoutsToTerraform(struct?: ApiManagementWorkspaceCertificateTimeouts | cdktn.IResolvable): any;
export declare function apiManagementWorkspaceCertificateTimeoutsToHclTerraform(struct?: ApiManagementWorkspaceCertificateTimeouts | cdktn.IResolvable): any;
export declare class ApiManagementWorkspaceCertificateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementWorkspaceCertificateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementWorkspaceCertificateTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate azurerm_api_management_workspace_certificate}
*/
export declare class ApiManagementWorkspaceCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_api_management_workspace_certificate";
    /**
    * Generates CDKTN code for importing a ApiManagementWorkspaceCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiManagementWorkspaceCertificate to import
    * @param importFromId The id of the existing ApiManagementWorkspaceCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiManagementWorkspaceCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_certificate azurerm_api_management_workspace_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiManagementWorkspaceCertificateConfig
    */
    constructor(scope: Construct, id: string, config: ApiManagementWorkspaceCertificateConfig);
    private _apiManagementWorkspaceId?;
    get apiManagementWorkspaceId(): string;
    set apiManagementWorkspaceId(value: string);
    get apiManagementWorkspaceIdInput(): string | undefined;
    private _certificateDataBase64?;
    get certificateDataBase64(): string;
    set certificateDataBase64(value: string);
    resetCertificateDataBase64(): void;
    get certificateDataBase64Input(): string | undefined;
    get expiration(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyVaultSecretId?;
    get keyVaultSecretId(): string;
    set keyVaultSecretId(value: string);
    resetKeyVaultSecretId(): void;
    get keyVaultSecretIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    get subject(): string;
    get thumbprint(): string;
    private _userAssignedIdentityClientId?;
    get userAssignedIdentityClientId(): string;
    set userAssignedIdentityClientId(value: string);
    resetUserAssignedIdentityClientId(): void;
    get userAssignedIdentityClientIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApiManagementWorkspaceCertificateTimeoutsOutputReference;
    putTimeouts(value: ApiManagementWorkspaceCertificateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApiManagementWorkspaceCertificateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
