/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermManagedRedisConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/managed_redis#id DataAzurermManagedRedis#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/managed_redis#name DataAzurermManagedRedis#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/managed_redis#resource_group_name DataAzurermManagedRedis#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/managed_redis#timeouts DataAzurermManagedRedis#timeouts}
    */
    readonly timeouts?: DataAzurermManagedRedisTimeouts;
}
export interface DataAzurermManagedRedisCustomerManagedKey {
}
export declare function dataAzurermManagedRedisCustomerManagedKeyToTerraform(struct?: DataAzurermManagedRedisCustomerManagedKey): any;
export declare function dataAzurermManagedRedisCustomerManagedKeyToHclTerraform(struct?: DataAzurermManagedRedisCustomerManagedKey): any;
export declare class DataAzurermManagedRedisCustomerManagedKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedRedisCustomerManagedKey | undefined;
    set internalValue(value: DataAzurermManagedRedisCustomerManagedKey | undefined);
    get keyVaultKeyId(): string;
    get userAssignedIdentityId(): string;
}
export declare class DataAzurermManagedRedisCustomerManagedKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedRedisCustomerManagedKeyOutputReference;
}
export interface DataAzurermManagedRedisDefaultDatabaseModule {
}
export declare function dataAzurermManagedRedisDefaultDatabaseModuleToTerraform(struct?: DataAzurermManagedRedisDefaultDatabaseModule): any;
export declare function dataAzurermManagedRedisDefaultDatabaseModuleToHclTerraform(struct?: DataAzurermManagedRedisDefaultDatabaseModule): any;
export declare class DataAzurermManagedRedisDefaultDatabaseModuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedRedisDefaultDatabaseModule | undefined;
    set internalValue(value: DataAzurermManagedRedisDefaultDatabaseModule | undefined);
    get args(): string;
    get name(): string;
    get version(): string;
}
export declare class DataAzurermManagedRedisDefaultDatabaseModuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedRedisDefaultDatabaseModuleOutputReference;
}
export interface DataAzurermManagedRedisDefaultDatabase {
}
export declare function dataAzurermManagedRedisDefaultDatabaseToTerraform(struct?: DataAzurermManagedRedisDefaultDatabase): any;
export declare function dataAzurermManagedRedisDefaultDatabaseToHclTerraform(struct?: DataAzurermManagedRedisDefaultDatabase): any;
export declare class DataAzurermManagedRedisDefaultDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedRedisDefaultDatabase | undefined;
    set internalValue(value: DataAzurermManagedRedisDefaultDatabase | undefined);
    get accessKeysAuthenticationEnabled(): cdktn.IResolvable;
    get clientProtocol(): string;
    get clusteringPolicy(): string;
    get evictionPolicy(): string;
    get geoReplicationGroupName(): string;
    get geoReplicationLinkedDatabaseIds(): string[];
    get id(): string;
    private _module;
    get module(): DataAzurermManagedRedisDefaultDatabaseModuleList;
    get persistenceAppendOnlyFileBackupFrequency(): string;
    get persistenceRedisDatabaseBackupFrequency(): string;
    get port(): number;
    get primaryAccessKey(): string;
    get secondaryAccessKey(): string;
}
export declare class DataAzurermManagedRedisDefaultDatabaseList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedRedisDefaultDatabaseOutputReference;
}
export interface DataAzurermManagedRedisIdentity {
}
export declare function dataAzurermManagedRedisIdentityToTerraform(struct?: DataAzurermManagedRedisIdentity): any;
export declare function dataAzurermManagedRedisIdentityToHclTerraform(struct?: DataAzurermManagedRedisIdentity): any;
export declare class DataAzurermManagedRedisIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedRedisIdentity | undefined;
    set internalValue(value: DataAzurermManagedRedisIdentity | undefined);
    get identityIds(): string[];
    get principalId(): string;
    get tenantId(): string;
    get type(): string;
}
export declare class DataAzurermManagedRedisIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedRedisIdentityOutputReference;
}
export interface DataAzurermManagedRedisTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/managed_redis#read DataAzurermManagedRedis#read}
    */
    readonly read?: string;
}
export declare function dataAzurermManagedRedisTimeoutsToTerraform(struct?: DataAzurermManagedRedisTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermManagedRedisTimeoutsToHclTerraform(struct?: DataAzurermManagedRedisTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermManagedRedisTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermManagedRedisTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermManagedRedisTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/managed_redis azurerm_managed_redis}
*/
export declare class DataAzurermManagedRedis extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_managed_redis";
    /**
    * Generates CDKTN code for importing a DataAzurermManagedRedis resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermManagedRedis to import
    * @param importFromId The id of the existing DataAzurermManagedRedis that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/managed_redis#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermManagedRedis to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/managed_redis azurerm_managed_redis} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermManagedRedisConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermManagedRedisConfig);
    private _customerManagedKey;
    get customerManagedKey(): DataAzurermManagedRedisCustomerManagedKeyList;
    private _defaultDatabase;
    get defaultDatabase(): DataAzurermManagedRedisDefaultDatabaseList;
    get highAvailabilityEnabled(): cdktn.IResolvable;
    get hostname(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): DataAzurermManagedRedisIdentityList;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get publicNetworkAccess(): string;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    get skuName(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): DataAzurermManagedRedisTimeoutsOutputReference;
    putTimeouts(value: DataAzurermManagedRedisTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermManagedRedisTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
