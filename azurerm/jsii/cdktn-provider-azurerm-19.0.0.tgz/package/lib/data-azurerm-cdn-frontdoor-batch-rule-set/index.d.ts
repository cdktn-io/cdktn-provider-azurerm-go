/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermCdnFrontdoorBatchRuleSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_batch_rule_set#id DataAzurermCdnFrontdoorBatchRuleSet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_batch_rule_set#name DataAzurermCdnFrontdoorBatchRuleSet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_batch_rule_set#profile_name DataAzurermCdnFrontdoorBatchRuleSet#profile_name}
    */
    readonly profileName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_batch_rule_set#resource_group_name DataAzurermCdnFrontdoorBatchRuleSet#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_batch_rule_set#timeouts DataAzurermCdnFrontdoorBatchRuleSet#timeouts}
    */
    readonly timeouts?: DataAzurermCdnFrontdoorBatchRuleSetTimeouts;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeader {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeaderToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeader): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeaderToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeader): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeader | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeader | undefined);
    get headerName(): string;
    get headerValue(): string;
    get operator(): string;
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeaderOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeader {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeaderToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeader): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeaderToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeader): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeader | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeader | undefined);
    get headerName(): string;
    get headerValue(): string;
    get operator(): string;
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeaderOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCaching {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCachingToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCaching): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCachingToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCaching): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCachingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCaching | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCaching | undefined);
    get behaviour(): string;
    get compressionEnabled(): cdktn.IResolvable;
    get duration(): string;
    get queryStringBehaviour(): string;
    get queryStringParameters(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCachingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCachingOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroup {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroupToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroup): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroupToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroup): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroup | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroup | undefined);
    get cdnFrontdoorOriginGroupId(): string;
    get forwardingProtocol(): string;
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroupList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroupOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverride {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverride): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverride): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverride | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverride | undefined);
    private _caching;
    get caching(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideCachingList;
    private _originGroup;
    get originGroup(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOriginGroupList;
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirect {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirectToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirect): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirectToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirect): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirect | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirect | undefined);
    get destinationFragment(): string;
    get destinationHostName(): string;
    get destinationPath(): string;
    get queryString(): string;
    get redirectProtocol(): string;
    get redirectType(): string;
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirectList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirectOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewrite {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewriteToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewrite): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewriteToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewrite): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewriteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewrite | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewrite | undefined);
    get destinationPath(): string;
    get preserveUnmatchedPathEnabled(): cdktn.IResolvable;
    get sourcePattern(): string;
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewriteList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewriteOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesActions {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActions): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesActionsToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesActions): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesActions | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesActions | undefined);
    private _modifyRequestHeader;
    get modifyRequestHeader(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyRequestHeaderList;
    private _modifyResponseHeader;
    get modifyResponseHeader(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsModifyResponseHeaderList;
    private _routeConfigurationOverride;
    get routeConfigurationOverride(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsRouteConfigurationOverrideList;
    private _urlRedirect;
    get urlRedirect(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRedirectList;
    private _urlRewrite;
    get urlRewrite(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsUrlRewriteList;
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesActionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPort {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPortToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPort): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPortToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPort): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPort | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPort | undefined);
    get operator(): string;
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPortList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPortOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceType {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceTypeToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceType): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceTypeToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceType): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceType | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceType | undefined);
    get operator(): string;
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceTypeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceTypeOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostName {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostNameToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostName): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostNameToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostName): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostName | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostName | undefined);
    get operator(): string;
    get transforms(): string[];
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostNameList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostNameOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersion {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersionToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersion): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersionToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersion): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersion | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersion | undefined);
    get operator(): string;
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersionOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgument {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgumentToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgument): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgumentToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgument): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgumentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgument | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgument | undefined);
    get name(): string;
    get operator(): string;
    get transforms(): string[];
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgumentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgumentOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryString {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryStringToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryString): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryStringToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryString): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryString | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryString | undefined);
    get operator(): string;
    get transforms(): string[];
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryStringList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryStringOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddress {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddressToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddress): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddressToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddress): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddress | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddress | undefined);
    get operator(): string;
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddressOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBody {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBodyToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBody): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBodyToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBody): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBodyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBody | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBody | undefined);
    get operator(): string;
    get transforms(): string[];
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBodyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBodyOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookies {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookiesToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookies): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookiesToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookies): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookies | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookies | undefined);
    get name(): string;
    get operator(): string;
    get transforms(): string[];
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookiesOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtension {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtensionToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtension): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtensionToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtension): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtensionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtension | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtension | undefined);
    get operator(): string;
    get transforms(): string[];
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtensionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtensionOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilename {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilenameToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilename): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilenameToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilename): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilenameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilename | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilename | undefined);
    get operator(): string;
    get transforms(): string[];
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilenameList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilenameOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeader {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeaderToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeader): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeaderToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeader): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeader | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeader | undefined);
    get name(): string;
    get operator(): string;
    get transforms(): string[];
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeaderOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethod {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethodToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethod): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethodToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethod): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethod | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethod | undefined);
    get operator(): string;
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethodList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethodOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPath {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPathToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPath): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPathToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPath): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPath | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPath | undefined);
    get operator(): string;
    get transforms(): string[];
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPathList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPathOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestScheme {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestSchemeToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestScheme): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestSchemeToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestScheme): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestSchemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestScheme | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestScheme | undefined);
    get operator(): string;
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestSchemeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestSchemeOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrl {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrlToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrl): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrlToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrl): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrl | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrl | undefined);
    get operator(): string;
    get transforms(): string[];
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrlOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPort {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPortToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPort): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPortToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPort): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPort | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPort | undefined);
    get operator(): string;
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPortList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPortOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddress {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddressToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddress): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddressToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddress): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddress | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddress | undefined);
    get operator(): string;
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddressOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocol {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocolToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocol): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocolToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocol): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocol | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocol | undefined);
    get operator(): string;
    get values(): string[];
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocolList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocolOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRulesConditions {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditions): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesConditionsToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRulesConditions): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditions | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRulesConditions | undefined);
    private _clientPort;
    get clientPort(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsClientPortList;
    private _deviceType;
    get deviceType(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsDeviceTypeList;
    private _hostName;
    get hostName(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHostNameList;
    private _httpVersion;
    get httpVersion(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsHttpVersionList;
    private _postArgument;
    get postArgument(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsPostArgumentList;
    private _queryString;
    get queryString(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsQueryStringList;
    private _remoteAddress;
    get remoteAddress(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRemoteAddressList;
    private _requestBody;
    get requestBody(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestBodyList;
    private _requestCookies;
    get requestCookies(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestCookiesList;
    private _requestFileExtension;
    get requestFileExtension(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFileExtensionList;
    private _requestFilename;
    get requestFilename(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestFilenameList;
    private _requestHeader;
    get requestHeader(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestHeaderList;
    private _requestMethod;
    get requestMethod(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestMethodList;
    private _requestPath;
    get requestPath(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestPathList;
    private _requestScheme;
    get requestScheme(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestSchemeList;
    private _requestUrl;
    get requestUrl(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsRequestUrlList;
    private _serverPort;
    get serverPort(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsServerPortList;
    private _socketAddress;
    get socketAddress(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSocketAddressList;
    private _sslProtocol;
    get sslProtocol(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsSslProtocolList;
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetRules {
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRules): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetRulesToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetRules): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetRules | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetRules | undefined);
    private _actions;
    get actions(): DataAzurermCdnFrontdoorBatchRuleSetRulesActionsList;
    get behaviourOnMatch(): string;
    private _conditions;
    get conditions(): DataAzurermCdnFrontdoorBatchRuleSetRulesConditionsList;
    get name(): string;
    get order(): number;
}
export declare class DataAzurermCdnFrontdoorBatchRuleSetRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorBatchRuleSetRulesOutputReference;
}
export interface DataAzurermCdnFrontdoorBatchRuleSetTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_batch_rule_set#read DataAzurermCdnFrontdoorBatchRuleSet#read}
    */
    readonly read?: string;
}
export declare function dataAzurermCdnFrontdoorBatchRuleSetTimeoutsToTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermCdnFrontdoorBatchRuleSetTimeoutsToHclTerraform(struct?: DataAzurermCdnFrontdoorBatchRuleSetTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermCdnFrontdoorBatchRuleSetTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermCdnFrontdoorBatchRuleSetTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorBatchRuleSetTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_batch_rule_set azurerm_cdn_frontdoor_batch_rule_set}
*/
export declare class DataAzurermCdnFrontdoorBatchRuleSet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_cdn_frontdoor_batch_rule_set";
    /**
    * Generates CDKTN code for importing a DataAzurermCdnFrontdoorBatchRuleSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermCdnFrontdoorBatchRuleSet to import
    * @param importFromId The id of the existing DataAzurermCdnFrontdoorBatchRuleSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_batch_rule_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermCdnFrontdoorBatchRuleSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_batch_rule_set azurerm_cdn_frontdoor_batch_rule_set} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermCdnFrontdoorBatchRuleSetConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermCdnFrontdoorBatchRuleSetConfig);
    get cdnFrontdoorProfileId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _profileName?;
    get profileName(): string;
    set profileName(value: string);
    get profileNameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _rules;
    get rules(): DataAzurermCdnFrontdoorBatchRuleSetRulesList;
    private _timeouts;
    get timeouts(): DataAzurermCdnFrontdoorBatchRuleSetTimeoutsOutputReference;
    putTimeouts(value: DataAzurermCdnFrontdoorBatchRuleSetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermCdnFrontdoorBatchRuleSetTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
