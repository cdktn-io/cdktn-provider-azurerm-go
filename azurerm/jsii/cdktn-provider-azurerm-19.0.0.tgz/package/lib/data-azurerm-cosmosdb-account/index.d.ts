/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermCosmosdbAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cosmosdb_account#id DataAzurermCosmosdbAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cosmosdb_account#name DataAzurermCosmosdbAccount#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cosmosdb_account#resource_group_name DataAzurermCosmosdbAccount#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cosmosdb_account#timeouts DataAzurermCosmosdbAccount#timeouts}
    */
    readonly timeouts?: DataAzurermCosmosdbAccountTimeouts;
}
export interface DataAzurermCosmosdbAccountCapabilities {
}
export declare function dataAzurermCosmosdbAccountCapabilitiesToTerraform(struct?: DataAzurermCosmosdbAccountCapabilities): any;
export declare function dataAzurermCosmosdbAccountCapabilitiesToHclTerraform(struct?: DataAzurermCosmosdbAccountCapabilities): any;
export declare class DataAzurermCosmosdbAccountCapabilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCosmosdbAccountCapabilities | undefined;
    set internalValue(value: DataAzurermCosmosdbAccountCapabilities | undefined);
    get name(): string;
}
export declare class DataAzurermCosmosdbAccountCapabilitiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCosmosdbAccountCapabilitiesOutputReference;
}
export interface DataAzurermCosmosdbAccountConsistencyPolicy {
}
export declare function dataAzurermCosmosdbAccountConsistencyPolicyToTerraform(struct?: DataAzurermCosmosdbAccountConsistencyPolicy): any;
export declare function dataAzurermCosmosdbAccountConsistencyPolicyToHclTerraform(struct?: DataAzurermCosmosdbAccountConsistencyPolicy): any;
export declare class DataAzurermCosmosdbAccountConsistencyPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCosmosdbAccountConsistencyPolicy | undefined;
    set internalValue(value: DataAzurermCosmosdbAccountConsistencyPolicy | undefined);
    get consistencyLevel(): string;
    get maxIntervalInSeconds(): number;
    get maxStalenessPrefix(): number;
}
export declare class DataAzurermCosmosdbAccountConsistencyPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCosmosdbAccountConsistencyPolicyOutputReference;
}
export interface DataAzurermCosmosdbAccountGeoLocation {
}
export declare function dataAzurermCosmosdbAccountGeoLocationToTerraform(struct?: DataAzurermCosmosdbAccountGeoLocation): any;
export declare function dataAzurermCosmosdbAccountGeoLocationToHclTerraform(struct?: DataAzurermCosmosdbAccountGeoLocation): any;
export declare class DataAzurermCosmosdbAccountGeoLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCosmosdbAccountGeoLocation | undefined;
    set internalValue(value: DataAzurermCosmosdbAccountGeoLocation | undefined);
    get failoverPriority(): number;
    get id(): string;
    get location(): string;
}
export declare class DataAzurermCosmosdbAccountGeoLocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCosmosdbAccountGeoLocationOutputReference;
}
export interface DataAzurermCosmosdbAccountVirtualNetworkRule {
}
export declare function dataAzurermCosmosdbAccountVirtualNetworkRuleToTerraform(struct?: DataAzurermCosmosdbAccountVirtualNetworkRule): any;
export declare function dataAzurermCosmosdbAccountVirtualNetworkRuleToHclTerraform(struct?: DataAzurermCosmosdbAccountVirtualNetworkRule): any;
export declare class DataAzurermCosmosdbAccountVirtualNetworkRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCosmosdbAccountVirtualNetworkRule | undefined;
    set internalValue(value: DataAzurermCosmosdbAccountVirtualNetworkRule | undefined);
    get id(): string;
}
export declare class DataAzurermCosmosdbAccountVirtualNetworkRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCosmosdbAccountVirtualNetworkRuleOutputReference;
}
export interface DataAzurermCosmosdbAccountTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cosmosdb_account#read DataAzurermCosmosdbAccount#read}
    */
    readonly read?: string;
}
export declare function dataAzurermCosmosdbAccountTimeoutsToTerraform(struct?: DataAzurermCosmosdbAccountTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermCosmosdbAccountTimeoutsToHclTerraform(struct?: DataAzurermCosmosdbAccountTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermCosmosdbAccountTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermCosmosdbAccountTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermCosmosdbAccountTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cosmosdb_account azurerm_cosmosdb_account}
*/
export declare class DataAzurermCosmosdbAccount extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_cosmosdb_account";
    /**
    * Generates CDKTN code for importing a DataAzurermCosmosdbAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermCosmosdbAccount to import
    * @param importFromId The id of the existing DataAzurermCosmosdbAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cosmosdb_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermCosmosdbAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cosmosdb_account azurerm_cosmosdb_account} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermCosmosdbAccountConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermCosmosdbAccountConfig);
    get automaticFailoverEnabled(): cdktn.IResolvable;
    private _capabilities;
    get capabilities(): DataAzurermCosmosdbAccountCapabilitiesList;
    private _consistencyPolicy;
    get consistencyPolicy(): DataAzurermCosmosdbAccountConsistencyPolicyList;
    get endpoint(): string;
    get freeTierEnabled(): cdktn.IResolvable;
    private _geoLocation;
    get geoLocation(): DataAzurermCosmosdbAccountGeoLocationList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipRangeFilter(): string[];
    get isVirtualNetworkFilterEnabled(): cdktn.IResolvable;
    get keyVaultKeyId(): string;
    get kind(): string;
    get location(): string;
    get multipleWriteLocationsEnabled(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get offerType(): string;
    get primaryKey(): string;
    get primaryMongodbConnectionString(): string;
    get primaryReadonlyKey(): string;
    get primaryReadonlyMongodbConnectionString(): string;
    get primaryReadonlySqlConnectionString(): string;
    get primarySqlConnectionString(): string;
    get readEndpoints(): string[];
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    get secondaryKey(): string;
    get secondaryMongodbConnectionString(): string;
    get secondaryReadonlyKey(): string;
    get secondaryReadonlyMongodbConnectionString(): string;
    get secondaryReadonlySqlConnectionString(): string;
    get secondarySqlConnectionString(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _virtualNetworkRule;
    get virtualNetworkRule(): DataAzurermCosmosdbAccountVirtualNetworkRuleList;
    get writeEndpoints(): string[];
    private _timeouts;
    get timeouts(): DataAzurermCosmosdbAccountTimeoutsOutputReference;
    putTimeouts(value: DataAzurermCosmosdbAccountTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermCosmosdbAccountTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
