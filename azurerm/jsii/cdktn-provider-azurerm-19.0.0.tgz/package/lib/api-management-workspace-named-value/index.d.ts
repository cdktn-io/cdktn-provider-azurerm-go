/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiManagementWorkspaceNamedValueConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#api_management_workspace_id ApiManagementWorkspaceNamedValue#api_management_workspace_id}
    */
    readonly apiManagementWorkspaceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#display_name ApiManagementWorkspaceNamedValue#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#id ApiManagementWorkspaceNamedValue#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#name ApiManagementWorkspaceNamedValue#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#secret ApiManagementWorkspaceNamedValue#secret}
    */
    readonly secret?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#tags ApiManagementWorkspaceNamedValue#tags}
    */
    readonly tags?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#value ApiManagementWorkspaceNamedValue#value}
    */
    readonly value?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#timeouts ApiManagementWorkspaceNamedValue#timeouts}
    */
    readonly timeouts?: ApiManagementWorkspaceNamedValueTimeouts;
    /**
    * value_from_key_vault block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#value_from_key_vault ApiManagementWorkspaceNamedValue#value_from_key_vault}
    */
    readonly valueFromKeyVault?: ApiManagementWorkspaceNamedValueValueFromKeyVault;
}
export interface ApiManagementWorkspaceNamedValueTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#create ApiManagementWorkspaceNamedValue#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#delete ApiManagementWorkspaceNamedValue#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#read ApiManagementWorkspaceNamedValue#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#update ApiManagementWorkspaceNamedValue#update}
    */
    readonly update?: string;
}
export declare function apiManagementWorkspaceNamedValueTimeoutsToTerraform(struct?: ApiManagementWorkspaceNamedValueTimeouts | cdktn.IResolvable): any;
export declare function apiManagementWorkspaceNamedValueTimeoutsToHclTerraform(struct?: ApiManagementWorkspaceNamedValueTimeouts | cdktn.IResolvable): any;
export declare class ApiManagementWorkspaceNamedValueTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementWorkspaceNamedValueTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementWorkspaceNamedValueTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ApiManagementWorkspaceNamedValueValueFromKeyVault {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#identity_client_id ApiManagementWorkspaceNamedValue#identity_client_id}
    */
    readonly identityClientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#secret_id ApiManagementWorkspaceNamedValue#secret_id}
    */
    readonly secretId: string;
}
export declare function apiManagementWorkspaceNamedValueValueFromKeyVaultToTerraform(struct?: ApiManagementWorkspaceNamedValueValueFromKeyVaultOutputReference | ApiManagementWorkspaceNamedValueValueFromKeyVault): any;
export declare function apiManagementWorkspaceNamedValueValueFromKeyVaultToHclTerraform(struct?: ApiManagementWorkspaceNamedValueValueFromKeyVaultOutputReference | ApiManagementWorkspaceNamedValueValueFromKeyVault): any;
export declare class ApiManagementWorkspaceNamedValueValueFromKeyVaultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementWorkspaceNamedValueValueFromKeyVault | undefined;
    set internalValue(value: ApiManagementWorkspaceNamedValueValueFromKeyVault | undefined);
    private _identityClientId?;
    get identityClientId(): string;
    set identityClientId(value: string);
    resetIdentityClientId(): void;
    get identityClientIdInput(): string | undefined;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    get secretIdInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value azurerm_api_management_workspace_named_value}
*/
export declare class ApiManagementWorkspaceNamedValue extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_api_management_workspace_named_value";
    /**
    * Generates CDKTN code for importing a ApiManagementWorkspaceNamedValue resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiManagementWorkspaceNamedValue to import
    * @param importFromId The id of the existing ApiManagementWorkspaceNamedValue that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiManagementWorkspaceNamedValue to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_workspace_named_value azurerm_api_management_workspace_named_value} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiManagementWorkspaceNamedValueConfig
    */
    constructor(scope: Construct, id: string, config: ApiManagementWorkspaceNamedValueConfig);
    private _apiManagementWorkspaceId?;
    get apiManagementWorkspaceId(): string;
    set apiManagementWorkspaceId(value: string);
    get apiManagementWorkspaceIdInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secret?;
    get secret(): boolean | cdktn.IResolvable;
    set secret(value: boolean | cdktn.IResolvable);
    resetSecret(): void;
    get secretInput(): boolean | cdktn.IResolvable | undefined;
    private _tags?;
    get tags(): string[];
    set tags(value: string[]);
    resetTags(): void;
    get tagsInput(): string[] | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApiManagementWorkspaceNamedValueTimeoutsOutputReference;
    putTimeouts(value: ApiManagementWorkspaceNamedValueTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApiManagementWorkspaceNamedValueTimeouts | undefined;
    private _valueFromKeyVault;
    get valueFromKeyVault(): ApiManagementWorkspaceNamedValueValueFromKeyVaultOutputReference;
    putValueFromKeyVault(value: ApiManagementWorkspaceNamedValueValueFromKeyVault): void;
    resetValueFromKeyVault(): void;
    get valueFromKeyVaultInput(): ApiManagementWorkspaceNamedValueValueFromKeyVault | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
