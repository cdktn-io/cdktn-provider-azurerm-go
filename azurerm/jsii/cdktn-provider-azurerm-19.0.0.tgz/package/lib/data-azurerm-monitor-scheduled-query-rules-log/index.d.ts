/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermMonitorScheduledQueryRulesLogConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/monitor_scheduled_query_rules_log#id DataAzurermMonitorScheduledQueryRulesLog#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/monitor_scheduled_query_rules_log#name DataAzurermMonitorScheduledQueryRulesLog#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/monitor_scheduled_query_rules_log#resource_group_name DataAzurermMonitorScheduledQueryRulesLog#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/monitor_scheduled_query_rules_log#timeouts DataAzurermMonitorScheduledQueryRulesLog#timeouts}
    */
    readonly timeouts?: DataAzurermMonitorScheduledQueryRulesLogTimeouts;
}
export interface DataAzurermMonitorScheduledQueryRulesLogCriteriaDimension {
}
export declare function dataAzurermMonitorScheduledQueryRulesLogCriteriaDimensionToTerraform(struct?: DataAzurermMonitorScheduledQueryRulesLogCriteriaDimension): any;
export declare function dataAzurermMonitorScheduledQueryRulesLogCriteriaDimensionToHclTerraform(struct?: DataAzurermMonitorScheduledQueryRulesLogCriteriaDimension): any;
export declare class DataAzurermMonitorScheduledQueryRulesLogCriteriaDimensionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermMonitorScheduledQueryRulesLogCriteriaDimension | undefined;
    set internalValue(value: DataAzurermMonitorScheduledQueryRulesLogCriteriaDimension | undefined);
    get name(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataAzurermMonitorScheduledQueryRulesLogCriteriaDimensionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermMonitorScheduledQueryRulesLogCriteriaDimensionOutputReference;
}
export interface DataAzurermMonitorScheduledQueryRulesLogCriteria {
}
export declare function dataAzurermMonitorScheduledQueryRulesLogCriteriaToTerraform(struct?: DataAzurermMonitorScheduledQueryRulesLogCriteria): any;
export declare function dataAzurermMonitorScheduledQueryRulesLogCriteriaToHclTerraform(struct?: DataAzurermMonitorScheduledQueryRulesLogCriteria): any;
export declare class DataAzurermMonitorScheduledQueryRulesLogCriteriaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermMonitorScheduledQueryRulesLogCriteria | undefined;
    set internalValue(value: DataAzurermMonitorScheduledQueryRulesLogCriteria | undefined);
    private _dimension;
    get dimension(): DataAzurermMonitorScheduledQueryRulesLogCriteriaDimensionList;
    get metricName(): string;
}
export declare class DataAzurermMonitorScheduledQueryRulesLogCriteriaList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermMonitorScheduledQueryRulesLogCriteriaOutputReference;
}
export interface DataAzurermMonitorScheduledQueryRulesLogTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/monitor_scheduled_query_rules_log#read DataAzurermMonitorScheduledQueryRulesLog#read}
    */
    readonly read?: string;
}
export declare function dataAzurermMonitorScheduledQueryRulesLogTimeoutsToTerraform(struct?: DataAzurermMonitorScheduledQueryRulesLogTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermMonitorScheduledQueryRulesLogTimeoutsToHclTerraform(struct?: DataAzurermMonitorScheduledQueryRulesLogTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermMonitorScheduledQueryRulesLogTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermMonitorScheduledQueryRulesLogTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermMonitorScheduledQueryRulesLogTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/monitor_scheduled_query_rules_log azurerm_monitor_scheduled_query_rules_log}
*/
export declare class DataAzurermMonitorScheduledQueryRulesLog extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_monitor_scheduled_query_rules_log";
    /**
    * Generates CDKTN code for importing a DataAzurermMonitorScheduledQueryRulesLog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermMonitorScheduledQueryRulesLog to import
    * @param importFromId The id of the existing DataAzurermMonitorScheduledQueryRulesLog that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/monitor_scheduled_query_rules_log#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermMonitorScheduledQueryRulesLog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/monitor_scheduled_query_rules_log azurerm_monitor_scheduled_query_rules_log} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermMonitorScheduledQueryRulesLogConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermMonitorScheduledQueryRulesLogConfig);
    get authorizedResourceIds(): string[];
    private _criteria;
    get criteria(): DataAzurermMonitorScheduledQueryRulesLogCriteriaList;
    get dataSourceId(): string;
    get description(): string;
    get enabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): DataAzurermMonitorScheduledQueryRulesLogTimeoutsOutputReference;
    putTimeouts(value: DataAzurermMonitorScheduledQueryRulesLogTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermMonitorScheduledQueryRulesLogTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
