/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermArcResourceBridgeApplianceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/arc_resource_bridge_appliance#id DataAzurermArcResourceBridgeAppliance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/arc_resource_bridge_appliance#name DataAzurermArcResourceBridgeAppliance#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/arc_resource_bridge_appliance#resource_group_name DataAzurermArcResourceBridgeAppliance#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/arc_resource_bridge_appliance#timeouts DataAzurermArcResourceBridgeAppliance#timeouts}
    */
    readonly timeouts?: DataAzurermArcResourceBridgeApplianceTimeouts;
}
export interface DataAzurermArcResourceBridgeApplianceIdentity {
}
export declare function dataAzurermArcResourceBridgeApplianceIdentityToTerraform(struct?: DataAzurermArcResourceBridgeApplianceIdentity): any;
export declare function dataAzurermArcResourceBridgeApplianceIdentityToHclTerraform(struct?: DataAzurermArcResourceBridgeApplianceIdentity): any;
export declare class DataAzurermArcResourceBridgeApplianceIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermArcResourceBridgeApplianceIdentity | undefined;
    set internalValue(value: DataAzurermArcResourceBridgeApplianceIdentity | undefined);
    get principalId(): string;
    get tenantId(): string;
    get type(): string;
}
export declare class DataAzurermArcResourceBridgeApplianceIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermArcResourceBridgeApplianceIdentityOutputReference;
}
export interface DataAzurermArcResourceBridgeApplianceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/arc_resource_bridge_appliance#read DataAzurermArcResourceBridgeAppliance#read}
    */
    readonly read?: string;
}
export declare function dataAzurermArcResourceBridgeApplianceTimeoutsToTerraform(struct?: DataAzurermArcResourceBridgeApplianceTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermArcResourceBridgeApplianceTimeoutsToHclTerraform(struct?: DataAzurermArcResourceBridgeApplianceTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermArcResourceBridgeApplianceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermArcResourceBridgeApplianceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermArcResourceBridgeApplianceTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/arc_resource_bridge_appliance azurerm_arc_resource_bridge_appliance}
*/
export declare class DataAzurermArcResourceBridgeAppliance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_arc_resource_bridge_appliance";
    /**
    * Generates CDKTN code for importing a DataAzurermArcResourceBridgeAppliance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermArcResourceBridgeAppliance to import
    * @param importFromId The id of the existing DataAzurermArcResourceBridgeAppliance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/arc_resource_bridge_appliance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermArcResourceBridgeAppliance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/arc_resource_bridge_appliance azurerm_arc_resource_bridge_appliance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermArcResourceBridgeApplianceConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermArcResourceBridgeApplianceConfig);
    get distro(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): DataAzurermArcResourceBridgeApplianceIdentityList;
    get infrastructureProvider(): string;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get publicKeyBase64(): string;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): DataAzurermArcResourceBridgeApplianceTimeoutsOutputReference;
    putTimeouts(value: DataAzurermArcResourceBridgeApplianceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermArcResourceBridgeApplianceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
