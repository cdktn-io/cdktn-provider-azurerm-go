/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermNetappVolumeBucketConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/netapp_volume_bucket#id DataAzurermNetappVolumeBucket#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/netapp_volume_bucket#name DataAzurermNetappVolumeBucket#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/netapp_volume_bucket#netapp_volume_id DataAzurermNetappVolumeBucket#netapp_volume_id}
    */
    readonly netappVolumeId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/netapp_volume_bucket#timeouts DataAzurermNetappVolumeBucket#timeouts}
    */
    readonly timeouts?: DataAzurermNetappVolumeBucketTimeouts;
}
export interface DataAzurermNetappVolumeBucketFileSystemNfsUser {
}
export declare function dataAzurermNetappVolumeBucketFileSystemNfsUserToTerraform(struct?: DataAzurermNetappVolumeBucketFileSystemNfsUser): any;
export declare function dataAzurermNetappVolumeBucketFileSystemNfsUserToHclTerraform(struct?: DataAzurermNetappVolumeBucketFileSystemNfsUser): any;
export declare class DataAzurermNetappVolumeBucketFileSystemNfsUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermNetappVolumeBucketFileSystemNfsUser | undefined;
    set internalValue(value: DataAzurermNetappVolumeBucketFileSystemNfsUser | undefined);
    get groupId(): number;
    get userId(): number;
}
export declare class DataAzurermNetappVolumeBucketFileSystemNfsUserList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermNetappVolumeBucketFileSystemNfsUserOutputReference;
}
export interface DataAzurermNetappVolumeBucketKeyVault {
}
export declare function dataAzurermNetappVolumeBucketKeyVaultToTerraform(struct?: DataAzurermNetappVolumeBucketKeyVault): any;
export declare function dataAzurermNetappVolumeBucketKeyVaultToHclTerraform(struct?: DataAzurermNetappVolumeBucketKeyVault): any;
export declare class DataAzurermNetappVolumeBucketKeyVaultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermNetappVolumeBucketKeyVault | undefined;
    set internalValue(value: DataAzurermNetappVolumeBucketKeyVault | undefined);
    get certificateKeyVaultUri(): string;
    get certificateName(): string;
    get credentialsKeyVaultUri(): string;
    get credentialsSecretName(): string;
}
export declare class DataAzurermNetappVolumeBucketKeyVaultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermNetappVolumeBucketKeyVaultOutputReference;
}
export interface DataAzurermNetappVolumeBucketTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/netapp_volume_bucket#read DataAzurermNetappVolumeBucket#read}
    */
    readonly read?: string;
}
export declare function dataAzurermNetappVolumeBucketTimeoutsToTerraform(struct?: DataAzurermNetappVolumeBucketTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermNetappVolumeBucketTimeoutsToHclTerraform(struct?: DataAzurermNetappVolumeBucketTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermNetappVolumeBucketTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermNetappVolumeBucketTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermNetappVolumeBucketTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/netapp_volume_bucket azurerm_netapp_volume_bucket}
*/
export declare class DataAzurermNetappVolumeBucket extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_netapp_volume_bucket";
    /**
    * Generates CDKTN code for importing a DataAzurermNetappVolumeBucket resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermNetappVolumeBucket to import
    * @param importFromId The id of the existing DataAzurermNetappVolumeBucket that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/netapp_volume_bucket#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermNetappVolumeBucket to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/netapp_volume_bucket azurerm_netapp_volume_bucket} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermNetappVolumeBucketConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermNetappVolumeBucketConfig);
    get fileSystemCifsUsername(): string;
    private _fileSystemNfsUser;
    get fileSystemNfsUser(): DataAzurermNetappVolumeBucketFileSystemNfsUserList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyVault;
    get keyVault(): DataAzurermNetappVolumeBucketKeyVaultList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _netappVolumeId?;
    get netappVolumeId(): string;
    set netappVolumeId(value: string);
    get netappVolumeIdInput(): string | undefined;
    get path(): string;
    get permissions(): string;
    get serverCertificateCommonName(): string;
    get serverCertificateExpiryDate(): string;
    get serverIpAddress(): string;
    get status(): string;
    private _timeouts;
    get timeouts(): DataAzurermNetappVolumeBucketTimeoutsOutputReference;
    putTimeouts(value: DataAzurermNetappVolumeBucketTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermNetappVolumeBucketTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
