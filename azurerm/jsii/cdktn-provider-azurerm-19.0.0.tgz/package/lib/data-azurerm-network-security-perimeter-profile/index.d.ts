/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermNetworkSecurityPerimeterProfileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/network_security_perimeter_profile#id DataAzurermNetworkSecurityPerimeterProfile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/network_security_perimeter_profile#name DataAzurermNetworkSecurityPerimeterProfile#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/network_security_perimeter_profile#network_security_perimeter_id DataAzurermNetworkSecurityPerimeterProfile#network_security_perimeter_id}
    */
    readonly networkSecurityPerimeterId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/network_security_perimeter_profile#timeouts DataAzurermNetworkSecurityPerimeterProfile#timeouts}
    */
    readonly timeouts?: DataAzurermNetworkSecurityPerimeterProfileTimeouts;
}
export interface DataAzurermNetworkSecurityPerimeterProfileTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/network_security_perimeter_profile#read DataAzurermNetworkSecurityPerimeterProfile#read}
    */
    readonly read?: string;
}
export declare function dataAzurermNetworkSecurityPerimeterProfileTimeoutsToTerraform(struct?: DataAzurermNetworkSecurityPerimeterProfileTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermNetworkSecurityPerimeterProfileTimeoutsToHclTerraform(struct?: DataAzurermNetworkSecurityPerimeterProfileTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermNetworkSecurityPerimeterProfileTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermNetworkSecurityPerimeterProfileTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermNetworkSecurityPerimeterProfileTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/network_security_perimeter_profile azurerm_network_security_perimeter_profile}
*/
export declare class DataAzurermNetworkSecurityPerimeterProfile extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_network_security_perimeter_profile";
    /**
    * Generates CDKTN code for importing a DataAzurermNetworkSecurityPerimeterProfile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermNetworkSecurityPerimeterProfile to import
    * @param importFromId The id of the existing DataAzurermNetworkSecurityPerimeterProfile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/network_security_perimeter_profile#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermNetworkSecurityPerimeterProfile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/network_security_perimeter_profile azurerm_network_security_perimeter_profile} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermNetworkSecurityPerimeterProfileConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermNetworkSecurityPerimeterProfileConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkSecurityPerimeterId?;
    get networkSecurityPerimeterId(): string;
    set networkSecurityPerimeterId(value: string);
    get networkSecurityPerimeterIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAzurermNetworkSecurityPerimeterProfileTimeoutsOutputReference;
    putTimeouts(value: DataAzurermNetworkSecurityPerimeterProfileTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermNetworkSecurityPerimeterProfileTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
