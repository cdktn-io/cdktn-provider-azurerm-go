/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermLogicAppWorkflowConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/logic_app_workflow#id DataAzurermLogicAppWorkflow#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/logic_app_workflow#name DataAzurermLogicAppWorkflow#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/logic_app_workflow#resource_group_name DataAzurermLogicAppWorkflow#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/logic_app_workflow#timeouts DataAzurermLogicAppWorkflow#timeouts}
    */
    readonly timeouts?: DataAzurermLogicAppWorkflowTimeouts;
}
export interface DataAzurermLogicAppWorkflowIdentity {
}
export declare function dataAzurermLogicAppWorkflowIdentityToTerraform(struct?: DataAzurermLogicAppWorkflowIdentity): any;
export declare function dataAzurermLogicAppWorkflowIdentityToHclTerraform(struct?: DataAzurermLogicAppWorkflowIdentity): any;
export declare class DataAzurermLogicAppWorkflowIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermLogicAppWorkflowIdentity | undefined;
    set internalValue(value: DataAzurermLogicAppWorkflowIdentity | undefined);
    get identityIds(): string[];
    get principalId(): string;
    get tenantId(): string;
    get type(): string;
}
export declare class DataAzurermLogicAppWorkflowIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermLogicAppWorkflowIdentityOutputReference;
}
export interface DataAzurermLogicAppWorkflowTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/logic_app_workflow#read DataAzurermLogicAppWorkflow#read}
    */
    readonly read?: string;
}
export declare function dataAzurermLogicAppWorkflowTimeoutsToTerraform(struct?: DataAzurermLogicAppWorkflowTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermLogicAppWorkflowTimeoutsToHclTerraform(struct?: DataAzurermLogicAppWorkflowTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermLogicAppWorkflowTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermLogicAppWorkflowTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermLogicAppWorkflowTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/logic_app_workflow azurerm_logic_app_workflow}
*/
export declare class DataAzurermLogicAppWorkflow extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_logic_app_workflow";
    /**
    * Generates CDKTN code for importing a DataAzurermLogicAppWorkflow resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermLogicAppWorkflow to import
    * @param importFromId The id of the existing DataAzurermLogicAppWorkflow that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/logic_app_workflow#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermLogicAppWorkflow to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/logic_app_workflow azurerm_logic_app_workflow} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermLogicAppWorkflowConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermLogicAppWorkflowConfig);
    get accessEndpoint(): string;
    get connectorEndpointIpAddresses(): string[];
    get connectorOutboundIpAddresses(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): DataAzurermLogicAppWorkflowIdentityList;
    get location(): string;
    get logicAppIntegrationAccountId(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameters;
    get parameters(): cdktn.StringMap;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    get workflowEndpointIpAddresses(): string[];
    get workflowOutboundIpAddresses(): string[];
    get workflowSchema(): string;
    get workflowVersion(): string;
    private _timeouts;
    get timeouts(): DataAzurermLogicAppWorkflowTimeoutsOutputReference;
    putTimeouts(value: DataAzurermLogicAppWorkflowTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermLogicAppWorkflowTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
