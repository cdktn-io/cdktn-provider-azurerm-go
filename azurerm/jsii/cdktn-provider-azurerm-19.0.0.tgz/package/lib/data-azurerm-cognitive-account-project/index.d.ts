/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermCognitiveAccountProjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cognitive_account_project#cognitive_account_name DataAzurermCognitiveAccountProject#cognitive_account_name}
    */
    readonly cognitiveAccountName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cognitive_account_project#id DataAzurermCognitiveAccountProject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cognitive_account_project#name DataAzurermCognitiveAccountProject#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cognitive_account_project#resource_group_name DataAzurermCognitiveAccountProject#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cognitive_account_project#timeouts DataAzurermCognitiveAccountProject#timeouts}
    */
    readonly timeouts?: DataAzurermCognitiveAccountProjectTimeouts;
}
export interface DataAzurermCognitiveAccountProjectIdentity {
}
export declare function dataAzurermCognitiveAccountProjectIdentityToTerraform(struct?: DataAzurermCognitiveAccountProjectIdentity): any;
export declare function dataAzurermCognitiveAccountProjectIdentityToHclTerraform(struct?: DataAzurermCognitiveAccountProjectIdentity): any;
export declare class DataAzurermCognitiveAccountProjectIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCognitiveAccountProjectIdentity | undefined;
    set internalValue(value: DataAzurermCognitiveAccountProjectIdentity | undefined);
    get identityIds(): string[];
    get principalId(): string;
    get tenantId(): string;
    get type(): string;
}
export declare class DataAzurermCognitiveAccountProjectIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCognitiveAccountProjectIdentityOutputReference;
}
export interface DataAzurermCognitiveAccountProjectTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cognitive_account_project#read DataAzurermCognitiveAccountProject#read}
    */
    readonly read?: string;
}
export declare function dataAzurermCognitiveAccountProjectTimeoutsToTerraform(struct?: DataAzurermCognitiveAccountProjectTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermCognitiveAccountProjectTimeoutsToHclTerraform(struct?: DataAzurermCognitiveAccountProjectTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermCognitiveAccountProjectTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermCognitiveAccountProjectTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermCognitiveAccountProjectTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cognitive_account_project azurerm_cognitive_account_project}
*/
export declare class DataAzurermCognitiveAccountProject extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_cognitive_account_project";
    /**
    * Generates CDKTN code for importing a DataAzurermCognitiveAccountProject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermCognitiveAccountProject to import
    * @param importFromId The id of the existing DataAzurermCognitiveAccountProject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cognitive_account_project#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermCognitiveAccountProject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cognitive_account_project azurerm_cognitive_account_project} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermCognitiveAccountProjectConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermCognitiveAccountProjectConfig);
    private _cognitiveAccountName?;
    get cognitiveAccountName(): string;
    set cognitiveAccountName(value: string);
    get cognitiveAccountNameInput(): string | undefined;
    get default(): cdktn.IResolvable;
    get description(): string;
    get displayName(): string;
    private _endpoints;
    get endpoints(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): DataAzurermCognitiveAccountProjectIdentityList;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): DataAzurermCognitiveAccountProjectTimeoutsOutputReference;
    putTimeouts(value: DataAzurermCognitiveAccountProjectTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermCognitiveAccountProjectTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
