/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiManagementApiDiagnosticConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#always_log_errors ApiManagementApiDiagnostic#always_log_errors}
    */
    readonly alwaysLogErrors?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#api_management_logger_id ApiManagementApiDiagnostic#api_management_logger_id}
    */
    readonly apiManagementLoggerId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#api_management_name ApiManagementApiDiagnostic#api_management_name}
    */
    readonly apiManagementName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#api_name ApiManagementApiDiagnostic#api_name}
    */
    readonly apiName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#http_correlation_protocol ApiManagementApiDiagnostic#http_correlation_protocol}
    */
    readonly httpCorrelationProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#id ApiManagementApiDiagnostic#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#identifier ApiManagementApiDiagnostic#identifier}
    */
    readonly identifier: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#log_client_ip ApiManagementApiDiagnostic#log_client_ip}
    */
    readonly logClientIp?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#metrics_enabled ApiManagementApiDiagnostic#metrics_enabled}
    */
    readonly metricsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#operation_name_format ApiManagementApiDiagnostic#operation_name_format}
    */
    readonly operationNameFormat?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#resource_group_name ApiManagementApiDiagnostic#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#sampling_percentage ApiManagementApiDiagnostic#sampling_percentage}
    */
    readonly samplingPercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#verbosity ApiManagementApiDiagnostic#verbosity}
    */
    readonly verbosity?: string;
    /**
    * backend_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#backend_request ApiManagementApiDiagnostic#backend_request}
    */
    readonly backendRequest?: ApiManagementApiDiagnosticBackendRequest;
    /**
    * backend_response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#backend_response ApiManagementApiDiagnostic#backend_response}
    */
    readonly backendResponse?: ApiManagementApiDiagnosticBackendResponse;
    /**
    * frontend_request block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#frontend_request ApiManagementApiDiagnostic#frontend_request}
    */
    readonly frontendRequest?: ApiManagementApiDiagnosticFrontendRequest;
    /**
    * frontend_response block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#frontend_response ApiManagementApiDiagnostic#frontend_response}
    */
    readonly frontendResponse?: ApiManagementApiDiagnosticFrontendResponse;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#timeouts ApiManagementApiDiagnostic#timeouts}
    */
    readonly timeouts?: ApiManagementApiDiagnosticTimeouts;
}
export interface ApiManagementApiDiagnosticBackendRequestDataMaskingHeaders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#mode ApiManagementApiDiagnostic#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#value ApiManagementApiDiagnostic#value}
    */
    readonly value: string;
}
export declare function apiManagementApiDiagnosticBackendRequestDataMaskingHeadersToTerraform(struct?: ApiManagementApiDiagnosticBackendRequestDataMaskingHeaders | cdktn.IResolvable): any;
export declare function apiManagementApiDiagnosticBackendRequestDataMaskingHeadersToHclTerraform(struct?: ApiManagementApiDiagnosticBackendRequestDataMaskingHeaders | cdktn.IResolvable): any;
export declare class ApiManagementApiDiagnosticBackendRequestDataMaskingHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiManagementApiDiagnosticBackendRequestDataMaskingHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementApiDiagnosticBackendRequestDataMaskingHeaders | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApiManagementApiDiagnosticBackendRequestDataMaskingHeadersList extends cdktn.ComplexList {
    internalValue?: ApiManagementApiDiagnosticBackendRequestDataMaskingHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiManagementApiDiagnosticBackendRequestDataMaskingHeadersOutputReference;
}
export interface ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#mode ApiManagementApiDiagnostic#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#value ApiManagementApiDiagnostic#value}
    */
    readonly value: string;
}
export declare function apiManagementApiDiagnosticBackendRequestDataMaskingQueryParamsToTerraform(struct?: ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParams | cdktn.IResolvable): any;
export declare function apiManagementApiDiagnosticBackendRequestDataMaskingQueryParamsToHclTerraform(struct?: ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParams | cdktn.IResolvable): any;
export declare class ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParams | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParams | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParamsList extends cdktn.ComplexList {
    internalValue?: ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParams[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParamsOutputReference;
}
export interface ApiManagementApiDiagnosticBackendRequestDataMasking {
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#headers ApiManagementApiDiagnostic#headers}
    */
    readonly headers?: ApiManagementApiDiagnosticBackendRequestDataMaskingHeaders[] | cdktn.IResolvable;
    /**
    * query_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#query_params ApiManagementApiDiagnostic#query_params}
    */
    readonly queryParams?: ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParams[] | cdktn.IResolvable;
}
export declare function apiManagementApiDiagnosticBackendRequestDataMaskingToTerraform(struct?: ApiManagementApiDiagnosticBackendRequestDataMaskingOutputReference | ApiManagementApiDiagnosticBackendRequestDataMasking): any;
export declare function apiManagementApiDiagnosticBackendRequestDataMaskingToHclTerraform(struct?: ApiManagementApiDiagnosticBackendRequestDataMaskingOutputReference | ApiManagementApiDiagnosticBackendRequestDataMasking): any;
export declare class ApiManagementApiDiagnosticBackendRequestDataMaskingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementApiDiagnosticBackendRequestDataMasking | undefined;
    set internalValue(value: ApiManagementApiDiagnosticBackendRequestDataMasking | undefined);
    private _headers;
    get headers(): ApiManagementApiDiagnosticBackendRequestDataMaskingHeadersList;
    putHeaders(value: ApiManagementApiDiagnosticBackendRequestDataMaskingHeaders[] | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | ApiManagementApiDiagnosticBackendRequestDataMaskingHeaders[] | undefined;
    private _queryParams;
    get queryParams(): ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParamsList;
    putQueryParams(value: ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParams[] | cdktn.IResolvable): void;
    resetQueryParams(): void;
    get queryParamsInput(): cdktn.IResolvable | ApiManagementApiDiagnosticBackendRequestDataMaskingQueryParams[] | undefined;
}
export interface ApiManagementApiDiagnosticBackendRequest {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#body_bytes ApiManagementApiDiagnostic#body_bytes}
    */
    readonly bodyBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#headers_to_log ApiManagementApiDiagnostic#headers_to_log}
    */
    readonly headersToLog?: string[];
    /**
    * data_masking block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#data_masking ApiManagementApiDiagnostic#data_masking}
    */
    readonly dataMasking?: ApiManagementApiDiagnosticBackendRequestDataMasking;
}
export declare function apiManagementApiDiagnosticBackendRequestToTerraform(struct?: ApiManagementApiDiagnosticBackendRequestOutputReference | ApiManagementApiDiagnosticBackendRequest): any;
export declare function apiManagementApiDiagnosticBackendRequestToHclTerraform(struct?: ApiManagementApiDiagnosticBackendRequestOutputReference | ApiManagementApiDiagnosticBackendRequest): any;
export declare class ApiManagementApiDiagnosticBackendRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementApiDiagnosticBackendRequest | undefined;
    set internalValue(value: ApiManagementApiDiagnosticBackendRequest | undefined);
    private _bodyBytes?;
    get bodyBytes(): number;
    set bodyBytes(value: number);
    resetBodyBytes(): void;
    get bodyBytesInput(): number | undefined;
    private _headersToLog?;
    get headersToLog(): string[];
    set headersToLog(value: string[]);
    resetHeadersToLog(): void;
    get headersToLogInput(): string[] | undefined;
    private _dataMasking;
    get dataMasking(): ApiManagementApiDiagnosticBackendRequestDataMaskingOutputReference;
    putDataMasking(value: ApiManagementApiDiagnosticBackendRequestDataMasking): void;
    resetDataMasking(): void;
    get dataMaskingInput(): ApiManagementApiDiagnosticBackendRequestDataMasking | undefined;
}
export interface ApiManagementApiDiagnosticBackendResponseDataMaskingHeaders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#mode ApiManagementApiDiagnostic#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#value ApiManagementApiDiagnostic#value}
    */
    readonly value: string;
}
export declare function apiManagementApiDiagnosticBackendResponseDataMaskingHeadersToTerraform(struct?: ApiManagementApiDiagnosticBackendResponseDataMaskingHeaders | cdktn.IResolvable): any;
export declare function apiManagementApiDiagnosticBackendResponseDataMaskingHeadersToHclTerraform(struct?: ApiManagementApiDiagnosticBackendResponseDataMaskingHeaders | cdktn.IResolvable): any;
export declare class ApiManagementApiDiagnosticBackendResponseDataMaskingHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiManagementApiDiagnosticBackendResponseDataMaskingHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementApiDiagnosticBackendResponseDataMaskingHeaders | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApiManagementApiDiagnosticBackendResponseDataMaskingHeadersList extends cdktn.ComplexList {
    internalValue?: ApiManagementApiDiagnosticBackendResponseDataMaskingHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiManagementApiDiagnosticBackendResponseDataMaskingHeadersOutputReference;
}
export interface ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#mode ApiManagementApiDiagnostic#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#value ApiManagementApiDiagnostic#value}
    */
    readonly value: string;
}
export declare function apiManagementApiDiagnosticBackendResponseDataMaskingQueryParamsToTerraform(struct?: ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParams | cdktn.IResolvable): any;
export declare function apiManagementApiDiagnosticBackendResponseDataMaskingQueryParamsToHclTerraform(struct?: ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParams | cdktn.IResolvable): any;
export declare class ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParams | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParams | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParamsList extends cdktn.ComplexList {
    internalValue?: ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParams[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParamsOutputReference;
}
export interface ApiManagementApiDiagnosticBackendResponseDataMasking {
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#headers ApiManagementApiDiagnostic#headers}
    */
    readonly headers?: ApiManagementApiDiagnosticBackendResponseDataMaskingHeaders[] | cdktn.IResolvable;
    /**
    * query_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#query_params ApiManagementApiDiagnostic#query_params}
    */
    readonly queryParams?: ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParams[] | cdktn.IResolvable;
}
export declare function apiManagementApiDiagnosticBackendResponseDataMaskingToTerraform(struct?: ApiManagementApiDiagnosticBackendResponseDataMaskingOutputReference | ApiManagementApiDiagnosticBackendResponseDataMasking): any;
export declare function apiManagementApiDiagnosticBackendResponseDataMaskingToHclTerraform(struct?: ApiManagementApiDiagnosticBackendResponseDataMaskingOutputReference | ApiManagementApiDiagnosticBackendResponseDataMasking): any;
export declare class ApiManagementApiDiagnosticBackendResponseDataMaskingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementApiDiagnosticBackendResponseDataMasking | undefined;
    set internalValue(value: ApiManagementApiDiagnosticBackendResponseDataMasking | undefined);
    private _headers;
    get headers(): ApiManagementApiDiagnosticBackendResponseDataMaskingHeadersList;
    putHeaders(value: ApiManagementApiDiagnosticBackendResponseDataMaskingHeaders[] | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | ApiManagementApiDiagnosticBackendResponseDataMaskingHeaders[] | undefined;
    private _queryParams;
    get queryParams(): ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParamsList;
    putQueryParams(value: ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParams[] | cdktn.IResolvable): void;
    resetQueryParams(): void;
    get queryParamsInput(): cdktn.IResolvable | ApiManagementApiDiagnosticBackendResponseDataMaskingQueryParams[] | undefined;
}
export interface ApiManagementApiDiagnosticBackendResponse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#body_bytes ApiManagementApiDiagnostic#body_bytes}
    */
    readonly bodyBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#headers_to_log ApiManagementApiDiagnostic#headers_to_log}
    */
    readonly headersToLog?: string[];
    /**
    * data_masking block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#data_masking ApiManagementApiDiagnostic#data_masking}
    */
    readonly dataMasking?: ApiManagementApiDiagnosticBackendResponseDataMasking;
}
export declare function apiManagementApiDiagnosticBackendResponseToTerraform(struct?: ApiManagementApiDiagnosticBackendResponseOutputReference | ApiManagementApiDiagnosticBackendResponse): any;
export declare function apiManagementApiDiagnosticBackendResponseToHclTerraform(struct?: ApiManagementApiDiagnosticBackendResponseOutputReference | ApiManagementApiDiagnosticBackendResponse): any;
export declare class ApiManagementApiDiagnosticBackendResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementApiDiagnosticBackendResponse | undefined;
    set internalValue(value: ApiManagementApiDiagnosticBackendResponse | undefined);
    private _bodyBytes?;
    get bodyBytes(): number;
    set bodyBytes(value: number);
    resetBodyBytes(): void;
    get bodyBytesInput(): number | undefined;
    private _headersToLog?;
    get headersToLog(): string[];
    set headersToLog(value: string[]);
    resetHeadersToLog(): void;
    get headersToLogInput(): string[] | undefined;
    private _dataMasking;
    get dataMasking(): ApiManagementApiDiagnosticBackendResponseDataMaskingOutputReference;
    putDataMasking(value: ApiManagementApiDiagnosticBackendResponseDataMasking): void;
    resetDataMasking(): void;
    get dataMaskingInput(): ApiManagementApiDiagnosticBackendResponseDataMasking | undefined;
}
export interface ApiManagementApiDiagnosticFrontendRequestDataMaskingHeaders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#mode ApiManagementApiDiagnostic#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#value ApiManagementApiDiagnostic#value}
    */
    readonly value: string;
}
export declare function apiManagementApiDiagnosticFrontendRequestDataMaskingHeadersToTerraform(struct?: ApiManagementApiDiagnosticFrontendRequestDataMaskingHeaders | cdktn.IResolvable): any;
export declare function apiManagementApiDiagnosticFrontendRequestDataMaskingHeadersToHclTerraform(struct?: ApiManagementApiDiagnosticFrontendRequestDataMaskingHeaders | cdktn.IResolvable): any;
export declare class ApiManagementApiDiagnosticFrontendRequestDataMaskingHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiManagementApiDiagnosticFrontendRequestDataMaskingHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementApiDiagnosticFrontendRequestDataMaskingHeaders | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApiManagementApiDiagnosticFrontendRequestDataMaskingHeadersList extends cdktn.ComplexList {
    internalValue?: ApiManagementApiDiagnosticFrontendRequestDataMaskingHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiManagementApiDiagnosticFrontendRequestDataMaskingHeadersOutputReference;
}
export interface ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#mode ApiManagementApiDiagnostic#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#value ApiManagementApiDiagnostic#value}
    */
    readonly value: string;
}
export declare function apiManagementApiDiagnosticFrontendRequestDataMaskingQueryParamsToTerraform(struct?: ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParams | cdktn.IResolvable): any;
export declare function apiManagementApiDiagnosticFrontendRequestDataMaskingQueryParamsToHclTerraform(struct?: ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParams | cdktn.IResolvable): any;
export declare class ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParams | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParams | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParamsList extends cdktn.ComplexList {
    internalValue?: ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParams[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParamsOutputReference;
}
export interface ApiManagementApiDiagnosticFrontendRequestDataMasking {
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#headers ApiManagementApiDiagnostic#headers}
    */
    readonly headers?: ApiManagementApiDiagnosticFrontendRequestDataMaskingHeaders[] | cdktn.IResolvable;
    /**
    * query_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#query_params ApiManagementApiDiagnostic#query_params}
    */
    readonly queryParams?: ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParams[] | cdktn.IResolvable;
}
export declare function apiManagementApiDiagnosticFrontendRequestDataMaskingToTerraform(struct?: ApiManagementApiDiagnosticFrontendRequestDataMaskingOutputReference | ApiManagementApiDiagnosticFrontendRequestDataMasking): any;
export declare function apiManagementApiDiagnosticFrontendRequestDataMaskingToHclTerraform(struct?: ApiManagementApiDiagnosticFrontendRequestDataMaskingOutputReference | ApiManagementApiDiagnosticFrontendRequestDataMasking): any;
export declare class ApiManagementApiDiagnosticFrontendRequestDataMaskingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementApiDiagnosticFrontendRequestDataMasking | undefined;
    set internalValue(value: ApiManagementApiDiagnosticFrontendRequestDataMasking | undefined);
    private _headers;
    get headers(): ApiManagementApiDiagnosticFrontendRequestDataMaskingHeadersList;
    putHeaders(value: ApiManagementApiDiagnosticFrontendRequestDataMaskingHeaders[] | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | ApiManagementApiDiagnosticFrontendRequestDataMaskingHeaders[] | undefined;
    private _queryParams;
    get queryParams(): ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParamsList;
    putQueryParams(value: ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParams[] | cdktn.IResolvable): void;
    resetQueryParams(): void;
    get queryParamsInput(): cdktn.IResolvable | ApiManagementApiDiagnosticFrontendRequestDataMaskingQueryParams[] | undefined;
}
export interface ApiManagementApiDiagnosticFrontendRequest {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#body_bytes ApiManagementApiDiagnostic#body_bytes}
    */
    readonly bodyBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#headers_to_log ApiManagementApiDiagnostic#headers_to_log}
    */
    readonly headersToLog?: string[];
    /**
    * data_masking block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#data_masking ApiManagementApiDiagnostic#data_masking}
    */
    readonly dataMasking?: ApiManagementApiDiagnosticFrontendRequestDataMasking;
}
export declare function apiManagementApiDiagnosticFrontendRequestToTerraform(struct?: ApiManagementApiDiagnosticFrontendRequestOutputReference | ApiManagementApiDiagnosticFrontendRequest): any;
export declare function apiManagementApiDiagnosticFrontendRequestToHclTerraform(struct?: ApiManagementApiDiagnosticFrontendRequestOutputReference | ApiManagementApiDiagnosticFrontendRequest): any;
export declare class ApiManagementApiDiagnosticFrontendRequestOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementApiDiagnosticFrontendRequest | undefined;
    set internalValue(value: ApiManagementApiDiagnosticFrontendRequest | undefined);
    private _bodyBytes?;
    get bodyBytes(): number;
    set bodyBytes(value: number);
    resetBodyBytes(): void;
    get bodyBytesInput(): number | undefined;
    private _headersToLog?;
    get headersToLog(): string[];
    set headersToLog(value: string[]);
    resetHeadersToLog(): void;
    get headersToLogInput(): string[] | undefined;
    private _dataMasking;
    get dataMasking(): ApiManagementApiDiagnosticFrontendRequestDataMaskingOutputReference;
    putDataMasking(value: ApiManagementApiDiagnosticFrontendRequestDataMasking): void;
    resetDataMasking(): void;
    get dataMaskingInput(): ApiManagementApiDiagnosticFrontendRequestDataMasking | undefined;
}
export interface ApiManagementApiDiagnosticFrontendResponseDataMaskingHeaders {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#mode ApiManagementApiDiagnostic#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#value ApiManagementApiDiagnostic#value}
    */
    readonly value: string;
}
export declare function apiManagementApiDiagnosticFrontendResponseDataMaskingHeadersToTerraform(struct?: ApiManagementApiDiagnosticFrontendResponseDataMaskingHeaders | cdktn.IResolvable): any;
export declare function apiManagementApiDiagnosticFrontendResponseDataMaskingHeadersToHclTerraform(struct?: ApiManagementApiDiagnosticFrontendResponseDataMaskingHeaders | cdktn.IResolvable): any;
export declare class ApiManagementApiDiagnosticFrontendResponseDataMaskingHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiManagementApiDiagnosticFrontendResponseDataMaskingHeaders | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementApiDiagnosticFrontendResponseDataMaskingHeaders | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApiManagementApiDiagnosticFrontendResponseDataMaskingHeadersList extends cdktn.ComplexList {
    internalValue?: ApiManagementApiDiagnosticFrontendResponseDataMaskingHeaders[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiManagementApiDiagnosticFrontendResponseDataMaskingHeadersOutputReference;
}
export interface ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParams {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#mode ApiManagementApiDiagnostic#mode}
    */
    readonly mode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#value ApiManagementApiDiagnostic#value}
    */
    readonly value: string;
}
export declare function apiManagementApiDiagnosticFrontendResponseDataMaskingQueryParamsToTerraform(struct?: ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParams | cdktn.IResolvable): any;
export declare function apiManagementApiDiagnosticFrontendResponseDataMaskingQueryParamsToHclTerraform(struct?: ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParams | cdktn.IResolvable): any;
export declare class ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParams | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParams | cdktn.IResolvable | undefined);
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParamsList extends cdktn.ComplexList {
    internalValue?: ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParams[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParamsOutputReference;
}
export interface ApiManagementApiDiagnosticFrontendResponseDataMasking {
    /**
    * headers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#headers ApiManagementApiDiagnostic#headers}
    */
    readonly headers?: ApiManagementApiDiagnosticFrontendResponseDataMaskingHeaders[] | cdktn.IResolvable;
    /**
    * query_params block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#query_params ApiManagementApiDiagnostic#query_params}
    */
    readonly queryParams?: ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParams[] | cdktn.IResolvable;
}
export declare function apiManagementApiDiagnosticFrontendResponseDataMaskingToTerraform(struct?: ApiManagementApiDiagnosticFrontendResponseDataMaskingOutputReference | ApiManagementApiDiagnosticFrontendResponseDataMasking): any;
export declare function apiManagementApiDiagnosticFrontendResponseDataMaskingToHclTerraform(struct?: ApiManagementApiDiagnosticFrontendResponseDataMaskingOutputReference | ApiManagementApiDiagnosticFrontendResponseDataMasking): any;
export declare class ApiManagementApiDiagnosticFrontendResponseDataMaskingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementApiDiagnosticFrontendResponseDataMasking | undefined;
    set internalValue(value: ApiManagementApiDiagnosticFrontendResponseDataMasking | undefined);
    private _headers;
    get headers(): ApiManagementApiDiagnosticFrontendResponseDataMaskingHeadersList;
    putHeaders(value: ApiManagementApiDiagnosticFrontendResponseDataMaskingHeaders[] | cdktn.IResolvable): void;
    resetHeaders(): void;
    get headersInput(): cdktn.IResolvable | ApiManagementApiDiagnosticFrontendResponseDataMaskingHeaders[] | undefined;
    private _queryParams;
    get queryParams(): ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParamsList;
    putQueryParams(value: ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParams[] | cdktn.IResolvable): void;
    resetQueryParams(): void;
    get queryParamsInput(): cdktn.IResolvable | ApiManagementApiDiagnosticFrontendResponseDataMaskingQueryParams[] | undefined;
}
export interface ApiManagementApiDiagnosticFrontendResponse {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#body_bytes ApiManagementApiDiagnostic#body_bytes}
    */
    readonly bodyBytes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#headers_to_log ApiManagementApiDiagnostic#headers_to_log}
    */
    readonly headersToLog?: string[];
    /**
    * data_masking block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#data_masking ApiManagementApiDiagnostic#data_masking}
    */
    readonly dataMasking?: ApiManagementApiDiagnosticFrontendResponseDataMasking;
}
export declare function apiManagementApiDiagnosticFrontendResponseToTerraform(struct?: ApiManagementApiDiagnosticFrontendResponseOutputReference | ApiManagementApiDiagnosticFrontendResponse): any;
export declare function apiManagementApiDiagnosticFrontendResponseToHclTerraform(struct?: ApiManagementApiDiagnosticFrontendResponseOutputReference | ApiManagementApiDiagnosticFrontendResponse): any;
export declare class ApiManagementApiDiagnosticFrontendResponseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementApiDiagnosticFrontendResponse | undefined;
    set internalValue(value: ApiManagementApiDiagnosticFrontendResponse | undefined);
    private _bodyBytes?;
    get bodyBytes(): number;
    set bodyBytes(value: number);
    resetBodyBytes(): void;
    get bodyBytesInput(): number | undefined;
    private _headersToLog?;
    get headersToLog(): string[];
    set headersToLog(value: string[]);
    resetHeadersToLog(): void;
    get headersToLogInput(): string[] | undefined;
    private _dataMasking;
    get dataMasking(): ApiManagementApiDiagnosticFrontendResponseDataMaskingOutputReference;
    putDataMasking(value: ApiManagementApiDiagnosticFrontendResponseDataMasking): void;
    resetDataMasking(): void;
    get dataMaskingInput(): ApiManagementApiDiagnosticFrontendResponseDataMasking | undefined;
}
export interface ApiManagementApiDiagnosticTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#create ApiManagementApiDiagnostic#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#delete ApiManagementApiDiagnostic#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#read ApiManagementApiDiagnostic#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#update ApiManagementApiDiagnostic#update}
    */
    readonly update?: string;
}
export declare function apiManagementApiDiagnosticTimeoutsToTerraform(struct?: ApiManagementApiDiagnosticTimeouts | cdktn.IResolvable): any;
export declare function apiManagementApiDiagnosticTimeoutsToHclTerraform(struct?: ApiManagementApiDiagnosticTimeouts | cdktn.IResolvable): any;
export declare class ApiManagementApiDiagnosticTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementApiDiagnosticTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementApiDiagnosticTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic azurerm_api_management_api_diagnostic}
*/
export declare class ApiManagementApiDiagnostic extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_api_management_api_diagnostic";
    /**
    * Generates CDKTN code for importing a ApiManagementApiDiagnostic resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiManagementApiDiagnostic to import
    * @param importFromId The id of the existing ApiManagementApiDiagnostic that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiManagementApiDiagnostic to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/api_management_api_diagnostic azurerm_api_management_api_diagnostic} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiManagementApiDiagnosticConfig
    */
    constructor(scope: Construct, id: string, config: ApiManagementApiDiagnosticConfig);
    private _alwaysLogErrors?;
    get alwaysLogErrors(): boolean | cdktn.IResolvable;
    set alwaysLogErrors(value: boolean | cdktn.IResolvable);
    resetAlwaysLogErrors(): void;
    get alwaysLogErrorsInput(): boolean | cdktn.IResolvable | undefined;
    private _apiManagementLoggerId?;
    get apiManagementLoggerId(): string;
    set apiManagementLoggerId(value: string);
    get apiManagementLoggerIdInput(): string | undefined;
    private _apiManagementName?;
    get apiManagementName(): string;
    set apiManagementName(value: string);
    get apiManagementNameInput(): string | undefined;
    private _apiName?;
    get apiName(): string;
    set apiName(value: string);
    get apiNameInput(): string | undefined;
    private _httpCorrelationProtocol?;
    get httpCorrelationProtocol(): string;
    set httpCorrelationProtocol(value: string);
    resetHttpCorrelationProtocol(): void;
    get httpCorrelationProtocolInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    private _logClientIp?;
    get logClientIp(): boolean | cdktn.IResolvable;
    set logClientIp(value: boolean | cdktn.IResolvable);
    resetLogClientIp(): void;
    get logClientIpInput(): boolean | cdktn.IResolvable | undefined;
    private _metricsEnabled?;
    get metricsEnabled(): boolean | cdktn.IResolvable;
    set metricsEnabled(value: boolean | cdktn.IResolvable);
    resetMetricsEnabled(): void;
    get metricsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _operationNameFormat?;
    get operationNameFormat(): string;
    set operationNameFormat(value: string);
    resetOperationNameFormat(): void;
    get operationNameFormatInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _samplingPercentage?;
    get samplingPercentage(): number;
    set samplingPercentage(value: number);
    resetSamplingPercentage(): void;
    get samplingPercentageInput(): number | undefined;
    private _verbosity?;
    get verbosity(): string;
    set verbosity(value: string);
    resetVerbosity(): void;
    get verbosityInput(): string | undefined;
    private _backendRequest;
    get backendRequest(): ApiManagementApiDiagnosticBackendRequestOutputReference;
    putBackendRequest(value: ApiManagementApiDiagnosticBackendRequest): void;
    resetBackendRequest(): void;
    get backendRequestInput(): ApiManagementApiDiagnosticBackendRequest | undefined;
    private _backendResponse;
    get backendResponse(): ApiManagementApiDiagnosticBackendResponseOutputReference;
    putBackendResponse(value: ApiManagementApiDiagnosticBackendResponse): void;
    resetBackendResponse(): void;
    get backendResponseInput(): ApiManagementApiDiagnosticBackendResponse | undefined;
    private _frontendRequest;
    get frontendRequest(): ApiManagementApiDiagnosticFrontendRequestOutputReference;
    putFrontendRequest(value: ApiManagementApiDiagnosticFrontendRequest): void;
    resetFrontendRequest(): void;
    get frontendRequestInput(): ApiManagementApiDiagnosticFrontendRequest | undefined;
    private _frontendResponse;
    get frontendResponse(): ApiManagementApiDiagnosticFrontendResponseOutputReference;
    putFrontendResponse(value: ApiManagementApiDiagnosticFrontendResponse): void;
    resetFrontendResponse(): void;
    get frontendResponseInput(): ApiManagementApiDiagnosticFrontendResponse | undefined;
    private _timeouts;
    get timeouts(): ApiManagementApiDiagnosticTimeoutsOutputReference;
    putTimeouts(value: ApiManagementApiDiagnosticTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApiManagementApiDiagnosticTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
