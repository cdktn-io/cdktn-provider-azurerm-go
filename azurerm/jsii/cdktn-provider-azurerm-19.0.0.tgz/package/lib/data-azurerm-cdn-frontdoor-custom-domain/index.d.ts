/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermCdnFrontdoorCustomDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_custom_domain#id DataAzurermCdnFrontdoorCustomDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_custom_domain#name DataAzurermCdnFrontdoorCustomDomain#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_custom_domain#profile_name DataAzurermCdnFrontdoorCustomDomain#profile_name}
    */
    readonly profileName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_custom_domain#resource_group_name DataAzurermCdnFrontdoorCustomDomain#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_custom_domain#timeouts DataAzurermCdnFrontdoorCustomDomain#timeouts}
    */
    readonly timeouts?: DataAzurermCdnFrontdoorCustomDomainTimeouts;
}
export interface DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers {
}
export declare function dataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersToTerraform(struct?: DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers): any;
export declare function dataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersToHclTerraform(struct?: DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers): any;
export declare class DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers | undefined);
    get tls12(): string[];
    get tls13(): string[];
}
export declare class DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersOutputReference;
}
export interface DataAzurermCdnFrontdoorCustomDomainTlsCipherSuite {
}
export declare function dataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteToTerraform(struct?: DataAzurermCdnFrontdoorCustomDomainTlsCipherSuite): any;
export declare function dataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteToHclTerraform(struct?: DataAzurermCdnFrontdoorCustomDomainTlsCipherSuite): any;
export declare class DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorCustomDomainTlsCipherSuite | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorCustomDomainTlsCipherSuite | undefined);
    private _customCiphers;
    get customCiphers(): DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersList;
    get type(): string;
}
export declare class DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteOutputReference;
}
export interface DataAzurermCdnFrontdoorCustomDomainTls {
}
export declare function dataAzurermCdnFrontdoorCustomDomainTlsToTerraform(struct?: DataAzurermCdnFrontdoorCustomDomainTls): any;
export declare function dataAzurermCdnFrontdoorCustomDomainTlsToHclTerraform(struct?: DataAzurermCdnFrontdoorCustomDomainTls): any;
export declare class DataAzurermCdnFrontdoorCustomDomainTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorCustomDomainTls | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorCustomDomainTls | undefined);
    get cdnFrontdoorSecretId(): string;
    get certificateType(): string;
    private _cipherSuite;
    get cipherSuite(): DataAzurermCdnFrontdoorCustomDomainTlsCipherSuiteList;
    get minimumVersion(): string;
}
export declare class DataAzurermCdnFrontdoorCustomDomainTlsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorCustomDomainTlsOutputReference;
}
export interface DataAzurermCdnFrontdoorCustomDomainTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_custom_domain#read DataAzurermCdnFrontdoorCustomDomain#read}
    */
    readonly read?: string;
}
export declare function dataAzurermCdnFrontdoorCustomDomainTimeoutsToTerraform(struct?: DataAzurermCdnFrontdoorCustomDomainTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermCdnFrontdoorCustomDomainTimeoutsToHclTerraform(struct?: DataAzurermCdnFrontdoorCustomDomainTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermCdnFrontdoorCustomDomainTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermCdnFrontdoorCustomDomainTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorCustomDomainTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_custom_domain azurerm_cdn_frontdoor_custom_domain}
*/
export declare class DataAzurermCdnFrontdoorCustomDomain extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_cdn_frontdoor_custom_domain";
    /**
    * Generates CDKTN code for importing a DataAzurermCdnFrontdoorCustomDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermCdnFrontdoorCustomDomain to import
    * @param importFromId The id of the existing DataAzurermCdnFrontdoorCustomDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_custom_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermCdnFrontdoorCustomDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/cdn_frontdoor_custom_domain azurerm_cdn_frontdoor_custom_domain} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermCdnFrontdoorCustomDomainConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermCdnFrontdoorCustomDomainConfig);
    get cdnFrontdoorProfileId(): string;
    get dnsZoneId(): string;
    get expirationDate(): string;
    get hostName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _profileName?;
    get profileName(): string;
    set profileName(value: string);
    get profileNameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _tls;
    get tls(): DataAzurermCdnFrontdoorCustomDomainTlsList;
    get validationToken(): string;
    private _timeouts;
    get timeouts(): DataAzurermCdnFrontdoorCustomDomainTimeoutsOutputReference;
    putTimeouts(value: DataAzurermCdnFrontdoorCustomDomainTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermCdnFrontdoorCustomDomainTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
