/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BatchAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#allowed_authentication_modes BatchAccount#allowed_authentication_modes}
    */
    readonly allowedAuthenticationModes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#encryption BatchAccount#encryption}
    */
    readonly encryption?: BatchAccountEncryption[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#id BatchAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#location BatchAccount#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#name BatchAccount#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#pool_allocation_mode BatchAccount#pool_allocation_mode}
    */
    readonly poolAllocationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#public_network_access_enabled BatchAccount#public_network_access_enabled}
    */
    readonly publicNetworkAccessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#resource_group_name BatchAccount#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#storage_account_authentication_mode BatchAccount#storage_account_authentication_mode}
    */
    readonly storageAccountAuthenticationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#storage_account_id BatchAccount#storage_account_id}
    */
    readonly storageAccountId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#storage_account_node_identity BatchAccount#storage_account_node_identity}
    */
    readonly storageAccountNodeIdentity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#tags BatchAccount#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#identity BatchAccount#identity}
    */
    readonly identity?: BatchAccountIdentity;
    /**
    * key_vault_reference block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#key_vault_reference BatchAccount#key_vault_reference}
    */
    readonly keyVaultReference?: BatchAccountKeyVaultReference;
    /**
    * network_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#network_profile BatchAccount#network_profile}
    */
    readonly networkProfile?: BatchAccountNetworkProfile;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#timeouts BatchAccount#timeouts}
    */
    readonly timeouts?: BatchAccountTimeouts;
}
export interface BatchAccountEncryption {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#key_vault_key_id BatchAccount#key_vault_key_id}
    */
    readonly keyVaultKeyId?: string;
}
export declare function batchAccountEncryptionToTerraform(struct?: BatchAccountEncryption | cdktn.IResolvable): any;
export declare function batchAccountEncryptionToHclTerraform(struct?: BatchAccountEncryption | cdktn.IResolvable): any;
export declare class BatchAccountEncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchAccountEncryption | cdktn.IResolvable | undefined;
    set internalValue(value: BatchAccountEncryption | cdktn.IResolvable | undefined);
    private _keyVaultKeyId?;
    get keyVaultKeyId(): string;
    set keyVaultKeyId(value: string);
    resetKeyVaultKeyId(): void;
    get keyVaultKeyIdInput(): string | undefined;
}
export declare class BatchAccountEncryptionList extends cdktn.ComplexList {
    internalValue?: BatchAccountEncryption[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchAccountEncryptionOutputReference;
}
export interface BatchAccountIdentity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#identity_ids BatchAccount#identity_ids}
    */
    readonly identityIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#type BatchAccount#type}
    */
    readonly type: string;
}
export declare function batchAccountIdentityToTerraform(struct?: BatchAccountIdentityOutputReference | BatchAccountIdentity): any;
export declare function batchAccountIdentityToHclTerraform(struct?: BatchAccountIdentityOutputReference | BatchAccountIdentity): any;
export declare class BatchAccountIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchAccountIdentity | undefined;
    set internalValue(value: BatchAccountIdentity | undefined);
    private _identityIds?;
    get identityIds(): string[];
    set identityIds(value: string[]);
    resetIdentityIds(): void;
    get identityIdsInput(): string[] | undefined;
    get principalId(): string;
    get tenantId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface BatchAccountKeyVaultReference {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#id BatchAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#url BatchAccount#url}
    */
    readonly url: string;
}
export declare function batchAccountKeyVaultReferenceToTerraform(struct?: BatchAccountKeyVaultReferenceOutputReference | BatchAccountKeyVaultReference): any;
export declare function batchAccountKeyVaultReferenceToHclTerraform(struct?: BatchAccountKeyVaultReferenceOutputReference | BatchAccountKeyVaultReference): any;
export declare class BatchAccountKeyVaultReferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchAccountKeyVaultReference | undefined;
    set internalValue(value: BatchAccountKeyVaultReference | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _url?;
    get url(): string;
    set url(value: string);
    get urlInput(): string | undefined;
}
export interface BatchAccountNetworkProfileAccountAccessIpRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#action BatchAccount#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#ip_range BatchAccount#ip_range}
    */
    readonly ipRange: string;
}
export declare function batchAccountNetworkProfileAccountAccessIpRuleToTerraform(struct?: BatchAccountNetworkProfileAccountAccessIpRule | cdktn.IResolvable): any;
export declare function batchAccountNetworkProfileAccountAccessIpRuleToHclTerraform(struct?: BatchAccountNetworkProfileAccountAccessIpRule | cdktn.IResolvable): any;
export declare class BatchAccountNetworkProfileAccountAccessIpRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchAccountNetworkProfileAccountAccessIpRule | cdktn.IResolvable | undefined;
    set internalValue(value: BatchAccountNetworkProfileAccountAccessIpRule | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _ipRange?;
    get ipRange(): string;
    set ipRange(value: string);
    get ipRangeInput(): string | undefined;
}
export declare class BatchAccountNetworkProfileAccountAccessIpRuleList extends cdktn.ComplexList {
    internalValue?: BatchAccountNetworkProfileAccountAccessIpRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchAccountNetworkProfileAccountAccessIpRuleOutputReference;
}
export interface BatchAccountNetworkProfileAccountAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#default_action BatchAccount#default_action}
    */
    readonly defaultAction?: string;
    /**
    * ip_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#ip_rule BatchAccount#ip_rule}
    */
    readonly ipRule?: BatchAccountNetworkProfileAccountAccessIpRule[] | cdktn.IResolvable;
}
export declare function batchAccountNetworkProfileAccountAccessToTerraform(struct?: BatchAccountNetworkProfileAccountAccessOutputReference | BatchAccountNetworkProfileAccountAccess): any;
export declare function batchAccountNetworkProfileAccountAccessToHclTerraform(struct?: BatchAccountNetworkProfileAccountAccessOutputReference | BatchAccountNetworkProfileAccountAccess): any;
export declare class BatchAccountNetworkProfileAccountAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchAccountNetworkProfileAccountAccess | undefined;
    set internalValue(value: BatchAccountNetworkProfileAccountAccess | undefined);
    private _defaultAction?;
    get defaultAction(): string;
    set defaultAction(value: string);
    resetDefaultAction(): void;
    get defaultActionInput(): string | undefined;
    private _ipRule;
    get ipRule(): BatchAccountNetworkProfileAccountAccessIpRuleList;
    putIpRule(value: BatchAccountNetworkProfileAccountAccessIpRule[] | cdktn.IResolvable): void;
    resetIpRule(): void;
    get ipRuleInput(): cdktn.IResolvable | BatchAccountNetworkProfileAccountAccessIpRule[] | undefined;
}
export interface BatchAccountNetworkProfileNodeManagementAccessIpRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#action BatchAccount#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#ip_range BatchAccount#ip_range}
    */
    readonly ipRange: string;
}
export declare function batchAccountNetworkProfileNodeManagementAccessIpRuleToTerraform(struct?: BatchAccountNetworkProfileNodeManagementAccessIpRule | cdktn.IResolvable): any;
export declare function batchAccountNetworkProfileNodeManagementAccessIpRuleToHclTerraform(struct?: BatchAccountNetworkProfileNodeManagementAccessIpRule | cdktn.IResolvable): any;
export declare class BatchAccountNetworkProfileNodeManagementAccessIpRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BatchAccountNetworkProfileNodeManagementAccessIpRule | cdktn.IResolvable | undefined;
    set internalValue(value: BatchAccountNetworkProfileNodeManagementAccessIpRule | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _ipRange?;
    get ipRange(): string;
    set ipRange(value: string);
    get ipRangeInput(): string | undefined;
}
export declare class BatchAccountNetworkProfileNodeManagementAccessIpRuleList extends cdktn.ComplexList {
    internalValue?: BatchAccountNetworkProfileNodeManagementAccessIpRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BatchAccountNetworkProfileNodeManagementAccessIpRuleOutputReference;
}
export interface BatchAccountNetworkProfileNodeManagementAccess {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#default_action BatchAccount#default_action}
    */
    readonly defaultAction?: string;
    /**
    * ip_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#ip_rule BatchAccount#ip_rule}
    */
    readonly ipRule?: BatchAccountNetworkProfileNodeManagementAccessIpRule[] | cdktn.IResolvable;
}
export declare function batchAccountNetworkProfileNodeManagementAccessToTerraform(struct?: BatchAccountNetworkProfileNodeManagementAccessOutputReference | BatchAccountNetworkProfileNodeManagementAccess): any;
export declare function batchAccountNetworkProfileNodeManagementAccessToHclTerraform(struct?: BatchAccountNetworkProfileNodeManagementAccessOutputReference | BatchAccountNetworkProfileNodeManagementAccess): any;
export declare class BatchAccountNetworkProfileNodeManagementAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchAccountNetworkProfileNodeManagementAccess | undefined;
    set internalValue(value: BatchAccountNetworkProfileNodeManagementAccess | undefined);
    private _defaultAction?;
    get defaultAction(): string;
    set defaultAction(value: string);
    resetDefaultAction(): void;
    get defaultActionInput(): string | undefined;
    private _ipRule;
    get ipRule(): BatchAccountNetworkProfileNodeManagementAccessIpRuleList;
    putIpRule(value: BatchAccountNetworkProfileNodeManagementAccessIpRule[] | cdktn.IResolvable): void;
    resetIpRule(): void;
    get ipRuleInput(): cdktn.IResolvable | BatchAccountNetworkProfileNodeManagementAccessIpRule[] | undefined;
}
export interface BatchAccountNetworkProfile {
    /**
    * account_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#account_access BatchAccount#account_access}
    */
    readonly accountAccess?: BatchAccountNetworkProfileAccountAccess;
    /**
    * node_management_access block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#node_management_access BatchAccount#node_management_access}
    */
    readonly nodeManagementAccess?: BatchAccountNetworkProfileNodeManagementAccess;
}
export declare function batchAccountNetworkProfileToTerraform(struct?: BatchAccountNetworkProfileOutputReference | BatchAccountNetworkProfile): any;
export declare function batchAccountNetworkProfileToHclTerraform(struct?: BatchAccountNetworkProfileOutputReference | BatchAccountNetworkProfile): any;
export declare class BatchAccountNetworkProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchAccountNetworkProfile | undefined;
    set internalValue(value: BatchAccountNetworkProfile | undefined);
    private _accountAccess;
    get accountAccess(): BatchAccountNetworkProfileAccountAccessOutputReference;
    putAccountAccess(value: BatchAccountNetworkProfileAccountAccess): void;
    resetAccountAccess(): void;
    get accountAccessInput(): BatchAccountNetworkProfileAccountAccess | undefined;
    private _nodeManagementAccess;
    get nodeManagementAccess(): BatchAccountNetworkProfileNodeManagementAccessOutputReference;
    putNodeManagementAccess(value: BatchAccountNetworkProfileNodeManagementAccess): void;
    resetNodeManagementAccess(): void;
    get nodeManagementAccessInput(): BatchAccountNetworkProfileNodeManagementAccess | undefined;
}
export interface BatchAccountTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#create BatchAccount#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#delete BatchAccount#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#read BatchAccount#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#update BatchAccount#update}
    */
    readonly update?: string;
}
export declare function batchAccountTimeoutsToTerraform(struct?: BatchAccountTimeouts | cdktn.IResolvable): any;
export declare function batchAccountTimeoutsToHclTerraform(struct?: BatchAccountTimeouts | cdktn.IResolvable): any;
export declare class BatchAccountTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BatchAccountTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BatchAccountTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account azurerm_batch_account}
*/
export declare class BatchAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_batch_account";
    /**
    * Generates CDKTN code for importing a BatchAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BatchAccount to import
    * @param importFromId The id of the existing BatchAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BatchAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/batch_account azurerm_batch_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BatchAccountConfig
    */
    constructor(scope: Construct, id: string, config: BatchAccountConfig);
    get accountEndpoint(): string;
    private _allowedAuthenticationModes?;
    get allowedAuthenticationModes(): string[];
    set allowedAuthenticationModes(value: string[]);
    resetAllowedAuthenticationModes(): void;
    get allowedAuthenticationModesInput(): string[] | undefined;
    private _encryption;
    get encryption(): BatchAccountEncryptionList;
    putEncryption(value: BatchAccountEncryption[] | cdktn.IResolvable): void;
    resetEncryption(): void;
    get encryptionInput(): cdktn.IResolvable | BatchAccountEncryption[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _poolAllocationMode?;
    get poolAllocationMode(): string;
    set poolAllocationMode(value: string);
    resetPoolAllocationMode(): void;
    get poolAllocationModeInput(): string | undefined;
    get primaryAccessKey(): string;
    private _publicNetworkAccessEnabled?;
    get publicNetworkAccessEnabled(): boolean | cdktn.IResolvable;
    set publicNetworkAccessEnabled(value: boolean | cdktn.IResolvable);
    resetPublicNetworkAccessEnabled(): void;
    get publicNetworkAccessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    get secondaryAccessKey(): string;
    private _storageAccountAuthenticationMode?;
    get storageAccountAuthenticationMode(): string;
    set storageAccountAuthenticationMode(value: string);
    resetStorageAccountAuthenticationMode(): void;
    get storageAccountAuthenticationModeInput(): string | undefined;
    private _storageAccountId?;
    get storageAccountId(): string;
    set storageAccountId(value: string);
    resetStorageAccountId(): void;
    get storageAccountIdInput(): string | undefined;
    private _storageAccountNodeIdentity?;
    get storageAccountNodeIdentity(): string;
    set storageAccountNodeIdentity(value: string);
    resetStorageAccountNodeIdentity(): void;
    get storageAccountNodeIdentityInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _identity;
    get identity(): BatchAccountIdentityOutputReference;
    putIdentity(value: BatchAccountIdentity): void;
    resetIdentity(): void;
    get identityInput(): BatchAccountIdentity | undefined;
    private _keyVaultReference;
    get keyVaultReference(): BatchAccountKeyVaultReferenceOutputReference;
    putKeyVaultReference(value: BatchAccountKeyVaultReference): void;
    resetKeyVaultReference(): void;
    get keyVaultReferenceInput(): BatchAccountKeyVaultReference | undefined;
    private _networkProfile;
    get networkProfile(): BatchAccountNetworkProfileOutputReference;
    putNetworkProfile(value: BatchAccountNetworkProfile): void;
    resetNetworkProfile(): void;
    get networkProfileInput(): BatchAccountNetworkProfile | undefined;
    private _timeouts;
    get timeouts(): BatchAccountTimeoutsOutputReference;
    putTimeouts(value: BatchAccountTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BatchAccountTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
