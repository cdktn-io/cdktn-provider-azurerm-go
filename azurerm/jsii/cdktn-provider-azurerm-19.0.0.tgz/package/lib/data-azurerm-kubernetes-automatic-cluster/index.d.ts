/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermKubernetesAutomaticClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/kubernetes_automatic_cluster#id DataAzurermKubernetesAutomaticCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/kubernetes_automatic_cluster#name DataAzurermKubernetesAutomaticCluster#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/kubernetes_automatic_cluster#resource_group_name DataAzurermKubernetesAutomaticCluster#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/kubernetes_automatic_cluster#timeouts DataAzurermKubernetesAutomaticCluster#timeouts}
    */
    readonly timeouts?: DataAzurermKubernetesAutomaticClusterTimeouts;
}
export interface DataAzurermKubernetesAutomaticClusterApiServerAccess {
}
export declare function dataAzurermKubernetesAutomaticClusterApiServerAccessToTerraform(struct?: DataAzurermKubernetesAutomaticClusterApiServerAccess): any;
export declare function dataAzurermKubernetesAutomaticClusterApiServerAccessToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterApiServerAccess): any;
export declare class DataAzurermKubernetesAutomaticClusterApiServerAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKubernetesAutomaticClusterApiServerAccess | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterApiServerAccess | undefined);
    get authorizedIpRanges(): string[];
    get subnetId(): string;
}
export declare class DataAzurermKubernetesAutomaticClusterApiServerAccessList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKubernetesAutomaticClusterApiServerAccessOutputReference;
}
export interface DataAzurermKubernetesAutomaticClusterHostedSystem {
}
export declare function dataAzurermKubernetesAutomaticClusterHostedSystemToTerraform(struct?: DataAzurermKubernetesAutomaticClusterHostedSystem): any;
export declare function dataAzurermKubernetesAutomaticClusterHostedSystemToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterHostedSystem): any;
export declare class DataAzurermKubernetesAutomaticClusterHostedSystemOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKubernetesAutomaticClusterHostedSystem | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterHostedSystem | undefined);
    get nodeSubnetId(): string;
    get systemNodeSubnetId(): string;
}
export declare class DataAzurermKubernetesAutomaticClusterHostedSystemList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKubernetesAutomaticClusterHostedSystemOutputReference;
}
export interface DataAzurermKubernetesAutomaticClusterIdentity {
}
export declare function dataAzurermKubernetesAutomaticClusterIdentityToTerraform(struct?: DataAzurermKubernetesAutomaticClusterIdentity): any;
export declare function dataAzurermKubernetesAutomaticClusterIdentityToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterIdentity): any;
export declare class DataAzurermKubernetesAutomaticClusterIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKubernetesAutomaticClusterIdentity | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterIdentity | undefined);
    get identityIds(): string[];
    get principalId(): string;
    get tenantId(): string;
    get type(): string;
}
export declare class DataAzurermKubernetesAutomaticClusterIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKubernetesAutomaticClusterIdentityOutputReference;
}
export interface DataAzurermKubernetesAutomaticClusterKubeConfig {
}
export declare function dataAzurermKubernetesAutomaticClusterKubeConfigToTerraform(struct?: DataAzurermKubernetesAutomaticClusterKubeConfig): any;
export declare function dataAzurermKubernetesAutomaticClusterKubeConfigToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterKubeConfig): any;
export declare class DataAzurermKubernetesAutomaticClusterKubeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKubernetesAutomaticClusterKubeConfig | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterKubeConfig | undefined);
    get clientCertificate(): string;
    get clientKey(): string;
    get clusterCaCertificate(): string;
    get host(): string;
    get password(): string;
    get username(): string;
}
export declare class DataAzurermKubernetesAutomaticClusterKubeConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKubernetesAutomaticClusterKubeConfigOutputReference;
}
export interface DataAzurermKubernetesAutomaticClusterKubeletIdentity {
}
export declare function dataAzurermKubernetesAutomaticClusterKubeletIdentityToTerraform(struct?: DataAzurermKubernetesAutomaticClusterKubeletIdentity): any;
export declare function dataAzurermKubernetesAutomaticClusterKubeletIdentityToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterKubeletIdentity): any;
export declare class DataAzurermKubernetesAutomaticClusterKubeletIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKubernetesAutomaticClusterKubeletIdentity | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterKubeletIdentity | undefined);
    get clientId(): string;
    get objectId(): string;
    get userAssignedIdentityId(): string;
}
export declare class DataAzurermKubernetesAutomaticClusterKubeletIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKubernetesAutomaticClusterKubeletIdentityOutputReference;
}
export interface DataAzurermKubernetesAutomaticClusterPrivateCluster {
}
export declare function dataAzurermKubernetesAutomaticClusterPrivateClusterToTerraform(struct?: DataAzurermKubernetesAutomaticClusterPrivateCluster): any;
export declare function dataAzurermKubernetesAutomaticClusterPrivateClusterToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterPrivateCluster): any;
export declare class DataAzurermKubernetesAutomaticClusterPrivateClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKubernetesAutomaticClusterPrivateCluster | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterPrivateCluster | undefined);
    get privateDnsZoneId(): string;
    get publicFullyQualifiedDomainNameEnabled(): cdktn.IResolvable;
}
export declare class DataAzurermKubernetesAutomaticClusterPrivateClusterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKubernetesAutomaticClusterPrivateClusterOutputReference;
}
export interface DataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthority {
}
export declare function dataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthorityToTerraform(struct?: DataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthority): any;
export declare function dataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthorityToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthority): any;
export declare class DataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthority | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthority | undefined);
    get certificateChainObjectName(): string;
    get certificateObjectName(): string;
    get keyObjectName(): string;
    get keyVaultId(): string;
    get rootCertificateObjectName(): string;
}
export declare class DataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthorityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthorityOutputReference;
}
export interface DataAzurermKubernetesAutomaticClusterServiceMesh {
}
export declare function dataAzurermKubernetesAutomaticClusterServiceMeshToTerraform(struct?: DataAzurermKubernetesAutomaticClusterServiceMesh): any;
export declare function dataAzurermKubernetesAutomaticClusterServiceMeshToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterServiceMesh): any;
export declare class DataAzurermKubernetesAutomaticClusterServiceMeshOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKubernetesAutomaticClusterServiceMesh | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterServiceMesh | undefined);
    private _certificateAuthority;
    get certificateAuthority(): DataAzurermKubernetesAutomaticClusterServiceMeshCertificateAuthorityList;
    get externalIngressGatewayEnabled(): cdktn.IResolvable;
    get internalIngressGatewayEnabled(): cdktn.IResolvable;
    get proxyRedirectMechanism(): string;
    get revisions(): string[];
}
export declare class DataAzurermKubernetesAutomaticClusterServiceMeshList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKubernetesAutomaticClusterServiceMeshOutputReference;
}
export interface DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentity {
}
export declare function dataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentityToTerraform(struct?: DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentity): any;
export declare function dataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentityToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentity): any;
export declare class DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentity | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentity | undefined);
    get clientId(): string;
    get objectId(): string;
    get userAssignedIdentityId(): string;
}
export declare class DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentityOutputReference;
}
export interface DataAzurermKubernetesAutomaticClusterWebAppRoutingIngress {
}
export declare function dataAzurermKubernetesAutomaticClusterWebAppRoutingIngressToTerraform(struct?: DataAzurermKubernetesAutomaticClusterWebAppRoutingIngress): any;
export declare function dataAzurermKubernetesAutomaticClusterWebAppRoutingIngressToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterWebAppRoutingIngress): any;
export declare class DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKubernetesAutomaticClusterWebAppRoutingIngress | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterWebAppRoutingIngress | undefined);
    get defaultNginxController(): string;
    get dnsZoneIds(): string[];
    get istioEnabled(): cdktn.IResolvable;
    private _webAppRoutingIdentity;
    get webAppRoutingIdentity(): DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressWebAppRoutingIdentityList;
}
export declare class DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressOutputReference;
}
export interface DataAzurermKubernetesAutomaticClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/kubernetes_automatic_cluster#read DataAzurermKubernetesAutomaticCluster#read}
    */
    readonly read?: string;
}
export declare function dataAzurermKubernetesAutomaticClusterTimeoutsToTerraform(struct?: DataAzurermKubernetesAutomaticClusterTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermKubernetesAutomaticClusterTimeoutsToHclTerraform(struct?: DataAzurermKubernetesAutomaticClusterTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermKubernetesAutomaticClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermKubernetesAutomaticClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermKubernetesAutomaticClusterTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/kubernetes_automatic_cluster azurerm_kubernetes_automatic_cluster}
*/
export declare class DataAzurermKubernetesAutomaticCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_kubernetes_automatic_cluster";
    /**
    * Generates CDKTN code for importing a DataAzurermKubernetesAutomaticCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermKubernetesAutomaticCluster to import
    * @param importFromId The id of the existing DataAzurermKubernetesAutomaticCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/kubernetes_automatic_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermKubernetesAutomaticCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/kubernetes_automatic_cluster azurerm_kubernetes_automatic_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermKubernetesAutomaticClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermKubernetesAutomaticClusterConfig);
    private _apiServerAccess;
    get apiServerAccess(): DataAzurermKubernetesAutomaticClusterApiServerAccessList;
    get currentKubernetesVersion(): string;
    get dnsPrefix(): string;
    get fullyQualifiedDomainName(): string;
    private _hostedSystem;
    get hostedSystem(): DataAzurermKubernetesAutomaticClusterHostedSystemList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): DataAzurermKubernetesAutomaticClusterIdentityList;
    private _kubeConfig;
    get kubeConfig(): DataAzurermKubernetesAutomaticClusterKubeConfigList;
    get kubeConfigRaw(): string;
    private _kubeletIdentity;
    get kubeletIdentity(): DataAzurermKubernetesAutomaticClusterKubeletIdentityList;
    get kubernetesVersion(): string;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nodeResourceGroup(): string;
    get nodeResourceGroupId(): string;
    get portalFullyQualifiedDomainName(): string;
    private _privateCluster;
    get privateCluster(): DataAzurermKubernetesAutomaticClusterPrivateClusterList;
    get privateFullyQualifiedDomainName(): string;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _serviceMesh;
    get serviceMesh(): DataAzurermKubernetesAutomaticClusterServiceMeshList;
    private _tags;
    get tags(): cdktn.StringMap;
    private _webAppRoutingIngress;
    get webAppRoutingIngress(): DataAzurermKubernetesAutomaticClusterWebAppRoutingIngressList;
    private _timeouts;
    get timeouts(): DataAzurermKubernetesAutomaticClusterTimeoutsOutputReference;
    putTimeouts(value: DataAzurermKubernetesAutomaticClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermKubernetesAutomaticClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
