/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ContainerAppConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Container App Environment to host this Container App.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#container_app_environment_id ContainerApp#container_app_environment_id}
    */
    readonly containerAppEnvironmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#id ContainerApp#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#max_inactive_revisions ContainerApp#max_inactive_revisions}
    */
    readonly maxInactiveRevisions?: number;
    /**
    * The name for this Container App.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#resource_group_name ContainerApp#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#revision_mode ContainerApp#revision_mode}
    */
    readonly revisionMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#tags ContainerApp#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#workload_profile_name ContainerApp#workload_profile_name}
    */
    readonly workloadProfileName?: string;
    /**
    * dapr block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#dapr ContainerApp#dapr}
    */
    readonly dapr?: ContainerAppDapr;
    /**
    * identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#identity ContainerApp#identity}
    */
    readonly identity?: ContainerAppIdentity;
    /**
    * ingress block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#ingress ContainerApp#ingress}
    */
    readonly ingress?: ContainerAppIngress;
    /**
    * registry block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#registry ContainerApp#registry}
    */
    readonly registry?: ContainerAppRegistry[] | cdktn.IResolvable;
    /**
    * secret block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#secret ContainerApp#secret}
    */
    readonly secret?: ContainerAppSecret[] | cdktn.IResolvable;
    /**
    * template block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#template ContainerApp#template}
    */
    readonly template: ContainerAppTemplate;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#timeouts ContainerApp#timeouts}
    */
    readonly timeouts?: ContainerAppTimeouts;
}
export interface ContainerAppDapr {
    /**
    * The Dapr Application Identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#app_id ContainerApp#app_id}
    */
    readonly appId: string;
    /**
    * The port which the application is listening on. This is the same as the `ingress` port.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#app_port ContainerApp#app_port}
    */
    readonly appPort?: number;
    /**
    * The protocol for the app. Possible values include `http` and `grpc`. Defaults to `http`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#app_protocol ContainerApp#app_protocol}
    */
    readonly appProtocol?: string;
}
export declare function containerAppDaprToTerraform(struct?: ContainerAppDaprOutputReference | ContainerAppDapr): any;
export declare function containerAppDaprToHclTerraform(struct?: ContainerAppDaprOutputReference | ContainerAppDapr): any;
export declare class ContainerAppDaprOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerAppDapr | undefined;
    set internalValue(value: ContainerAppDapr | undefined);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    private _appPort?;
    get appPort(): number;
    set appPort(value: number);
    resetAppPort(): void;
    get appPortInput(): number | undefined;
    private _appProtocol?;
    get appProtocol(): string;
    set appProtocol(value: string);
    resetAppProtocol(): void;
    get appProtocolInput(): string | undefined;
}
export interface ContainerAppIdentity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#identity_ids ContainerApp#identity_ids}
    */
    readonly identityIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#type ContainerApp#type}
    */
    readonly type: string;
}
export declare function containerAppIdentityToTerraform(struct?: ContainerAppIdentityOutputReference | ContainerAppIdentity): any;
export declare function containerAppIdentityToHclTerraform(struct?: ContainerAppIdentityOutputReference | ContainerAppIdentity): any;
export declare class ContainerAppIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerAppIdentity | undefined;
    set internalValue(value: ContainerAppIdentity | undefined);
    private _identityIds?;
    get identityIds(): string[];
    set identityIds(value: string[]);
    resetIdentityIds(): void;
    get identityIdsInput(): string[] | undefined;
    get principalId(): string;
    get tenantId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ContainerAppIngressCustomDomain {
}
export declare function containerAppIngressCustomDomainToTerraform(struct?: ContainerAppIngressCustomDomain): any;
export declare function containerAppIngressCustomDomainToHclTerraform(struct?: ContainerAppIngressCustomDomain): any;
export declare class ContainerAppIngressCustomDomainOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppIngressCustomDomain | undefined;
    set internalValue(value: ContainerAppIngressCustomDomain | undefined);
    get certificateBindingType(): string;
    get certificateId(): string;
    get name(): string;
}
export declare class ContainerAppIngressCustomDomainList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppIngressCustomDomainOutputReference;
}
export interface ContainerAppIngressCors {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#allow_credentials_enabled ContainerApp#allow_credentials_enabled}
    */
    readonly allowCredentialsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#allowed_headers ContainerApp#allowed_headers}
    */
    readonly allowedHeaders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#allowed_methods ContainerApp#allowed_methods}
    */
    readonly allowedMethods?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#allowed_origins ContainerApp#allowed_origins}
    */
    readonly allowedOrigins: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#exposed_headers ContainerApp#exposed_headers}
    */
    readonly exposedHeaders?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#max_age_in_seconds ContainerApp#max_age_in_seconds}
    */
    readonly maxAgeInSeconds?: number;
}
export declare function containerAppIngressCorsToTerraform(struct?: ContainerAppIngressCorsOutputReference | ContainerAppIngressCors): any;
export declare function containerAppIngressCorsToHclTerraform(struct?: ContainerAppIngressCorsOutputReference | ContainerAppIngressCors): any;
export declare class ContainerAppIngressCorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerAppIngressCors | undefined;
    set internalValue(value: ContainerAppIngressCors | undefined);
    private _allowCredentialsEnabled?;
    get allowCredentialsEnabled(): boolean | cdktn.IResolvable;
    set allowCredentialsEnabled(value: boolean | cdktn.IResolvable);
    resetAllowCredentialsEnabled(): void;
    get allowCredentialsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _allowedHeaders?;
    get allowedHeaders(): string[];
    set allowedHeaders(value: string[]);
    resetAllowedHeaders(): void;
    get allowedHeadersInput(): string[] | undefined;
    private _allowedMethods?;
    get allowedMethods(): string[];
    set allowedMethods(value: string[]);
    resetAllowedMethods(): void;
    get allowedMethodsInput(): string[] | undefined;
    private _allowedOrigins?;
    get allowedOrigins(): string[];
    set allowedOrigins(value: string[]);
    get allowedOriginsInput(): string[] | undefined;
    private _exposedHeaders?;
    get exposedHeaders(): string[];
    set exposedHeaders(value: string[]);
    resetExposedHeaders(): void;
    get exposedHeadersInput(): string[] | undefined;
    private _maxAgeInSeconds?;
    get maxAgeInSeconds(): number;
    set maxAgeInSeconds(value: number);
    resetMaxAgeInSeconds(): void;
    get maxAgeInSecondsInput(): number | undefined;
}
export interface ContainerAppIngressIpSecurityRestriction {
    /**
    * The action. Allow or Deny.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#action ContainerApp#action}
    */
    readonly action: string;
    /**
    * Describe the IP restriction rule that is being sent to the container-app.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#description ContainerApp#description}
    */
    readonly description?: string;
    /**
    * The incoming IP address or range of IP addresses (in CIDR notation).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#ip_address_range ContainerApp#ip_address_range}
    */
    readonly ipAddressRange: string;
    /**
    * Name for the IP restriction rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
}
export declare function containerAppIngressIpSecurityRestrictionToTerraform(struct?: ContainerAppIngressIpSecurityRestriction | cdktn.IResolvable): any;
export declare function containerAppIngressIpSecurityRestrictionToHclTerraform(struct?: ContainerAppIngressIpSecurityRestriction | cdktn.IResolvable): any;
export declare class ContainerAppIngressIpSecurityRestrictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppIngressIpSecurityRestriction | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppIngressIpSecurityRestriction | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    get actionInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _ipAddressRange?;
    get ipAddressRange(): string;
    set ipAddressRange(value: string);
    get ipAddressRangeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ContainerAppIngressIpSecurityRestrictionList extends cdktn.ComplexList {
    internalValue?: ContainerAppIngressIpSecurityRestriction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppIngressIpSecurityRestrictionOutputReference;
}
export interface ContainerAppIngressTrafficWeight {
    /**
    * The label to apply to the revision as a name prefix for routing traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#label ContainerApp#label}
    */
    readonly label?: string;
    /**
    * This traffic Weight relates to the latest stable Container Revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#latest_revision ContainerApp#latest_revision}
    */
    readonly latestRevision?: boolean | cdktn.IResolvable;
    /**
    * The percentage of traffic to send to this revision.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#percentage ContainerApp#percentage}
    */
    readonly percentage: number;
    /**
    * The suffix string to append to the revision. This must be unique for the Container App's lifetime. A default hash created by the service will be used if this value is omitted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#revision_suffix ContainerApp#revision_suffix}
    */
    readonly revisionSuffix?: string;
}
export declare function containerAppIngressTrafficWeightToTerraform(struct?: ContainerAppIngressTrafficWeight | cdktn.IResolvable): any;
export declare function containerAppIngressTrafficWeightToHclTerraform(struct?: ContainerAppIngressTrafficWeight | cdktn.IResolvable): any;
export declare class ContainerAppIngressTrafficWeightOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppIngressTrafficWeight | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppIngressTrafficWeight | cdktn.IResolvable | undefined);
    private _label?;
    get label(): string;
    set label(value: string);
    resetLabel(): void;
    get labelInput(): string | undefined;
    private _latestRevision?;
    get latestRevision(): boolean | cdktn.IResolvable;
    set latestRevision(value: boolean | cdktn.IResolvable);
    resetLatestRevision(): void;
    get latestRevisionInput(): boolean | cdktn.IResolvable | undefined;
    private _percentage?;
    get percentage(): number;
    set percentage(value: number);
    get percentageInput(): number | undefined;
    private _revisionSuffix?;
    get revisionSuffix(): string;
    set revisionSuffix(value: string);
    resetRevisionSuffix(): void;
    get revisionSuffixInput(): string | undefined;
}
export declare class ContainerAppIngressTrafficWeightList extends cdktn.ComplexList {
    internalValue?: ContainerAppIngressTrafficWeight[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppIngressTrafficWeightOutputReference;
}
export interface ContainerAppIngress {
    /**
    * Should this ingress allow insecure connections?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#allow_insecure_connections ContainerApp#allow_insecure_connections}
    */
    readonly allowInsecureConnections?: boolean | cdktn.IResolvable;
    /**
    * Client certificate mode for mTLS authentication. Ignore indicates server drops client certificate on forwarding. Accept indicates server forwards client certificate but does not require a client certificate. Require indicates server requires a client certificate.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#client_certificate_mode ContainerApp#client_certificate_mode}
    */
    readonly clientCertificateMode?: string;
    /**
    * The exposed port on the container for the Ingress traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#exposed_port ContainerApp#exposed_port}
    */
    readonly exposedPort?: number;
    /**
    * Is this an external Ingress.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#external_enabled ContainerApp#external_enabled}
    */
    readonly externalEnabled?: boolean | cdktn.IResolvable;
    /**
    * The target port on the container for the Ingress traffic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#target_port ContainerApp#target_port}
    */
    readonly targetPort: number;
    /**
    * The transport method for the Ingress. Possible values include `auto`, `http`, and `http2`, `tcp`. Defaults to `auto`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#transport ContainerApp#transport}
    */
    readonly transport?: string;
    /**
    * cors block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#cors ContainerApp#cors}
    */
    readonly cors?: ContainerAppIngressCors;
    /**
    * ip_security_restriction block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#ip_security_restriction ContainerApp#ip_security_restriction}
    */
    readonly ipSecurityRestriction?: ContainerAppIngressIpSecurityRestriction[] | cdktn.IResolvable;
    /**
    * traffic_weight block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#traffic_weight ContainerApp#traffic_weight}
    */
    readonly trafficWeight: ContainerAppIngressTrafficWeight[] | cdktn.IResolvable;
}
export declare function containerAppIngressToTerraform(struct?: ContainerAppIngressOutputReference | ContainerAppIngress): any;
export declare function containerAppIngressToHclTerraform(struct?: ContainerAppIngressOutputReference | ContainerAppIngress): any;
export declare class ContainerAppIngressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerAppIngress | undefined;
    set internalValue(value: ContainerAppIngress | undefined);
    private _allowInsecureConnections?;
    get allowInsecureConnections(): boolean | cdktn.IResolvable;
    set allowInsecureConnections(value: boolean | cdktn.IResolvable);
    resetAllowInsecureConnections(): void;
    get allowInsecureConnectionsInput(): boolean | cdktn.IResolvable | undefined;
    private _clientCertificateMode?;
    get clientCertificateMode(): string;
    set clientCertificateMode(value: string);
    resetClientCertificateMode(): void;
    get clientCertificateModeInput(): string | undefined;
    private _customDomain;
    get customDomain(): ContainerAppIngressCustomDomainList;
    private _exposedPort?;
    get exposedPort(): number;
    set exposedPort(value: number);
    resetExposedPort(): void;
    get exposedPortInput(): number | undefined;
    private _externalEnabled?;
    get externalEnabled(): boolean | cdktn.IResolvable;
    set externalEnabled(value: boolean | cdktn.IResolvable);
    resetExternalEnabled(): void;
    get externalEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get fqdn(): string;
    private _targetPort?;
    get targetPort(): number;
    set targetPort(value: number);
    get targetPortInput(): number | undefined;
    private _transport?;
    get transport(): string;
    set transport(value: string);
    resetTransport(): void;
    get transportInput(): string | undefined;
    private _cors;
    get cors(): ContainerAppIngressCorsOutputReference;
    putCors(value: ContainerAppIngressCors): void;
    resetCors(): void;
    get corsInput(): ContainerAppIngressCors | undefined;
    private _ipSecurityRestriction;
    get ipSecurityRestriction(): ContainerAppIngressIpSecurityRestrictionList;
    putIpSecurityRestriction(value: ContainerAppIngressIpSecurityRestriction[] | cdktn.IResolvable): void;
    resetIpSecurityRestriction(): void;
    get ipSecurityRestrictionInput(): cdktn.IResolvable | ContainerAppIngressIpSecurityRestriction[] | undefined;
    private _trafficWeight;
    get trafficWeight(): ContainerAppIngressTrafficWeightList;
    putTrafficWeight(value: ContainerAppIngressTrafficWeight[] | cdktn.IResolvable): void;
    get trafficWeightInput(): cdktn.IResolvable | ContainerAppIngressTrafficWeight[] | undefined;
}
export interface ContainerAppRegistry {
    /**
    * ID of the System or User Managed Identity used to pull images from the Container Registry
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#identity ContainerApp#identity}
    */
    readonly identity?: string;
    /**
    * The name of the Secret Reference containing the password value for this user on the Container Registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#password_secret_name ContainerApp#password_secret_name}
    */
    readonly passwordSecretName?: string;
    /**
    * The hostname for the Container Registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#server ContainerApp#server}
    */
    readonly server: string;
    /**
    * The username to use for this Container Registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#username ContainerApp#username}
    */
    readonly username?: string;
}
export declare function containerAppRegistryToTerraform(struct?: ContainerAppRegistry | cdktn.IResolvable): any;
export declare function containerAppRegistryToHclTerraform(struct?: ContainerAppRegistry | cdktn.IResolvable): any;
export declare class ContainerAppRegistryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppRegistry | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppRegistry | cdktn.IResolvable | undefined);
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _passwordSecretName?;
    get passwordSecretName(): string;
    set passwordSecretName(value: string);
    resetPasswordSecretName(): void;
    get passwordSecretNameInput(): string | undefined;
    private _server?;
    get server(): string;
    set server(value: string);
    get serverInput(): string | undefined;
    private _username?;
    get username(): string;
    set username(value: string);
    resetUsername(): void;
    get usernameInput(): string | undefined;
}
export declare class ContainerAppRegistryList extends cdktn.ComplexList {
    internalValue?: ContainerAppRegistry[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppRegistryOutputReference;
}
export interface ContainerAppSecret {
    /**
    * The identity to use for accessing key vault reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#identity ContainerApp#identity}
    */
    readonly identity?: string;
    /**
    * The Key Vault Secret ID. Could be either one of `id` or `versionless_id`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#key_vault_secret_id ContainerApp#key_vault_secret_id}
    */
    readonly keyVaultSecretId?: string;
    /**
    * The secret name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * The value for this secret.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#value ContainerApp#value}
    */
    readonly value?: string;
}
export declare function containerAppSecretToTerraform(struct?: ContainerAppSecret | cdktn.IResolvable): any;
export declare function containerAppSecretToHclTerraform(struct?: ContainerAppSecret | cdktn.IResolvable): any;
export declare class ContainerAppSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppSecret | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppSecret | cdktn.IResolvable | undefined);
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _keyVaultSecretId?;
    get keyVaultSecretId(): string;
    set keyVaultSecretId(value: string);
    resetKeyVaultSecretId(): void;
    get keyVaultSecretIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ContainerAppSecretList extends cdktn.ComplexList {
    internalValue?: ContainerAppSecret[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppSecretOutputReference;
}
export interface ContainerAppTemplateAzureQueueScaleRuleAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#secret_name ContainerApp#secret_name}
    */
    readonly secretName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#trigger_parameter ContainerApp#trigger_parameter}
    */
    readonly triggerParameter: string;
}
export declare function containerAppTemplateAzureQueueScaleRuleAuthenticationToTerraform(struct?: ContainerAppTemplateAzureQueueScaleRuleAuthentication | cdktn.IResolvable): any;
export declare function containerAppTemplateAzureQueueScaleRuleAuthenticationToHclTerraform(struct?: ContainerAppTemplateAzureQueueScaleRuleAuthentication | cdktn.IResolvable): any;
export declare class ContainerAppTemplateAzureQueueScaleRuleAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateAzureQueueScaleRuleAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateAzureQueueScaleRuleAuthentication | cdktn.IResolvable | undefined);
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    private _triggerParameter?;
    get triggerParameter(): string;
    set triggerParameter(value: string);
    get triggerParameterInput(): string | undefined;
}
export declare class ContainerAppTemplateAzureQueueScaleRuleAuthenticationList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateAzureQueueScaleRuleAuthentication[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateAzureQueueScaleRuleAuthenticationOutputReference;
}
export interface ContainerAppTemplateAzureQueueScaleRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#queue_length ContainerApp#queue_length}
    */
    readonly queueLength: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#queue_name ContainerApp#queue_name}
    */
    readonly queueName: string;
    /**
    * authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#authentication ContainerApp#authentication}
    */
    readonly authentication: ContainerAppTemplateAzureQueueScaleRuleAuthentication[] | cdktn.IResolvable;
}
export declare function containerAppTemplateAzureQueueScaleRuleToTerraform(struct?: ContainerAppTemplateAzureQueueScaleRule | cdktn.IResolvable): any;
export declare function containerAppTemplateAzureQueueScaleRuleToHclTerraform(struct?: ContainerAppTemplateAzureQueueScaleRule | cdktn.IResolvable): any;
export declare class ContainerAppTemplateAzureQueueScaleRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateAzureQueueScaleRule | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateAzureQueueScaleRule | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _queueLength?;
    get queueLength(): number;
    set queueLength(value: number);
    get queueLengthInput(): number | undefined;
    private _queueName?;
    get queueName(): string;
    set queueName(value: string);
    get queueNameInput(): string | undefined;
    private _authentication;
    get authentication(): ContainerAppTemplateAzureQueueScaleRuleAuthenticationList;
    putAuthentication(value: ContainerAppTemplateAzureQueueScaleRuleAuthentication[] | cdktn.IResolvable): void;
    get authenticationInput(): cdktn.IResolvable | ContainerAppTemplateAzureQueueScaleRuleAuthentication[] | undefined;
}
export declare class ContainerAppTemplateAzureQueueScaleRuleList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateAzureQueueScaleRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateAzureQueueScaleRuleOutputReference;
}
export interface ContainerAppTemplateContainerEnv {
    /**
    * The name of the environment variable for the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * The name of the secret that contains the value for this environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#secret_name ContainerApp#secret_name}
    */
    readonly secretName?: string;
    /**
    * The value for this environment variable. **NOTE:** This value is ignored if `secret_name` is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#value ContainerApp#value}
    */
    readonly value?: string;
}
export declare function containerAppTemplateContainerEnvToTerraform(struct?: ContainerAppTemplateContainerEnv | cdktn.IResolvable): any;
export declare function containerAppTemplateContainerEnvToHclTerraform(struct?: ContainerAppTemplateContainerEnv | cdktn.IResolvable): any;
export declare class ContainerAppTemplateContainerEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateContainerEnv | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateContainerEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    resetSecretName(): void;
    get secretNameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ContainerAppTemplateContainerEnvList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateContainerEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateContainerEnvOutputReference;
}
export interface ContainerAppTemplateContainerLivenessProbeHeader {
    /**
    * The HTTP Header Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * The HTTP Header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#value ContainerApp#value}
    */
    readonly value: string;
}
export declare function containerAppTemplateContainerLivenessProbeHeaderToTerraform(struct?: ContainerAppTemplateContainerLivenessProbeHeader | cdktn.IResolvable): any;
export declare function containerAppTemplateContainerLivenessProbeHeaderToHclTerraform(struct?: ContainerAppTemplateContainerLivenessProbeHeader | cdktn.IResolvable): any;
export declare class ContainerAppTemplateContainerLivenessProbeHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateContainerLivenessProbeHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateContainerLivenessProbeHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ContainerAppTemplateContainerLivenessProbeHeaderList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateContainerLivenessProbeHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateContainerLivenessProbeHeaderOutputReference;
}
export interface ContainerAppTemplateContainerLivenessProbe {
    /**
    * The number of consecutive failures required to consider this probe as failed. Possible values are between `1` and `30`. Defaults to `3`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#failure_count_threshold ContainerApp#failure_count_threshold}
    */
    readonly failureCountThreshold?: number;
    /**
    * The probe hostname. Defaults to the pod IP address. Setting a value for `Host` in `headers` can be used to override this for `http` and `https` type probes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#host ContainerApp#host}
    */
    readonly host?: string;
    /**
    * The number of seconds elapsed after the container has started before the probe is initiated. Possible values are between `0` and `60`. Defaults to `1` seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#initial_delay ContainerApp#initial_delay}
    */
    readonly initialDelay?: number;
    /**
    * How often, in seconds, the probe should run. Possible values are between `1` and `240`. Defaults to `10`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#interval_seconds ContainerApp#interval_seconds}
    */
    readonly intervalSeconds?: number;
    /**
    * The URI to use with the `host` for http type probes. Not valid for `TCP` type probes. Defaults to `/`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#path ContainerApp#path}
    */
    readonly path?: string;
    /**
    * The port number on which to connect. Possible values are between `1` and `65535`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#port ContainerApp#port}
    */
    readonly port: number;
    /**
    * Time in seconds after which the probe times out. Possible values are between `1` an `240`. Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#timeout ContainerApp#timeout}
    */
    readonly timeout?: number;
    /**
    * Type of probe. Possible values are `TCP`, `HTTP`, and `HTTPS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#transport ContainerApp#transport}
    */
    readonly transport: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#header ContainerApp#header}
    */
    readonly header?: ContainerAppTemplateContainerLivenessProbeHeader[] | cdktn.IResolvable;
}
export declare function containerAppTemplateContainerLivenessProbeToTerraform(struct?: ContainerAppTemplateContainerLivenessProbe | cdktn.IResolvable): any;
export declare function containerAppTemplateContainerLivenessProbeToHclTerraform(struct?: ContainerAppTemplateContainerLivenessProbe | cdktn.IResolvable): any;
export declare class ContainerAppTemplateContainerLivenessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateContainerLivenessProbe | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateContainerLivenessProbe | cdktn.IResolvable | undefined);
    private _failureCountThreshold?;
    get failureCountThreshold(): number;
    set failureCountThreshold(value: number);
    resetFailureCountThreshold(): void;
    get failureCountThresholdInput(): number | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _initialDelay?;
    get initialDelay(): number;
    set initialDelay(value: number);
    resetInitialDelay(): void;
    get initialDelayInput(): number | undefined;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    resetIntervalSeconds(): void;
    get intervalSecondsInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _transport?;
    get transport(): string;
    set transport(value: string);
    get transportInput(): string | undefined;
    private _header;
    get header(): ContainerAppTemplateContainerLivenessProbeHeaderList;
    putHeader(value: ContainerAppTemplateContainerLivenessProbeHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | ContainerAppTemplateContainerLivenessProbeHeader[] | undefined;
}
export declare class ContainerAppTemplateContainerLivenessProbeList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateContainerLivenessProbe[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateContainerLivenessProbeOutputReference;
}
export interface ContainerAppTemplateContainerReadinessProbeHeader {
    /**
    * The HTTP Header Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * The HTTP Header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#value ContainerApp#value}
    */
    readonly value: string;
}
export declare function containerAppTemplateContainerReadinessProbeHeaderToTerraform(struct?: ContainerAppTemplateContainerReadinessProbeHeader | cdktn.IResolvable): any;
export declare function containerAppTemplateContainerReadinessProbeHeaderToHclTerraform(struct?: ContainerAppTemplateContainerReadinessProbeHeader | cdktn.IResolvable): any;
export declare class ContainerAppTemplateContainerReadinessProbeHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateContainerReadinessProbeHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateContainerReadinessProbeHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ContainerAppTemplateContainerReadinessProbeHeaderList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateContainerReadinessProbeHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateContainerReadinessProbeHeaderOutputReference;
}
export interface ContainerAppTemplateContainerReadinessProbe {
    /**
    * The number of consecutive failures required to consider this probe as failed. Possible values are between `1` and `48`. Defaults to `3`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#failure_count_threshold ContainerApp#failure_count_threshold}
    */
    readonly failureCountThreshold?: number;
    /**
    * The probe hostname. Defaults to the pod IP address. Setting a value for `Host` in `headers` can be used to override this for `http` and `https` type probes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#host ContainerApp#host}
    */
    readonly host?: string;
    /**
    * The number of seconds elapsed after the container has started before the probe is initiated. Possible values are between `0` and `60`. Defaults to `0` seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#initial_delay ContainerApp#initial_delay}
    */
    readonly initialDelay?: number;
    /**
    * How often, in seconds, the probe should run. Possible values are between `1` and `240`. Defaults to `10`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#interval_seconds ContainerApp#interval_seconds}
    */
    readonly intervalSeconds?: number;
    /**
    * The URI to use for http type probes. Not valid for `TCP` type probes. Defaults to `/`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#path ContainerApp#path}
    */
    readonly path?: string;
    /**
    * The port number on which to connect. Possible values are between `1` and `65535`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#port ContainerApp#port}
    */
    readonly port: number;
    /**
    * The number of consecutive successful responses required to consider this probe as successful. Possible values are between `1` and `10`. Defaults to `3`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#success_count_threshold ContainerApp#success_count_threshold}
    */
    readonly successCountThreshold?: number;
    /**
    * Time in seconds after which the probe times out. Possible values are between `1` an `240`. Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#timeout ContainerApp#timeout}
    */
    readonly timeout?: number;
    /**
    * Type of probe. Possible values are `TCP`, `HTTP`, and `HTTPS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#transport ContainerApp#transport}
    */
    readonly transport: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#header ContainerApp#header}
    */
    readonly header?: ContainerAppTemplateContainerReadinessProbeHeader[] | cdktn.IResolvable;
}
export declare function containerAppTemplateContainerReadinessProbeToTerraform(struct?: ContainerAppTemplateContainerReadinessProbe | cdktn.IResolvable): any;
export declare function containerAppTemplateContainerReadinessProbeToHclTerraform(struct?: ContainerAppTemplateContainerReadinessProbe | cdktn.IResolvable): any;
export declare class ContainerAppTemplateContainerReadinessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateContainerReadinessProbe | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateContainerReadinessProbe | cdktn.IResolvable | undefined);
    private _failureCountThreshold?;
    get failureCountThreshold(): number;
    set failureCountThreshold(value: number);
    resetFailureCountThreshold(): void;
    get failureCountThresholdInput(): number | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _initialDelay?;
    get initialDelay(): number;
    set initialDelay(value: number);
    resetInitialDelay(): void;
    get initialDelayInput(): number | undefined;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    resetIntervalSeconds(): void;
    get intervalSecondsInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _successCountThreshold?;
    get successCountThreshold(): number;
    set successCountThreshold(value: number);
    resetSuccessCountThreshold(): void;
    get successCountThresholdInput(): number | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _transport?;
    get transport(): string;
    set transport(value: string);
    get transportInput(): string | undefined;
    private _header;
    get header(): ContainerAppTemplateContainerReadinessProbeHeaderList;
    putHeader(value: ContainerAppTemplateContainerReadinessProbeHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | ContainerAppTemplateContainerReadinessProbeHeader[] | undefined;
}
export declare class ContainerAppTemplateContainerReadinessProbeList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateContainerReadinessProbe[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateContainerReadinessProbeOutputReference;
}
export interface ContainerAppTemplateContainerStartupProbeHeader {
    /**
    * The HTTP Header Name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * The HTTP Header value.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#value ContainerApp#value}
    */
    readonly value: string;
}
export declare function containerAppTemplateContainerStartupProbeHeaderToTerraform(struct?: ContainerAppTemplateContainerStartupProbeHeader | cdktn.IResolvable): any;
export declare function containerAppTemplateContainerStartupProbeHeaderToHclTerraform(struct?: ContainerAppTemplateContainerStartupProbeHeader | cdktn.IResolvable): any;
export declare class ContainerAppTemplateContainerStartupProbeHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateContainerStartupProbeHeader | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateContainerStartupProbeHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ContainerAppTemplateContainerStartupProbeHeaderList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateContainerStartupProbeHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateContainerStartupProbeHeaderOutputReference;
}
export interface ContainerAppTemplateContainerStartupProbe {
    /**
    * The number of consecutive failures required to consider this probe as failed. Possible values are between `1` and `240`. Defaults to `3`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#failure_count_threshold ContainerApp#failure_count_threshold}
    */
    readonly failureCountThreshold?: number;
    /**
    * The probe hostname. Defaults to the pod IP address. Setting a value for `Host` in `headers` can be used to override this for `http` and `https` type probes.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#host ContainerApp#host}
    */
    readonly host?: string;
    /**
    * The number of seconds elapsed after the container has started before the probe is initiated. Possible values are between `0` and `60`. Defaults to `0` seconds.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#initial_delay ContainerApp#initial_delay}
    */
    readonly initialDelay?: number;
    /**
    * How often, in seconds, the probe should run. Possible values are between `1` and `240`. Defaults to `10`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#interval_seconds ContainerApp#interval_seconds}
    */
    readonly intervalSeconds?: number;
    /**
    * The URI to use with the `host` for http type probes. Not valid for `TCP` type probes. Defaults to `/`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#path ContainerApp#path}
    */
    readonly path?: string;
    /**
    * The port number on which to connect. Possible values are between `1` and `65535`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#port ContainerApp#port}
    */
    readonly port: number;
    /**
    * Time in seconds after which the probe times out. Possible values are between `1` an `240`. Defaults to `1`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#timeout ContainerApp#timeout}
    */
    readonly timeout?: number;
    /**
    * Type of probe. Possible values are `TCP`, `HTTP`, and `HTTPS`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#transport ContainerApp#transport}
    */
    readonly transport: string;
    /**
    * header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#header ContainerApp#header}
    */
    readonly header?: ContainerAppTemplateContainerStartupProbeHeader[] | cdktn.IResolvable;
}
export declare function containerAppTemplateContainerStartupProbeToTerraform(struct?: ContainerAppTemplateContainerStartupProbe | cdktn.IResolvable): any;
export declare function containerAppTemplateContainerStartupProbeToHclTerraform(struct?: ContainerAppTemplateContainerStartupProbe | cdktn.IResolvable): any;
export declare class ContainerAppTemplateContainerStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateContainerStartupProbe | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateContainerStartupProbe | cdktn.IResolvable | undefined);
    private _failureCountThreshold?;
    get failureCountThreshold(): number;
    set failureCountThreshold(value: number);
    resetFailureCountThreshold(): void;
    get failureCountThresholdInput(): number | undefined;
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    private _initialDelay?;
    get initialDelay(): number;
    set initialDelay(value: number);
    resetInitialDelay(): void;
    get initialDelayInput(): number | undefined;
    private _intervalSeconds?;
    get intervalSeconds(): number;
    set intervalSeconds(value: number);
    resetIntervalSeconds(): void;
    get intervalSecondsInput(): number | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    resetTimeout(): void;
    get timeoutInput(): number | undefined;
    private _transport?;
    get transport(): string;
    set transport(value: string);
    get transportInput(): string | undefined;
    private _header;
    get header(): ContainerAppTemplateContainerStartupProbeHeaderList;
    putHeader(value: ContainerAppTemplateContainerStartupProbeHeader[] | cdktn.IResolvable): void;
    resetHeader(): void;
    get headerInput(): cdktn.IResolvable | ContainerAppTemplateContainerStartupProbeHeader[] | undefined;
}
export declare class ContainerAppTemplateContainerStartupProbeList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateContainerStartupProbe[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateContainerStartupProbeOutputReference;
}
export interface ContainerAppTemplateContainerVolumeMounts {
    /**
    * The name of the Volume to be mounted in the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * The path in the container at which to mount this volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#path ContainerApp#path}
    */
    readonly path: string;
    /**
    * The sub path of the volume to be mounted in the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#sub_path ContainerApp#sub_path}
    */
    readonly subPath?: string;
}
export declare function containerAppTemplateContainerVolumeMountsToTerraform(struct?: ContainerAppTemplateContainerVolumeMounts | cdktn.IResolvable): any;
export declare function containerAppTemplateContainerVolumeMountsToHclTerraform(struct?: ContainerAppTemplateContainerVolumeMounts | cdktn.IResolvable): any;
export declare class ContainerAppTemplateContainerVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateContainerVolumeMounts | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateContainerVolumeMounts | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
}
export declare class ContainerAppTemplateContainerVolumeMountsList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateContainerVolumeMounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateContainerVolumeMountsOutputReference;
}
export interface ContainerAppTemplateContainer {
    /**
    * A list of args to pass to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#args ContainerApp#args}
    */
    readonly args?: string[];
    /**
    * A command to pass to the container to override the default. This is provided as a list of command line elements without spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#command ContainerApp#command}
    */
    readonly command?: string[];
    /**
    * The amount of vCPU to allocate to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#cpu ContainerApp#cpu}
    */
    readonly cpu: number;
    /**
    * The image to use to create the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#image ContainerApp#image}
    */
    readonly image: string;
    /**
    * The amount of memory to allocate to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#memory ContainerApp#memory}
    */
    readonly memory: string;
    /**
    * The name of the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#env ContainerApp#env}
    */
    readonly env?: ContainerAppTemplateContainerEnv[] | cdktn.IResolvable;
    /**
    * liveness_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#liveness_probe ContainerApp#liveness_probe}
    */
    readonly livenessProbe?: ContainerAppTemplateContainerLivenessProbe[] | cdktn.IResolvable;
    /**
    * readiness_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#readiness_probe ContainerApp#readiness_probe}
    */
    readonly readinessProbe?: ContainerAppTemplateContainerReadinessProbe[] | cdktn.IResolvable;
    /**
    * startup_probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#startup_probe ContainerApp#startup_probe}
    */
    readonly startupProbe?: ContainerAppTemplateContainerStartupProbe[] | cdktn.IResolvable;
    /**
    * volume_mounts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#volume_mounts ContainerApp#volume_mounts}
    */
    readonly volumeMounts?: ContainerAppTemplateContainerVolumeMounts[] | cdktn.IResolvable;
}
export declare function containerAppTemplateContainerToTerraform(struct?: ContainerAppTemplateContainer | cdktn.IResolvable): any;
export declare function containerAppTemplateContainerToHclTerraform(struct?: ContainerAppTemplateContainer | cdktn.IResolvable): any;
export declare class ContainerAppTemplateContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateContainer | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateContainer | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _cpu?;
    get cpu(): number;
    set cpu(value: number);
    get cpuInput(): number | undefined;
    get ephemeralStorage(): string;
    private _image?;
    get image(): string;
    set image(value: string);
    get imageInput(): string | undefined;
    private _memory?;
    get memory(): string;
    set memory(value: string);
    get memoryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _env;
    get env(): ContainerAppTemplateContainerEnvList;
    putEnv(value: ContainerAppTemplateContainerEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | ContainerAppTemplateContainerEnv[] | undefined;
    private _livenessProbe;
    get livenessProbe(): ContainerAppTemplateContainerLivenessProbeList;
    putLivenessProbe(value: ContainerAppTemplateContainerLivenessProbe[] | cdktn.IResolvable): void;
    resetLivenessProbe(): void;
    get livenessProbeInput(): cdktn.IResolvable | ContainerAppTemplateContainerLivenessProbe[] | undefined;
    private _readinessProbe;
    get readinessProbe(): ContainerAppTemplateContainerReadinessProbeList;
    putReadinessProbe(value: ContainerAppTemplateContainerReadinessProbe[] | cdktn.IResolvable): void;
    resetReadinessProbe(): void;
    get readinessProbeInput(): cdktn.IResolvable | ContainerAppTemplateContainerReadinessProbe[] | undefined;
    private _startupProbe;
    get startupProbe(): ContainerAppTemplateContainerStartupProbeList;
    putStartupProbe(value: ContainerAppTemplateContainerStartupProbe[] | cdktn.IResolvable): void;
    resetStartupProbe(): void;
    get startupProbeInput(): cdktn.IResolvable | ContainerAppTemplateContainerStartupProbe[] | undefined;
    private _volumeMounts;
    get volumeMounts(): ContainerAppTemplateContainerVolumeMountsList;
    putVolumeMounts(value: ContainerAppTemplateContainerVolumeMounts[] | cdktn.IResolvable): void;
    resetVolumeMounts(): void;
    get volumeMountsInput(): cdktn.IResolvable | ContainerAppTemplateContainerVolumeMounts[] | undefined;
}
export declare class ContainerAppTemplateContainerList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateContainer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateContainerOutputReference;
}
export interface ContainerAppTemplateCustomScaleRuleAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#secret_name ContainerApp#secret_name}
    */
    readonly secretName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#trigger_parameter ContainerApp#trigger_parameter}
    */
    readonly triggerParameter: string;
}
export declare function containerAppTemplateCustomScaleRuleAuthenticationToTerraform(struct?: ContainerAppTemplateCustomScaleRuleAuthentication | cdktn.IResolvable): any;
export declare function containerAppTemplateCustomScaleRuleAuthenticationToHclTerraform(struct?: ContainerAppTemplateCustomScaleRuleAuthentication | cdktn.IResolvable): any;
export declare class ContainerAppTemplateCustomScaleRuleAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateCustomScaleRuleAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateCustomScaleRuleAuthentication | cdktn.IResolvable | undefined);
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    private _triggerParameter?;
    get triggerParameter(): string;
    set triggerParameter(value: string);
    get triggerParameterInput(): string | undefined;
}
export declare class ContainerAppTemplateCustomScaleRuleAuthenticationList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateCustomScaleRuleAuthentication[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateCustomScaleRuleAuthenticationOutputReference;
}
export interface ContainerAppTemplateCustomScaleRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#custom_rule_type ContainerApp#custom_rule_type}
    */
    readonly customRuleType: string;
    /**
    * ID of the System or User Managed Identity used to execute scale rule.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#identity_id ContainerApp#identity_id}
    */
    readonly identityId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#metadata ContainerApp#metadata}
    */
    readonly metadata: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#authentication ContainerApp#authentication}
    */
    readonly authentication?: ContainerAppTemplateCustomScaleRuleAuthentication[] | cdktn.IResolvable;
}
export declare function containerAppTemplateCustomScaleRuleToTerraform(struct?: ContainerAppTemplateCustomScaleRule | cdktn.IResolvable): any;
export declare function containerAppTemplateCustomScaleRuleToHclTerraform(struct?: ContainerAppTemplateCustomScaleRule | cdktn.IResolvable): any;
export declare class ContainerAppTemplateCustomScaleRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateCustomScaleRule | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateCustomScaleRule | cdktn.IResolvable | undefined);
    private _customRuleType?;
    get customRuleType(): string;
    set customRuleType(value: string);
    get customRuleTypeInput(): string | undefined;
    private _identityId?;
    get identityId(): string;
    set identityId(value: string);
    resetIdentityId(): void;
    get identityIdInput(): string | undefined;
    private _metadata?;
    get metadata(): {
        [key: string]: string;
    };
    set metadata(value: {
        [key: string]: string;
    });
    get metadataInput(): {
        [key: string]: string;
    } | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _authentication;
    get authentication(): ContainerAppTemplateCustomScaleRuleAuthenticationList;
    putAuthentication(value: ContainerAppTemplateCustomScaleRuleAuthentication[] | cdktn.IResolvable): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | ContainerAppTemplateCustomScaleRuleAuthentication[] | undefined;
}
export declare class ContainerAppTemplateCustomScaleRuleList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateCustomScaleRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateCustomScaleRuleOutputReference;
}
export interface ContainerAppTemplateHttpScaleRuleAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#secret_name ContainerApp#secret_name}
    */
    readonly secretName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#trigger_parameter ContainerApp#trigger_parameter}
    */
    readonly triggerParameter?: string;
}
export declare function containerAppTemplateHttpScaleRuleAuthenticationToTerraform(struct?: ContainerAppTemplateHttpScaleRuleAuthentication | cdktn.IResolvable): any;
export declare function containerAppTemplateHttpScaleRuleAuthenticationToHclTerraform(struct?: ContainerAppTemplateHttpScaleRuleAuthentication | cdktn.IResolvable): any;
export declare class ContainerAppTemplateHttpScaleRuleAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateHttpScaleRuleAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateHttpScaleRuleAuthentication | cdktn.IResolvable | undefined);
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    private _triggerParameter?;
    get triggerParameter(): string;
    set triggerParameter(value: string);
    resetTriggerParameter(): void;
    get triggerParameterInput(): string | undefined;
}
export declare class ContainerAppTemplateHttpScaleRuleAuthenticationList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateHttpScaleRuleAuthentication[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateHttpScaleRuleAuthenticationOutputReference;
}
export interface ContainerAppTemplateHttpScaleRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#concurrent_requests ContainerApp#concurrent_requests}
    */
    readonly concurrentRequests: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#authentication ContainerApp#authentication}
    */
    readonly authentication?: ContainerAppTemplateHttpScaleRuleAuthentication[] | cdktn.IResolvable;
}
export declare function containerAppTemplateHttpScaleRuleToTerraform(struct?: ContainerAppTemplateHttpScaleRule | cdktn.IResolvable): any;
export declare function containerAppTemplateHttpScaleRuleToHclTerraform(struct?: ContainerAppTemplateHttpScaleRule | cdktn.IResolvable): any;
export declare class ContainerAppTemplateHttpScaleRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateHttpScaleRule | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateHttpScaleRule | cdktn.IResolvable | undefined);
    private _concurrentRequests?;
    get concurrentRequests(): string;
    set concurrentRequests(value: string);
    get concurrentRequestsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _authentication;
    get authentication(): ContainerAppTemplateHttpScaleRuleAuthenticationList;
    putAuthentication(value: ContainerAppTemplateHttpScaleRuleAuthentication[] | cdktn.IResolvable): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | ContainerAppTemplateHttpScaleRuleAuthentication[] | undefined;
}
export declare class ContainerAppTemplateHttpScaleRuleList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateHttpScaleRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateHttpScaleRuleOutputReference;
}
export interface ContainerAppTemplateInitContainerEnv {
    /**
    * The name of the environment variable for the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * The name of the secret that contains the value for this environment variable.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#secret_name ContainerApp#secret_name}
    */
    readonly secretName?: string;
    /**
    * The value for this environment variable. **NOTE:** This value is ignored if `secret_name` is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#value ContainerApp#value}
    */
    readonly value?: string;
}
export declare function containerAppTemplateInitContainerEnvToTerraform(struct?: ContainerAppTemplateInitContainerEnv | cdktn.IResolvable): any;
export declare function containerAppTemplateInitContainerEnvToHclTerraform(struct?: ContainerAppTemplateInitContainerEnv | cdktn.IResolvable): any;
export declare class ContainerAppTemplateInitContainerEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateInitContainerEnv | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateInitContainerEnv | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    resetSecretName(): void;
    get secretNameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
}
export declare class ContainerAppTemplateInitContainerEnvList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateInitContainerEnv[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateInitContainerEnvOutputReference;
}
export interface ContainerAppTemplateInitContainerVolumeMounts {
    /**
    * The name of the Volume to be mounted in the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * The path in the container at which to mount this volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#path ContainerApp#path}
    */
    readonly path: string;
    /**
    * The sub path of the volume to be mounted in the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#sub_path ContainerApp#sub_path}
    */
    readonly subPath?: string;
}
export declare function containerAppTemplateInitContainerVolumeMountsToTerraform(struct?: ContainerAppTemplateInitContainerVolumeMounts | cdktn.IResolvable): any;
export declare function containerAppTemplateInitContainerVolumeMountsToHclTerraform(struct?: ContainerAppTemplateInitContainerVolumeMounts | cdktn.IResolvable): any;
export declare class ContainerAppTemplateInitContainerVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateInitContainerVolumeMounts | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateInitContainerVolumeMounts | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    private _subPath?;
    get subPath(): string;
    set subPath(value: string);
    resetSubPath(): void;
    get subPathInput(): string | undefined;
}
export declare class ContainerAppTemplateInitContainerVolumeMountsList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateInitContainerVolumeMounts[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateInitContainerVolumeMountsOutputReference;
}
export interface ContainerAppTemplateInitContainer {
    /**
    * A list of args to pass to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#args ContainerApp#args}
    */
    readonly args?: string[];
    /**
    * A command to pass to the container to override the default. This is provided as a list of command line elements without spaces.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#command ContainerApp#command}
    */
    readonly command?: string[];
    /**
    * The amount of vCPU to allocate to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#cpu ContainerApp#cpu}
    */
    readonly cpu?: number;
    /**
    * The image to use to create the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#image ContainerApp#image}
    */
    readonly image: string;
    /**
    * The amount of memory to allocate to the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#memory ContainerApp#memory}
    */
    readonly memory?: string;
    /**
    * The name of the container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * env block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#env ContainerApp#env}
    */
    readonly env?: ContainerAppTemplateInitContainerEnv[] | cdktn.IResolvable;
    /**
    * volume_mounts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#volume_mounts ContainerApp#volume_mounts}
    */
    readonly volumeMounts?: ContainerAppTemplateInitContainerVolumeMounts[] | cdktn.IResolvable;
}
export declare function containerAppTemplateInitContainerToTerraform(struct?: ContainerAppTemplateInitContainer | cdktn.IResolvable): any;
export declare function containerAppTemplateInitContainerToHclTerraform(struct?: ContainerAppTemplateInitContainer | cdktn.IResolvable): any;
export declare class ContainerAppTemplateInitContainerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateInitContainer | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateInitContainer | cdktn.IResolvable | undefined);
    private _args?;
    get args(): string[];
    set args(value: string[]);
    resetArgs(): void;
    get argsInput(): string[] | undefined;
    private _command?;
    get command(): string[];
    set command(value: string[]);
    resetCommand(): void;
    get commandInput(): string[] | undefined;
    private _cpu?;
    get cpu(): number;
    set cpu(value: number);
    resetCpu(): void;
    get cpuInput(): number | undefined;
    get ephemeralStorage(): string;
    private _image?;
    get image(): string;
    set image(value: string);
    get imageInput(): string | undefined;
    private _memory?;
    get memory(): string;
    set memory(value: string);
    resetMemory(): void;
    get memoryInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _env;
    get env(): ContainerAppTemplateInitContainerEnvList;
    putEnv(value: ContainerAppTemplateInitContainerEnv[] | cdktn.IResolvable): void;
    resetEnv(): void;
    get envInput(): cdktn.IResolvable | ContainerAppTemplateInitContainerEnv[] | undefined;
    private _volumeMounts;
    get volumeMounts(): ContainerAppTemplateInitContainerVolumeMountsList;
    putVolumeMounts(value: ContainerAppTemplateInitContainerVolumeMounts[] | cdktn.IResolvable): void;
    resetVolumeMounts(): void;
    get volumeMountsInput(): cdktn.IResolvable | ContainerAppTemplateInitContainerVolumeMounts[] | undefined;
}
export declare class ContainerAppTemplateInitContainerList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateInitContainer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateInitContainerOutputReference;
}
export interface ContainerAppTemplateTcpScaleRuleAuthentication {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#secret_name ContainerApp#secret_name}
    */
    readonly secretName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#trigger_parameter ContainerApp#trigger_parameter}
    */
    readonly triggerParameter?: string;
}
export declare function containerAppTemplateTcpScaleRuleAuthenticationToTerraform(struct?: ContainerAppTemplateTcpScaleRuleAuthentication | cdktn.IResolvable): any;
export declare function containerAppTemplateTcpScaleRuleAuthenticationToHclTerraform(struct?: ContainerAppTemplateTcpScaleRuleAuthentication | cdktn.IResolvable): any;
export declare class ContainerAppTemplateTcpScaleRuleAuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateTcpScaleRuleAuthentication | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateTcpScaleRuleAuthentication | cdktn.IResolvable | undefined);
    private _secretName?;
    get secretName(): string;
    set secretName(value: string);
    get secretNameInput(): string | undefined;
    private _triggerParameter?;
    get triggerParameter(): string;
    set triggerParameter(value: string);
    resetTriggerParameter(): void;
    get triggerParameterInput(): string | undefined;
}
export declare class ContainerAppTemplateTcpScaleRuleAuthenticationList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateTcpScaleRuleAuthentication[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateTcpScaleRuleAuthenticationOutputReference;
}
export interface ContainerAppTemplateTcpScaleRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#concurrent_requests ContainerApp#concurrent_requests}
    */
    readonly concurrentRequests: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * authentication block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#authentication ContainerApp#authentication}
    */
    readonly authentication?: ContainerAppTemplateTcpScaleRuleAuthentication[] | cdktn.IResolvable;
}
export declare function containerAppTemplateTcpScaleRuleToTerraform(struct?: ContainerAppTemplateTcpScaleRule | cdktn.IResolvable): any;
export declare function containerAppTemplateTcpScaleRuleToHclTerraform(struct?: ContainerAppTemplateTcpScaleRule | cdktn.IResolvable): any;
export declare class ContainerAppTemplateTcpScaleRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateTcpScaleRule | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateTcpScaleRule | cdktn.IResolvable | undefined);
    private _concurrentRequests?;
    get concurrentRequests(): string;
    set concurrentRequests(value: string);
    get concurrentRequestsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _authentication;
    get authentication(): ContainerAppTemplateTcpScaleRuleAuthenticationList;
    putAuthentication(value: ContainerAppTemplateTcpScaleRuleAuthentication[] | cdktn.IResolvable): void;
    resetAuthentication(): void;
    get authenticationInput(): cdktn.IResolvable | ContainerAppTemplateTcpScaleRuleAuthentication[] | undefined;
}
export declare class ContainerAppTemplateTcpScaleRuleList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateTcpScaleRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateTcpScaleRuleOutputReference;
}
export interface ContainerAppTemplateVolume {
    /**
    * Mount options used while mounting the AzureFile. Must be a comma-separated string.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#mount_options ContainerApp#mount_options}
    */
    readonly mountOptions?: string;
    /**
    * The name of the volume.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#name ContainerApp#name}
    */
    readonly name: string;
    /**
    * The name of the `AzureFile` storage. Required when `storage_type` is `AzureFile`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#storage_name ContainerApp#storage_name}
    */
    readonly storageName?: string;
    /**
    * The type of storage volume. Possible values include `AzureFile` and `EmptyDir`. Defaults to `EmptyDir`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#storage_type ContainerApp#storage_type}
    */
    readonly storageType?: string;
}
export declare function containerAppTemplateVolumeToTerraform(struct?: ContainerAppTemplateVolume | cdktn.IResolvable): any;
export declare function containerAppTemplateVolumeToHclTerraform(struct?: ContainerAppTemplateVolume | cdktn.IResolvable): any;
export declare class ContainerAppTemplateVolumeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerAppTemplateVolume | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTemplateVolume | cdktn.IResolvable | undefined);
    private _mountOptions?;
    get mountOptions(): string;
    set mountOptions(value: string);
    resetMountOptions(): void;
    get mountOptionsInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storageName?;
    get storageName(): string;
    set storageName(value: string);
    resetStorageName(): void;
    get storageNameInput(): string | undefined;
    private _storageType?;
    get storageType(): string;
    set storageType(value: string);
    resetStorageType(): void;
    get storageTypeInput(): string | undefined;
}
export declare class ContainerAppTemplateVolumeList extends cdktn.ComplexList {
    internalValue?: ContainerAppTemplateVolume[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerAppTemplateVolumeOutputReference;
}
export interface ContainerAppTemplate {
    /**
    * The number of seconds to wait before scaling down the number of instances again.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#cooldown_period_in_seconds ContainerApp#cooldown_period_in_seconds}
    */
    readonly cooldownPeriodInSeconds?: number;
    /**
    * The maximum number of replicas for this container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#max_replicas ContainerApp#max_replicas}
    */
    readonly maxReplicas?: number;
    /**
    * The minimum number of replicas for this container.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#min_replicas ContainerApp#min_replicas}
    */
    readonly minReplicas?: number;
    /**
    * The interval in seconds used for polling KEDA.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#polling_interval_in_seconds ContainerApp#polling_interval_in_seconds}
    */
    readonly pollingIntervalInSeconds?: number;
    /**
    * The suffix for the revision. This value must be unique for the lifetime of the Resource. If omitted the service will use a hash function to create one.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#revision_suffix ContainerApp#revision_suffix}
    */
    readonly revisionSuffix?: string;
    /**
    * The time in seconds after the container is sent the termination signal before the process if forcibly killed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#termination_grace_period_seconds ContainerApp#termination_grace_period_seconds}
    */
    readonly terminationGracePeriodSeconds?: number;
    /**
    * azure_queue_scale_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#azure_queue_scale_rule ContainerApp#azure_queue_scale_rule}
    */
    readonly azureQueueScaleRule?: ContainerAppTemplateAzureQueueScaleRule[] | cdktn.IResolvable;
    /**
    * container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#container ContainerApp#container}
    */
    readonly container: ContainerAppTemplateContainer[] | cdktn.IResolvable;
    /**
    * custom_scale_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#custom_scale_rule ContainerApp#custom_scale_rule}
    */
    readonly customScaleRule?: ContainerAppTemplateCustomScaleRule[] | cdktn.IResolvable;
    /**
    * http_scale_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#http_scale_rule ContainerApp#http_scale_rule}
    */
    readonly httpScaleRule?: ContainerAppTemplateHttpScaleRule[] | cdktn.IResolvable;
    /**
    * init_container block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#init_container ContainerApp#init_container}
    */
    readonly initContainer?: ContainerAppTemplateInitContainer[] | cdktn.IResolvable;
    /**
    * tcp_scale_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#tcp_scale_rule ContainerApp#tcp_scale_rule}
    */
    readonly tcpScaleRule?: ContainerAppTemplateTcpScaleRule[] | cdktn.IResolvable;
    /**
    * volume block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#volume ContainerApp#volume}
    */
    readonly volume?: ContainerAppTemplateVolume[] | cdktn.IResolvable;
}
export declare function containerAppTemplateToTerraform(struct?: ContainerAppTemplateOutputReference | ContainerAppTemplate): any;
export declare function containerAppTemplateToHclTerraform(struct?: ContainerAppTemplateOutputReference | ContainerAppTemplate): any;
export declare class ContainerAppTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerAppTemplate | undefined;
    set internalValue(value: ContainerAppTemplate | undefined);
    private _cooldownPeriodInSeconds?;
    get cooldownPeriodInSeconds(): number;
    set cooldownPeriodInSeconds(value: number);
    resetCooldownPeriodInSeconds(): void;
    get cooldownPeriodInSecondsInput(): number | undefined;
    private _maxReplicas?;
    get maxReplicas(): number;
    set maxReplicas(value: number);
    resetMaxReplicas(): void;
    get maxReplicasInput(): number | undefined;
    private _minReplicas?;
    get minReplicas(): number;
    set minReplicas(value: number);
    resetMinReplicas(): void;
    get minReplicasInput(): number | undefined;
    private _pollingIntervalInSeconds?;
    get pollingIntervalInSeconds(): number;
    set pollingIntervalInSeconds(value: number);
    resetPollingIntervalInSeconds(): void;
    get pollingIntervalInSecondsInput(): number | undefined;
    private _revisionSuffix?;
    get revisionSuffix(): string;
    set revisionSuffix(value: string);
    resetRevisionSuffix(): void;
    get revisionSuffixInput(): string | undefined;
    private _terminationGracePeriodSeconds?;
    get terminationGracePeriodSeconds(): number;
    set terminationGracePeriodSeconds(value: number);
    resetTerminationGracePeriodSeconds(): void;
    get terminationGracePeriodSecondsInput(): number | undefined;
    private _azureQueueScaleRule;
    get azureQueueScaleRule(): ContainerAppTemplateAzureQueueScaleRuleList;
    putAzureQueueScaleRule(value: ContainerAppTemplateAzureQueueScaleRule[] | cdktn.IResolvable): void;
    resetAzureQueueScaleRule(): void;
    get azureQueueScaleRuleInput(): cdktn.IResolvable | ContainerAppTemplateAzureQueueScaleRule[] | undefined;
    private _container;
    get container(): ContainerAppTemplateContainerList;
    putContainer(value: ContainerAppTemplateContainer[] | cdktn.IResolvable): void;
    get containerInput(): cdktn.IResolvable | ContainerAppTemplateContainer[] | undefined;
    private _customScaleRule;
    get customScaleRule(): ContainerAppTemplateCustomScaleRuleList;
    putCustomScaleRule(value: ContainerAppTemplateCustomScaleRule[] | cdktn.IResolvable): void;
    resetCustomScaleRule(): void;
    get customScaleRuleInput(): cdktn.IResolvable | ContainerAppTemplateCustomScaleRule[] | undefined;
    private _httpScaleRule;
    get httpScaleRule(): ContainerAppTemplateHttpScaleRuleList;
    putHttpScaleRule(value: ContainerAppTemplateHttpScaleRule[] | cdktn.IResolvable): void;
    resetHttpScaleRule(): void;
    get httpScaleRuleInput(): cdktn.IResolvable | ContainerAppTemplateHttpScaleRule[] | undefined;
    private _initContainer;
    get initContainer(): ContainerAppTemplateInitContainerList;
    putInitContainer(value: ContainerAppTemplateInitContainer[] | cdktn.IResolvable): void;
    resetInitContainer(): void;
    get initContainerInput(): cdktn.IResolvable | ContainerAppTemplateInitContainer[] | undefined;
    private _tcpScaleRule;
    get tcpScaleRule(): ContainerAppTemplateTcpScaleRuleList;
    putTcpScaleRule(value: ContainerAppTemplateTcpScaleRule[] | cdktn.IResolvable): void;
    resetTcpScaleRule(): void;
    get tcpScaleRuleInput(): cdktn.IResolvable | ContainerAppTemplateTcpScaleRule[] | undefined;
    private _volume;
    get volume(): ContainerAppTemplateVolumeList;
    putVolume(value: ContainerAppTemplateVolume[] | cdktn.IResolvable): void;
    resetVolume(): void;
    get volumeInput(): cdktn.IResolvable | ContainerAppTemplateVolume[] | undefined;
}
export interface ContainerAppTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#create ContainerApp#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#delete ContainerApp#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#read ContainerApp#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#update ContainerApp#update}
    */
    readonly update?: string;
}
export declare function containerAppTimeoutsToTerraform(struct?: ContainerAppTimeouts | cdktn.IResolvable): any;
export declare function containerAppTimeoutsToHclTerraform(struct?: ContainerAppTimeouts | cdktn.IResolvable): any;
export declare class ContainerAppTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerAppTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app azurerm_container_app}
*/
export declare class ContainerApp extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_container_app";
    /**
    * Generates CDKTN code for importing a ContainerApp resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ContainerApp to import
    * @param importFromId The id of the existing ContainerApp that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ContainerApp to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/container_app azurerm_container_app} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ContainerAppConfig
    */
    constructor(scope: Construct, id: string, config: ContainerAppConfig);
    private _containerAppEnvironmentId?;
    get containerAppEnvironmentId(): string;
    set containerAppEnvironmentId(value: string);
    get containerAppEnvironmentIdInput(): string | undefined;
    get customDomainVerificationId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get latestRevisionFqdn(): string;
    get latestRevisionName(): string;
    get location(): string;
    private _maxInactiveRevisions?;
    get maxInactiveRevisions(): number;
    set maxInactiveRevisions(value: number);
    resetMaxInactiveRevisions(): void;
    get maxInactiveRevisionsInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get outboundIpAddresses(): string[];
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _revisionMode?;
    get revisionMode(): string;
    set revisionMode(value: string);
    get revisionModeInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _workloadProfileName?;
    get workloadProfileName(): string;
    set workloadProfileName(value: string);
    resetWorkloadProfileName(): void;
    get workloadProfileNameInput(): string | undefined;
    private _dapr;
    get dapr(): ContainerAppDaprOutputReference;
    putDapr(value: ContainerAppDapr): void;
    resetDapr(): void;
    get daprInput(): ContainerAppDapr | undefined;
    private _identity;
    get identity(): ContainerAppIdentityOutputReference;
    putIdentity(value: ContainerAppIdentity): void;
    resetIdentity(): void;
    get identityInput(): ContainerAppIdentity | undefined;
    private _ingress;
    get ingress(): ContainerAppIngressOutputReference;
    putIngress(value: ContainerAppIngress): void;
    resetIngress(): void;
    get ingressInput(): ContainerAppIngress | undefined;
    private _registry;
    get registry(): ContainerAppRegistryList;
    putRegistry(value: ContainerAppRegistry[] | cdktn.IResolvable): void;
    resetRegistry(): void;
    get registryInput(): cdktn.IResolvable | ContainerAppRegistry[] | undefined;
    private _secret;
    get secret(): ContainerAppSecretList;
    putSecret(value: ContainerAppSecret[] | cdktn.IResolvable): void;
    resetSecret(): void;
    get secretInput(): cdktn.IResolvable | ContainerAppSecret[] | undefined;
    private _template;
    get template(): ContainerAppTemplateOutputReference;
    putTemplate(value: ContainerAppTemplate): void;
    get templateInput(): ContainerAppTemplate | undefined;
    private _timeouts;
    get timeouts(): ContainerAppTimeoutsOutputReference;
    putTimeouts(value: ContainerAppTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ContainerAppTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
