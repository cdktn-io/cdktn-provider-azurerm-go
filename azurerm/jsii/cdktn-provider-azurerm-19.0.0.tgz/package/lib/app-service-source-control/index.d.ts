/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppServiceSourceControlConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Windows or Linux Web App.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#app_id AppServiceSourceControl#app_id}
    */
    readonly appId: string;
    /**
    * The branch name to use for deployments.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#branch AppServiceSourceControl#branch}
    */
    readonly branch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#id AppServiceSourceControl#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The URL for the repository.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#repo_url AppServiceSourceControl#repo_url}
    */
    readonly repoUrl?: string;
    /**
    * Should the Deployment Rollback be enabled? Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#rollback_enabled AppServiceSourceControl#rollback_enabled}
    */
    readonly rollbackEnabled?: boolean | cdktn.IResolvable;
    /**
    * Should the App use local Git configuration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#use_local_git AppServiceSourceControl#use_local_git}
    */
    readonly useLocalGit?: boolean | cdktn.IResolvable;
    /**
    * Should code be deployed manually. Set to `false` to enable continuous integration, such as webhooks into online repos such as GitHub. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#use_manual_integration AppServiceSourceControl#use_manual_integration}
    */
    readonly useManualIntegration?: boolean | cdktn.IResolvable;
    /**
    * The repository specified is Mercurial. Defaults to `false`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#use_mercurial AppServiceSourceControl#use_mercurial}
    */
    readonly useMercurial?: boolean | cdktn.IResolvable;
    /**
    * github_action_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#github_action_configuration AppServiceSourceControl#github_action_configuration}
    */
    readonly githubActionConfiguration?: AppServiceSourceControlGithubActionConfiguration;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#timeouts AppServiceSourceControl#timeouts}
    */
    readonly timeouts?: AppServiceSourceControlTimeouts;
}
export interface AppServiceSourceControlGithubActionConfigurationCodeConfiguration {
    /**
    * The value to use for the Runtime Stack in the workflow file content for code base apps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#runtime_stack AppServiceSourceControl#runtime_stack}
    */
    readonly runtimeStack: string;
    /**
    * The value to use for the Runtime Version in the workflow file content for code base apps.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#runtime_version AppServiceSourceControl#runtime_version}
    */
    readonly runtimeVersion: string;
}
export declare function appServiceSourceControlGithubActionConfigurationCodeConfigurationToTerraform(struct?: AppServiceSourceControlGithubActionConfigurationCodeConfigurationOutputReference | AppServiceSourceControlGithubActionConfigurationCodeConfiguration): any;
export declare function appServiceSourceControlGithubActionConfigurationCodeConfigurationToHclTerraform(struct?: AppServiceSourceControlGithubActionConfigurationCodeConfigurationOutputReference | AppServiceSourceControlGithubActionConfigurationCodeConfiguration): any;
export declare class AppServiceSourceControlGithubActionConfigurationCodeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppServiceSourceControlGithubActionConfigurationCodeConfiguration | undefined;
    set internalValue(value: AppServiceSourceControlGithubActionConfigurationCodeConfiguration | undefined);
    private _runtimeStack?;
    get runtimeStack(): string;
    set runtimeStack(value: string);
    get runtimeStackInput(): string | undefined;
    private _runtimeVersion?;
    get runtimeVersion(): string;
    set runtimeVersion(value: string);
    get runtimeVersionInput(): string | undefined;
}
export interface AppServiceSourceControlGithubActionConfigurationContainerConfiguration {
    /**
    * The image name for the build.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#image_name AppServiceSourceControl#image_name}
    */
    readonly imageName: string;
    /**
    * The password used to upload the image to the container registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#registry_password AppServiceSourceControl#registry_password}
    */
    readonly registryPassword?: string;
    /**
    * The server URL for the container registry where the build will be hosted.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#registry_url AppServiceSourceControl#registry_url}
    */
    readonly registryUrl: string;
    /**
    * The username used to upload the image to the container registry.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#registry_username AppServiceSourceControl#registry_username}
    */
    readonly registryUsername?: string;
}
export declare function appServiceSourceControlGithubActionConfigurationContainerConfigurationToTerraform(struct?: AppServiceSourceControlGithubActionConfigurationContainerConfigurationOutputReference | AppServiceSourceControlGithubActionConfigurationContainerConfiguration): any;
export declare function appServiceSourceControlGithubActionConfigurationContainerConfigurationToHclTerraform(struct?: AppServiceSourceControlGithubActionConfigurationContainerConfigurationOutputReference | AppServiceSourceControlGithubActionConfigurationContainerConfiguration): any;
export declare class AppServiceSourceControlGithubActionConfigurationContainerConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppServiceSourceControlGithubActionConfigurationContainerConfiguration | undefined;
    set internalValue(value: AppServiceSourceControlGithubActionConfigurationContainerConfiguration | undefined);
    private _imageName?;
    get imageName(): string;
    set imageName(value: string);
    get imageNameInput(): string | undefined;
    private _registryPassword?;
    get registryPassword(): string;
    set registryPassword(value: string);
    resetRegistryPassword(): void;
    get registryPasswordInput(): string | undefined;
    private _registryUrl?;
    get registryUrl(): string;
    set registryUrl(value: string);
    get registryUrlInput(): string | undefined;
    private _registryUsername?;
    get registryUsername(): string;
    set registryUsername(value: string);
    resetRegistryUsername(): void;
    get registryUsernameInput(): string | undefined;
}
export interface AppServiceSourceControlGithubActionConfiguration {
    /**
    * Should the service generate the GitHub Action Workflow file. Defaults to `true`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#generate_workflow_file AppServiceSourceControl#generate_workflow_file}
    */
    readonly generateWorkflowFile?: boolean | cdktn.IResolvable;
    /**
    * code_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#code_configuration AppServiceSourceControl#code_configuration}
    */
    readonly codeConfiguration?: AppServiceSourceControlGithubActionConfigurationCodeConfiguration;
    /**
    * container_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#container_configuration AppServiceSourceControl#container_configuration}
    */
    readonly containerConfiguration?: AppServiceSourceControlGithubActionConfigurationContainerConfiguration;
}
export declare function appServiceSourceControlGithubActionConfigurationToTerraform(struct?: AppServiceSourceControlGithubActionConfigurationOutputReference | AppServiceSourceControlGithubActionConfiguration): any;
export declare function appServiceSourceControlGithubActionConfigurationToHclTerraform(struct?: AppServiceSourceControlGithubActionConfigurationOutputReference | AppServiceSourceControlGithubActionConfiguration): any;
export declare class AppServiceSourceControlGithubActionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppServiceSourceControlGithubActionConfiguration | undefined;
    set internalValue(value: AppServiceSourceControlGithubActionConfiguration | undefined);
    private _generateWorkflowFile?;
    get generateWorkflowFile(): boolean | cdktn.IResolvable;
    set generateWorkflowFile(value: boolean | cdktn.IResolvable);
    resetGenerateWorkflowFile(): void;
    get generateWorkflowFileInput(): boolean | cdktn.IResolvable | undefined;
    get linuxAction(): cdktn.IResolvable;
    private _codeConfiguration;
    get codeConfiguration(): AppServiceSourceControlGithubActionConfigurationCodeConfigurationOutputReference;
    putCodeConfiguration(value: AppServiceSourceControlGithubActionConfigurationCodeConfiguration): void;
    resetCodeConfiguration(): void;
    get codeConfigurationInput(): AppServiceSourceControlGithubActionConfigurationCodeConfiguration | undefined;
    private _containerConfiguration;
    get containerConfiguration(): AppServiceSourceControlGithubActionConfigurationContainerConfigurationOutputReference;
    putContainerConfiguration(value: AppServiceSourceControlGithubActionConfigurationContainerConfiguration): void;
    resetContainerConfiguration(): void;
    get containerConfigurationInput(): AppServiceSourceControlGithubActionConfigurationContainerConfiguration | undefined;
}
export interface AppServiceSourceControlTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#create AppServiceSourceControl#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#delete AppServiceSourceControl#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#read AppServiceSourceControl#read}
    */
    readonly read?: string;
}
export declare function appServiceSourceControlTimeoutsToTerraform(struct?: AppServiceSourceControlTimeouts | cdktn.IResolvable): any;
export declare function appServiceSourceControlTimeoutsToHclTerraform(struct?: AppServiceSourceControlTimeouts | cdktn.IResolvable): any;
export declare class AppServiceSourceControlTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppServiceSourceControlTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AppServiceSourceControlTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control azurerm_app_service_source_control}
*/
export declare class AppServiceSourceControl extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_app_service_source_control";
    /**
    * Generates CDKTN code for importing a AppServiceSourceControl resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppServiceSourceControl to import
    * @param importFromId The id of the existing AppServiceSourceControl that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppServiceSourceControl to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/app_service_source_control azurerm_app_service_source_control} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppServiceSourceControlConfig
    */
    constructor(scope: Construct, id: string, config: AppServiceSourceControlConfig);
    private _appId?;
    get appId(): string;
    set appId(value: string);
    get appIdInput(): string | undefined;
    private _branch?;
    get branch(): string;
    set branch(value: string);
    resetBranch(): void;
    get branchInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _repoUrl?;
    get repoUrl(): string;
    set repoUrl(value: string);
    resetRepoUrl(): void;
    get repoUrlInput(): string | undefined;
    private _rollbackEnabled?;
    get rollbackEnabled(): boolean | cdktn.IResolvable;
    set rollbackEnabled(value: boolean | cdktn.IResolvable);
    resetRollbackEnabled(): void;
    get rollbackEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get scmType(): string;
    private _useLocalGit?;
    get useLocalGit(): boolean | cdktn.IResolvable;
    set useLocalGit(value: boolean | cdktn.IResolvable);
    resetUseLocalGit(): void;
    get useLocalGitInput(): boolean | cdktn.IResolvable | undefined;
    private _useManualIntegration?;
    get useManualIntegration(): boolean | cdktn.IResolvable;
    set useManualIntegration(value: boolean | cdktn.IResolvable);
    resetUseManualIntegration(): void;
    get useManualIntegrationInput(): boolean | cdktn.IResolvable | undefined;
    private _useMercurial?;
    get useMercurial(): boolean | cdktn.IResolvable;
    set useMercurial(value: boolean | cdktn.IResolvable);
    resetUseMercurial(): void;
    get useMercurialInput(): boolean | cdktn.IResolvable | undefined;
    get usesGithubAction(): cdktn.IResolvable;
    private _githubActionConfiguration;
    get githubActionConfiguration(): AppServiceSourceControlGithubActionConfigurationOutputReference;
    putGithubActionConfiguration(value: AppServiceSourceControlGithubActionConfiguration): void;
    resetGithubActionConfiguration(): void;
    get githubActionConfigurationInput(): AppServiceSourceControlGithubActionConfiguration | undefined;
    private _timeouts;
    get timeouts(): AppServiceSourceControlTimeoutsOutputReference;
    putTimeouts(value: AppServiceSourceControlTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AppServiceSourceControlTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
