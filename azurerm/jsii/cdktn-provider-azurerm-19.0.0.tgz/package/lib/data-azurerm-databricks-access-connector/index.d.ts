/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermDatabricksAccessConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/databricks_access_connector#id DataAzurermDatabricksAccessConnector#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/databricks_access_connector#name DataAzurermDatabricksAccessConnector#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/databricks_access_connector#resource_group_name DataAzurermDatabricksAccessConnector#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/databricks_access_connector#timeouts DataAzurermDatabricksAccessConnector#timeouts}
    */
    readonly timeouts?: DataAzurermDatabricksAccessConnectorTimeouts;
}
export interface DataAzurermDatabricksAccessConnectorIdentity {
}
export declare function dataAzurermDatabricksAccessConnectorIdentityToTerraform(struct?: DataAzurermDatabricksAccessConnectorIdentity): any;
export declare function dataAzurermDatabricksAccessConnectorIdentityToHclTerraform(struct?: DataAzurermDatabricksAccessConnectorIdentity): any;
export declare class DataAzurermDatabricksAccessConnectorIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermDatabricksAccessConnectorIdentity | undefined;
    set internalValue(value: DataAzurermDatabricksAccessConnectorIdentity | undefined);
    get identityIds(): string[];
    get principalId(): string;
    get tenantId(): string;
    get type(): string;
}
export declare class DataAzurermDatabricksAccessConnectorIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermDatabricksAccessConnectorIdentityOutputReference;
}
export interface DataAzurermDatabricksAccessConnectorTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/databricks_access_connector#read DataAzurermDatabricksAccessConnector#read}
    */
    readonly read?: string;
}
export declare function dataAzurermDatabricksAccessConnectorTimeoutsToTerraform(struct?: DataAzurermDatabricksAccessConnectorTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermDatabricksAccessConnectorTimeoutsToHclTerraform(struct?: DataAzurermDatabricksAccessConnectorTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermDatabricksAccessConnectorTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermDatabricksAccessConnectorTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermDatabricksAccessConnectorTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/databricks_access_connector azurerm_databricks_access_connector}
*/
export declare class DataAzurermDatabricksAccessConnector extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_databricks_access_connector";
    /**
    * Generates CDKTN code for importing a DataAzurermDatabricksAccessConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermDatabricksAccessConnector to import
    * @param importFromId The id of the existing DataAzurermDatabricksAccessConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/databricks_access_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermDatabricksAccessConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/data-sources/databricks_access_connector azurerm_databricks_access_connector} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermDatabricksAccessConnectorConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermDatabricksAccessConnectorConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): DataAzurermDatabricksAccessConnectorIdentityList;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): DataAzurermDatabricksAccessConnectorTimeoutsOutputReference;
    putTimeouts(value: DataAzurermDatabricksAccessConnectorTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermDatabricksAccessConnectorTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
