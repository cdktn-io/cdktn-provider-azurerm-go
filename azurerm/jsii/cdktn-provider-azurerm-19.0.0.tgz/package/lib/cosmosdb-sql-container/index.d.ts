/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CosmosdbSqlContainerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#account_name CosmosdbSqlContainer#account_name}
    */
    readonly accountName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#analytical_storage_ttl CosmosdbSqlContainer#analytical_storage_ttl}
    */
    readonly analyticalStorageTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#database_name CosmosdbSqlContainer#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#default_ttl CosmosdbSqlContainer#default_ttl}
    */
    readonly defaultTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#id CosmosdbSqlContainer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#name CosmosdbSqlContainer#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#partition_key_kind CosmosdbSqlContainer#partition_key_kind}
    */
    readonly partitionKeyKind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#partition_key_paths CosmosdbSqlContainer#partition_key_paths}
    */
    readonly partitionKeyPaths: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#partition_key_version CosmosdbSqlContainer#partition_key_version}
    */
    readonly partitionKeyVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#resource_group_name CosmosdbSqlContainer#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#throughput CosmosdbSqlContainer#throughput}
    */
    readonly throughput?: number;
    /**
    * autoscale_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#autoscale_settings CosmosdbSqlContainer#autoscale_settings}
    */
    readonly autoscaleSettings?: CosmosdbSqlContainerAutoscaleSettings;
    /**
    * conflict_resolution_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#conflict_resolution_policy CosmosdbSqlContainer#conflict_resolution_policy}
    */
    readonly conflictResolutionPolicy?: CosmosdbSqlContainerConflictResolutionPolicy;
    /**
    * indexing_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#indexing_policy CosmosdbSqlContainer#indexing_policy}
    */
    readonly indexingPolicy?: CosmosdbSqlContainerIndexingPolicy;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#timeouts CosmosdbSqlContainer#timeouts}
    */
    readonly timeouts?: CosmosdbSqlContainerTimeouts;
    /**
    * unique_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#unique_key CosmosdbSqlContainer#unique_key}
    */
    readonly uniqueKey?: CosmosdbSqlContainerUniqueKey[] | cdktn.IResolvable;
}
export interface CosmosdbSqlContainerAutoscaleSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#max_throughput CosmosdbSqlContainer#max_throughput}
    */
    readonly maxThroughput?: number;
}
export declare function cosmosdbSqlContainerAutoscaleSettingsToTerraform(struct?: CosmosdbSqlContainerAutoscaleSettingsOutputReference | CosmosdbSqlContainerAutoscaleSettings): any;
export declare function cosmosdbSqlContainerAutoscaleSettingsToHclTerraform(struct?: CosmosdbSqlContainerAutoscaleSettingsOutputReference | CosmosdbSqlContainerAutoscaleSettings): any;
export declare class CosmosdbSqlContainerAutoscaleSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbSqlContainerAutoscaleSettings | undefined;
    set internalValue(value: CosmosdbSqlContainerAutoscaleSettings | undefined);
    private _maxThroughput?;
    get maxThroughput(): number;
    set maxThroughput(value: number);
    resetMaxThroughput(): void;
    get maxThroughputInput(): number | undefined;
}
export interface CosmosdbSqlContainerConflictResolutionPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#conflict_resolution_path CosmosdbSqlContainer#conflict_resolution_path}
    */
    readonly conflictResolutionPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#conflict_resolution_procedure CosmosdbSqlContainer#conflict_resolution_procedure}
    */
    readonly conflictResolutionProcedure?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#mode CosmosdbSqlContainer#mode}
    */
    readonly mode: string;
}
export declare function cosmosdbSqlContainerConflictResolutionPolicyToTerraform(struct?: CosmosdbSqlContainerConflictResolutionPolicyOutputReference | CosmosdbSqlContainerConflictResolutionPolicy): any;
export declare function cosmosdbSqlContainerConflictResolutionPolicyToHclTerraform(struct?: CosmosdbSqlContainerConflictResolutionPolicyOutputReference | CosmosdbSqlContainerConflictResolutionPolicy): any;
export declare class CosmosdbSqlContainerConflictResolutionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbSqlContainerConflictResolutionPolicy | undefined;
    set internalValue(value: CosmosdbSqlContainerConflictResolutionPolicy | undefined);
    private _conflictResolutionPath?;
    get conflictResolutionPath(): string;
    set conflictResolutionPath(value: string);
    resetConflictResolutionPath(): void;
    get conflictResolutionPathInput(): string | undefined;
    private _conflictResolutionProcedure?;
    get conflictResolutionProcedure(): string;
    set conflictResolutionProcedure(value: string);
    resetConflictResolutionProcedure(): void;
    get conflictResolutionProcedureInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export interface CosmosdbSqlContainerIndexingPolicyCompositeIndexIndex {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#order CosmosdbSqlContainer#order}
    */
    readonly order: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#path CosmosdbSqlContainer#path}
    */
    readonly path: string;
}
export declare function cosmosdbSqlContainerIndexingPolicyCompositeIndexIndexToTerraform(struct?: CosmosdbSqlContainerIndexingPolicyCompositeIndexIndex | cdktn.IResolvable): any;
export declare function cosmosdbSqlContainerIndexingPolicyCompositeIndexIndexToHclTerraform(struct?: CosmosdbSqlContainerIndexingPolicyCompositeIndexIndex | cdktn.IResolvable): any;
export declare class CosmosdbSqlContainerIndexingPolicyCompositeIndexIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbSqlContainerIndexingPolicyCompositeIndexIndex | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbSqlContainerIndexingPolicyCompositeIndexIndex | cdktn.IResolvable | undefined);
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export declare class CosmosdbSqlContainerIndexingPolicyCompositeIndexIndexList extends cdktn.ComplexList {
    internalValue?: CosmosdbSqlContainerIndexingPolicyCompositeIndexIndex[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbSqlContainerIndexingPolicyCompositeIndexIndexOutputReference;
}
export interface CosmosdbSqlContainerIndexingPolicyCompositeIndex {
    /**
    * index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#index CosmosdbSqlContainer#index}
    */
    readonly index: CosmosdbSqlContainerIndexingPolicyCompositeIndexIndex[] | cdktn.IResolvable;
}
export declare function cosmosdbSqlContainerIndexingPolicyCompositeIndexToTerraform(struct?: CosmosdbSqlContainerIndexingPolicyCompositeIndex | cdktn.IResolvable): any;
export declare function cosmosdbSqlContainerIndexingPolicyCompositeIndexToHclTerraform(struct?: CosmosdbSqlContainerIndexingPolicyCompositeIndex | cdktn.IResolvable): any;
export declare class CosmosdbSqlContainerIndexingPolicyCompositeIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbSqlContainerIndexingPolicyCompositeIndex | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbSqlContainerIndexingPolicyCompositeIndex | cdktn.IResolvable | undefined);
    private _index;
    get index(): CosmosdbSqlContainerIndexingPolicyCompositeIndexIndexList;
    putIndex(value: CosmosdbSqlContainerIndexingPolicyCompositeIndexIndex[] | cdktn.IResolvable): void;
    get indexInput(): cdktn.IResolvable | CosmosdbSqlContainerIndexingPolicyCompositeIndexIndex[] | undefined;
}
export declare class CosmosdbSqlContainerIndexingPolicyCompositeIndexList extends cdktn.ComplexList {
    internalValue?: CosmosdbSqlContainerIndexingPolicyCompositeIndex[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbSqlContainerIndexingPolicyCompositeIndexOutputReference;
}
export interface CosmosdbSqlContainerIndexingPolicyExcludedPath {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#path CosmosdbSqlContainer#path}
    */
    readonly path: string;
}
export declare function cosmosdbSqlContainerIndexingPolicyExcludedPathToTerraform(struct?: CosmosdbSqlContainerIndexingPolicyExcludedPath | cdktn.IResolvable): any;
export declare function cosmosdbSqlContainerIndexingPolicyExcludedPathToHclTerraform(struct?: CosmosdbSqlContainerIndexingPolicyExcludedPath | cdktn.IResolvable): any;
export declare class CosmosdbSqlContainerIndexingPolicyExcludedPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbSqlContainerIndexingPolicyExcludedPath | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbSqlContainerIndexingPolicyExcludedPath | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export declare class CosmosdbSqlContainerIndexingPolicyExcludedPathList extends cdktn.ComplexList {
    internalValue?: CosmosdbSqlContainerIndexingPolicyExcludedPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbSqlContainerIndexingPolicyExcludedPathOutputReference;
}
export interface CosmosdbSqlContainerIndexingPolicyIncludedPath {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#path CosmosdbSqlContainer#path}
    */
    readonly path: string;
}
export declare function cosmosdbSqlContainerIndexingPolicyIncludedPathToTerraform(struct?: CosmosdbSqlContainerIndexingPolicyIncludedPath | cdktn.IResolvable): any;
export declare function cosmosdbSqlContainerIndexingPolicyIncludedPathToHclTerraform(struct?: CosmosdbSqlContainerIndexingPolicyIncludedPath | cdktn.IResolvable): any;
export declare class CosmosdbSqlContainerIndexingPolicyIncludedPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbSqlContainerIndexingPolicyIncludedPath | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbSqlContainerIndexingPolicyIncludedPath | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export declare class CosmosdbSqlContainerIndexingPolicyIncludedPathList extends cdktn.ComplexList {
    internalValue?: CosmosdbSqlContainerIndexingPolicyIncludedPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbSqlContainerIndexingPolicyIncludedPathOutputReference;
}
export interface CosmosdbSqlContainerIndexingPolicySpatialIndex {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#path CosmosdbSqlContainer#path}
    */
    readonly path: string;
}
export declare function cosmosdbSqlContainerIndexingPolicySpatialIndexToTerraform(struct?: CosmosdbSqlContainerIndexingPolicySpatialIndex | cdktn.IResolvable): any;
export declare function cosmosdbSqlContainerIndexingPolicySpatialIndexToHclTerraform(struct?: CosmosdbSqlContainerIndexingPolicySpatialIndex | cdktn.IResolvable): any;
export declare class CosmosdbSqlContainerIndexingPolicySpatialIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbSqlContainerIndexingPolicySpatialIndex | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbSqlContainerIndexingPolicySpatialIndex | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    get types(): string[];
}
export declare class CosmosdbSqlContainerIndexingPolicySpatialIndexList extends cdktn.ComplexList {
    internalValue?: CosmosdbSqlContainerIndexingPolicySpatialIndex[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbSqlContainerIndexingPolicySpatialIndexOutputReference;
}
export interface CosmosdbSqlContainerIndexingPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#indexing_mode CosmosdbSqlContainer#indexing_mode}
    */
    readonly indexingMode?: string;
    /**
    * composite_index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#composite_index CosmosdbSqlContainer#composite_index}
    */
    readonly compositeIndex?: CosmosdbSqlContainerIndexingPolicyCompositeIndex[] | cdktn.IResolvable;
    /**
    * excluded_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#excluded_path CosmosdbSqlContainer#excluded_path}
    */
    readonly excludedPath?: CosmosdbSqlContainerIndexingPolicyExcludedPath[] | cdktn.IResolvable;
    /**
    * included_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#included_path CosmosdbSqlContainer#included_path}
    */
    readonly includedPath?: CosmosdbSqlContainerIndexingPolicyIncludedPath[] | cdktn.IResolvable;
    /**
    * spatial_index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#spatial_index CosmosdbSqlContainer#spatial_index}
    */
    readonly spatialIndex?: CosmosdbSqlContainerIndexingPolicySpatialIndex[] | cdktn.IResolvable;
}
export declare function cosmosdbSqlContainerIndexingPolicyToTerraform(struct?: CosmosdbSqlContainerIndexingPolicyOutputReference | CosmosdbSqlContainerIndexingPolicy): any;
export declare function cosmosdbSqlContainerIndexingPolicyToHclTerraform(struct?: CosmosdbSqlContainerIndexingPolicyOutputReference | CosmosdbSqlContainerIndexingPolicy): any;
export declare class CosmosdbSqlContainerIndexingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbSqlContainerIndexingPolicy | undefined;
    set internalValue(value: CosmosdbSqlContainerIndexingPolicy | undefined);
    private _indexingMode?;
    get indexingMode(): string;
    set indexingMode(value: string);
    resetIndexingMode(): void;
    get indexingModeInput(): string | undefined;
    private _compositeIndex;
    get compositeIndex(): CosmosdbSqlContainerIndexingPolicyCompositeIndexList;
    putCompositeIndex(value: CosmosdbSqlContainerIndexingPolicyCompositeIndex[] | cdktn.IResolvable): void;
    resetCompositeIndex(): void;
    get compositeIndexInput(): cdktn.IResolvable | CosmosdbSqlContainerIndexingPolicyCompositeIndex[] | undefined;
    private _excludedPath;
    get excludedPath(): CosmosdbSqlContainerIndexingPolicyExcludedPathList;
    putExcludedPath(value: CosmosdbSqlContainerIndexingPolicyExcludedPath[] | cdktn.IResolvable): void;
    resetExcludedPath(): void;
    get excludedPathInput(): cdktn.IResolvable | CosmosdbSqlContainerIndexingPolicyExcludedPath[] | undefined;
    private _includedPath;
    get includedPath(): CosmosdbSqlContainerIndexingPolicyIncludedPathList;
    putIncludedPath(value: CosmosdbSqlContainerIndexingPolicyIncludedPath[] | cdktn.IResolvable): void;
    resetIncludedPath(): void;
    get includedPathInput(): cdktn.IResolvable | CosmosdbSqlContainerIndexingPolicyIncludedPath[] | undefined;
    private _spatialIndex;
    get spatialIndex(): CosmosdbSqlContainerIndexingPolicySpatialIndexList;
    putSpatialIndex(value: CosmosdbSqlContainerIndexingPolicySpatialIndex[] | cdktn.IResolvable): void;
    resetSpatialIndex(): void;
    get spatialIndexInput(): cdktn.IResolvable | CosmosdbSqlContainerIndexingPolicySpatialIndex[] | undefined;
}
export interface CosmosdbSqlContainerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#create CosmosdbSqlContainer#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#delete CosmosdbSqlContainer#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#read CosmosdbSqlContainer#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#update CosmosdbSqlContainer#update}
    */
    readonly update?: string;
}
export declare function cosmosdbSqlContainerTimeoutsToTerraform(struct?: CosmosdbSqlContainerTimeouts | cdktn.IResolvable): any;
export declare function cosmosdbSqlContainerTimeoutsToHclTerraform(struct?: CosmosdbSqlContainerTimeouts | cdktn.IResolvable): any;
export declare class CosmosdbSqlContainerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbSqlContainerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbSqlContainerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CosmosdbSqlContainerUniqueKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#paths CosmosdbSqlContainer#paths}
    */
    readonly paths: string[];
}
export declare function cosmosdbSqlContainerUniqueKeyToTerraform(struct?: CosmosdbSqlContainerUniqueKey | cdktn.IResolvable): any;
export declare function cosmosdbSqlContainerUniqueKeyToHclTerraform(struct?: CosmosdbSqlContainerUniqueKey | cdktn.IResolvable): any;
export declare class CosmosdbSqlContainerUniqueKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbSqlContainerUniqueKey | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbSqlContainerUniqueKey | cdktn.IResolvable | undefined);
    private _paths?;
    get paths(): string[];
    set paths(value: string[]);
    get pathsInput(): string[] | undefined;
}
export declare class CosmosdbSqlContainerUniqueKeyList extends cdktn.ComplexList {
    internalValue?: CosmosdbSqlContainerUniqueKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbSqlContainerUniqueKeyOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container azurerm_cosmosdb_sql_container}
*/
export declare class CosmosdbSqlContainer extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_cosmosdb_sql_container";
    /**
    * Generates CDKTN code for importing a CosmosdbSqlContainer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CosmosdbSqlContainer to import
    * @param importFromId The id of the existing CosmosdbSqlContainer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CosmosdbSqlContainer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_sql_container azurerm_cosmosdb_sql_container} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CosmosdbSqlContainerConfig
    */
    constructor(scope: Construct, id: string, config: CosmosdbSqlContainerConfig);
    private _accountName?;
    get accountName(): string;
    set accountName(value: string);
    get accountNameInput(): string | undefined;
    private _analyticalStorageTtl?;
    get analyticalStorageTtl(): number;
    set analyticalStorageTtl(value: number);
    resetAnalyticalStorageTtl(): void;
    get analyticalStorageTtlInput(): number | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _defaultTtl?;
    get defaultTtl(): number;
    set defaultTtl(value: number);
    resetDefaultTtl(): void;
    get defaultTtlInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _partitionKeyKind?;
    get partitionKeyKind(): string;
    set partitionKeyKind(value: string);
    resetPartitionKeyKind(): void;
    get partitionKeyKindInput(): string | undefined;
    private _partitionKeyPaths?;
    get partitionKeyPaths(): string[];
    set partitionKeyPaths(value: string[]);
    get partitionKeyPathsInput(): string[] | undefined;
    private _partitionKeyVersion?;
    get partitionKeyVersion(): number;
    set partitionKeyVersion(value: number);
    resetPartitionKeyVersion(): void;
    get partitionKeyVersionInput(): number | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _throughput?;
    get throughput(): number;
    set throughput(value: number);
    resetThroughput(): void;
    get throughputInput(): number | undefined;
    private _autoscaleSettings;
    get autoscaleSettings(): CosmosdbSqlContainerAutoscaleSettingsOutputReference;
    putAutoscaleSettings(value: CosmosdbSqlContainerAutoscaleSettings): void;
    resetAutoscaleSettings(): void;
    get autoscaleSettingsInput(): CosmosdbSqlContainerAutoscaleSettings | undefined;
    private _conflictResolutionPolicy;
    get conflictResolutionPolicy(): CosmosdbSqlContainerConflictResolutionPolicyOutputReference;
    putConflictResolutionPolicy(value: CosmosdbSqlContainerConflictResolutionPolicy): void;
    resetConflictResolutionPolicy(): void;
    get conflictResolutionPolicyInput(): CosmosdbSqlContainerConflictResolutionPolicy | undefined;
    private _indexingPolicy;
    get indexingPolicy(): CosmosdbSqlContainerIndexingPolicyOutputReference;
    putIndexingPolicy(value: CosmosdbSqlContainerIndexingPolicy): void;
    resetIndexingPolicy(): void;
    get indexingPolicyInput(): CosmosdbSqlContainerIndexingPolicy | undefined;
    private _timeouts;
    get timeouts(): CosmosdbSqlContainerTimeoutsOutputReference;
    putTimeouts(value: CosmosdbSqlContainerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CosmosdbSqlContainerTimeouts | undefined;
    private _uniqueKey;
    get uniqueKey(): CosmosdbSqlContainerUniqueKeyList;
    putUniqueKey(value: CosmosdbSqlContainerUniqueKey[] | cdktn.IResolvable): void;
    resetUniqueKey(): void;
    get uniqueKeyInput(): cdktn.IResolvable | CosmosdbSqlContainerUniqueKey[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
