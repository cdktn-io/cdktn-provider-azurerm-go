/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CosmosdbAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#access_key_metadata_writes_enabled CosmosdbAccount#access_key_metadata_writes_enabled}
    */
    readonly accessKeyMetadataWritesEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#analytical_storage_enabled CosmosdbAccount#analytical_storage_enabled}
    */
    readonly analyticalStorageEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#automatic_failover_enabled CosmosdbAccount#automatic_failover_enabled}
    */
    readonly automaticFailoverEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#burst_capacity_enabled CosmosdbAccount#burst_capacity_enabled}
    */
    readonly burstCapacityEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#create_mode CosmosdbAccount#create_mode}
    */
    readonly createMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#default_identity_type CosmosdbAccount#default_identity_type}
    */
    readonly defaultIdentityType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#free_tier_enabled CosmosdbAccount#free_tier_enabled}
    */
    readonly freeTierEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#id CosmosdbAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#ip_range_filter CosmosdbAccount#ip_range_filter}
    */
    readonly ipRangeFilter?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#is_virtual_network_filter_enabled CosmosdbAccount#is_virtual_network_filter_enabled}
    */
    readonly isVirtualNetworkFilterEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#key_vault_key_id CosmosdbAccount#key_vault_key_id}
    */
    readonly keyVaultKeyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#kind CosmosdbAccount#kind}
    */
    readonly kind?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#local_authentication_enabled CosmosdbAccount#local_authentication_enabled}
    */
    readonly localAuthenticationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#location CosmosdbAccount#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#minimal_tls_version CosmosdbAccount#minimal_tls_version}
    */
    readonly minimalTlsVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#mongo_server_version CosmosdbAccount#mongo_server_version}
    */
    readonly mongoServerVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#multiple_write_locations_enabled CosmosdbAccount#multiple_write_locations_enabled}
    */
    readonly multipleWriteLocationsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#name CosmosdbAccount#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#network_acl_bypass_for_azure_services CosmosdbAccount#network_acl_bypass_for_azure_services}
    */
    readonly networkAclBypassForAzureServices?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#network_acl_bypass_ids CosmosdbAccount#network_acl_bypass_ids}
    */
    readonly networkAclBypassIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#offer_type CosmosdbAccount#offer_type}
    */
    readonly offerType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#partition_merge_enabled CosmosdbAccount#partition_merge_enabled}
    */
    readonly partitionMergeEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#public_network_access_enabled CosmosdbAccount#public_network_access_enabled}
    */
    readonly publicNetworkAccessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#resource_group_name CosmosdbAccount#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#tags CosmosdbAccount#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * analytical_storage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#analytical_storage CosmosdbAccount#analytical_storage}
    */
    readonly analyticalStorage?: CosmosdbAccountAnalyticalStorage;
    /**
    * backup block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#backup CosmosdbAccount#backup}
    */
    readonly backup?: CosmosdbAccountBackup;
    /**
    * capabilities block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#capabilities CosmosdbAccount#capabilities}
    */
    readonly capabilities?: CosmosdbAccountCapabilities[] | cdktn.IResolvable;
    /**
    * capacity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#capacity CosmosdbAccount#capacity}
    */
    readonly capacity?: CosmosdbAccountCapacity;
    /**
    * consistency_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#consistency_policy CosmosdbAccount#consistency_policy}
    */
    readonly consistencyPolicy: CosmosdbAccountConsistencyPolicy;
    /**
    * cors_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#cors_rule CosmosdbAccount#cors_rule}
    */
    readonly corsRule?: CosmosdbAccountCorsRule;
    /**
    * geo_location block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#geo_location CosmosdbAccount#geo_location}
    */
    readonly geoLocation: CosmosdbAccountGeoLocation[] | cdktn.IResolvable;
    /**
    * identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#identity CosmosdbAccount#identity}
    */
    readonly identity?: CosmosdbAccountIdentity;
    /**
    * restore block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#restore CosmosdbAccount#restore}
    */
    readonly restore?: CosmosdbAccountRestore;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#timeouts CosmosdbAccount#timeouts}
    */
    readonly timeouts?: CosmosdbAccountTimeouts;
    /**
    * virtual_network_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#virtual_network_rule CosmosdbAccount#virtual_network_rule}
    */
    readonly virtualNetworkRule?: CosmosdbAccountVirtualNetworkRule[] | cdktn.IResolvable;
}
export interface CosmosdbAccountAnalyticalStorage {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#schema_type CosmosdbAccount#schema_type}
    */
    readonly schemaType: string;
}
export declare function cosmosdbAccountAnalyticalStorageToTerraform(struct?: CosmosdbAccountAnalyticalStorageOutputReference | CosmosdbAccountAnalyticalStorage): any;
export declare function cosmosdbAccountAnalyticalStorageToHclTerraform(struct?: CosmosdbAccountAnalyticalStorageOutputReference | CosmosdbAccountAnalyticalStorage): any;
export declare class CosmosdbAccountAnalyticalStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbAccountAnalyticalStorage | undefined;
    set internalValue(value: CosmosdbAccountAnalyticalStorage | undefined);
    private _schemaType?;
    get schemaType(): string;
    set schemaType(value: string);
    get schemaTypeInput(): string | undefined;
}
export interface CosmosdbAccountBackup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#interval_in_minutes CosmosdbAccount#interval_in_minutes}
    */
    readonly intervalInMinutes?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#retention_in_hours CosmosdbAccount#retention_in_hours}
    */
    readonly retentionInHours?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#storage_redundancy CosmosdbAccount#storage_redundancy}
    */
    readonly storageRedundancy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#tier CosmosdbAccount#tier}
    */
    readonly tier?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#type CosmosdbAccount#type}
    */
    readonly type: string;
}
export declare function cosmosdbAccountBackupToTerraform(struct?: CosmosdbAccountBackupOutputReference | CosmosdbAccountBackup): any;
export declare function cosmosdbAccountBackupToHclTerraform(struct?: CosmosdbAccountBackupOutputReference | CosmosdbAccountBackup): any;
export declare class CosmosdbAccountBackupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbAccountBackup | undefined;
    set internalValue(value: CosmosdbAccountBackup | undefined);
    private _intervalInMinutes?;
    get intervalInMinutes(): number;
    set intervalInMinutes(value: number);
    resetIntervalInMinutes(): void;
    get intervalInMinutesInput(): number | undefined;
    private _retentionInHours?;
    get retentionInHours(): number;
    set retentionInHours(value: number);
    resetRetentionInHours(): void;
    get retentionInHoursInput(): number | undefined;
    private _storageRedundancy?;
    get storageRedundancy(): string;
    set storageRedundancy(value: string);
    resetStorageRedundancy(): void;
    get storageRedundancyInput(): string | undefined;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    resetTier(): void;
    get tierInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface CosmosdbAccountCapabilities {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#name CosmosdbAccount#name}
    */
    readonly name: string;
}
export declare function cosmosdbAccountCapabilitiesToTerraform(struct?: CosmosdbAccountCapabilities | cdktn.IResolvable): any;
export declare function cosmosdbAccountCapabilitiesToHclTerraform(struct?: CosmosdbAccountCapabilities | cdktn.IResolvable): any;
export declare class CosmosdbAccountCapabilitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbAccountCapabilities | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbAccountCapabilities | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class CosmosdbAccountCapabilitiesList extends cdktn.ComplexList {
    internalValue?: CosmosdbAccountCapabilities[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbAccountCapabilitiesOutputReference;
}
export interface CosmosdbAccountCapacity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#total_throughput_limit CosmosdbAccount#total_throughput_limit}
    */
    readonly totalThroughputLimit: number;
}
export declare function cosmosdbAccountCapacityToTerraform(struct?: CosmosdbAccountCapacityOutputReference | CosmosdbAccountCapacity): any;
export declare function cosmosdbAccountCapacityToHclTerraform(struct?: CosmosdbAccountCapacityOutputReference | CosmosdbAccountCapacity): any;
export declare class CosmosdbAccountCapacityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbAccountCapacity | undefined;
    set internalValue(value: CosmosdbAccountCapacity | undefined);
    private _totalThroughputLimit?;
    get totalThroughputLimit(): number;
    set totalThroughputLimit(value: number);
    get totalThroughputLimitInput(): number | undefined;
}
export interface CosmosdbAccountConsistencyPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#consistency_level CosmosdbAccount#consistency_level}
    */
    readonly consistencyLevel: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#max_interval_in_seconds CosmosdbAccount#max_interval_in_seconds}
    */
    readonly maxIntervalInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#max_staleness_prefix CosmosdbAccount#max_staleness_prefix}
    */
    readonly maxStalenessPrefix?: number;
}
export declare function cosmosdbAccountConsistencyPolicyToTerraform(struct?: CosmosdbAccountConsistencyPolicyOutputReference | CosmosdbAccountConsistencyPolicy): any;
export declare function cosmosdbAccountConsistencyPolicyToHclTerraform(struct?: CosmosdbAccountConsistencyPolicyOutputReference | CosmosdbAccountConsistencyPolicy): any;
export declare class CosmosdbAccountConsistencyPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbAccountConsistencyPolicy | undefined;
    set internalValue(value: CosmosdbAccountConsistencyPolicy | undefined);
    private _consistencyLevel?;
    get consistencyLevel(): string;
    set consistencyLevel(value: string);
    get consistencyLevelInput(): string | undefined;
    private _maxIntervalInSeconds?;
    get maxIntervalInSeconds(): number;
    set maxIntervalInSeconds(value: number);
    resetMaxIntervalInSeconds(): void;
    get maxIntervalInSecondsInput(): number | undefined;
    private _maxStalenessPrefix?;
    get maxStalenessPrefix(): number;
    set maxStalenessPrefix(value: number);
    resetMaxStalenessPrefix(): void;
    get maxStalenessPrefixInput(): number | undefined;
}
export interface CosmosdbAccountCorsRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#allowed_headers CosmosdbAccount#allowed_headers}
    */
    readonly allowedHeaders: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#allowed_methods CosmosdbAccount#allowed_methods}
    */
    readonly allowedMethods: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#allowed_origins CosmosdbAccount#allowed_origins}
    */
    readonly allowedOrigins: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#exposed_headers CosmosdbAccount#exposed_headers}
    */
    readonly exposedHeaders: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#max_age_in_seconds CosmosdbAccount#max_age_in_seconds}
    */
    readonly maxAgeInSeconds?: number;
}
export declare function cosmosdbAccountCorsRuleToTerraform(struct?: CosmosdbAccountCorsRuleOutputReference | CosmosdbAccountCorsRule): any;
export declare function cosmosdbAccountCorsRuleToHclTerraform(struct?: CosmosdbAccountCorsRuleOutputReference | CosmosdbAccountCorsRule): any;
export declare class CosmosdbAccountCorsRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbAccountCorsRule | undefined;
    set internalValue(value: CosmosdbAccountCorsRule | undefined);
    private _allowedHeaders?;
    get allowedHeaders(): string[];
    set allowedHeaders(value: string[]);
    get allowedHeadersInput(): string[] | undefined;
    private _allowedMethods?;
    get allowedMethods(): string[];
    set allowedMethods(value: string[]);
    get allowedMethodsInput(): string[] | undefined;
    private _allowedOrigins?;
    get allowedOrigins(): string[];
    set allowedOrigins(value: string[]);
    get allowedOriginsInput(): string[] | undefined;
    private _exposedHeaders?;
    get exposedHeaders(): string[];
    set exposedHeaders(value: string[]);
    get exposedHeadersInput(): string[] | undefined;
    private _maxAgeInSeconds?;
    get maxAgeInSeconds(): number;
    set maxAgeInSeconds(value: number);
    resetMaxAgeInSeconds(): void;
    get maxAgeInSecondsInput(): number | undefined;
}
export interface CosmosdbAccountGeoLocation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#failover_priority CosmosdbAccount#failover_priority}
    */
    readonly failoverPriority: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#location CosmosdbAccount#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#zone_redundant CosmosdbAccount#zone_redundant}
    */
    readonly zoneRedundant?: boolean | cdktn.IResolvable;
}
export declare function cosmosdbAccountGeoLocationToTerraform(struct?: CosmosdbAccountGeoLocation | cdktn.IResolvable): any;
export declare function cosmosdbAccountGeoLocationToHclTerraform(struct?: CosmosdbAccountGeoLocation | cdktn.IResolvable): any;
export declare class CosmosdbAccountGeoLocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbAccountGeoLocation | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbAccountGeoLocation | cdktn.IResolvable | undefined);
    private _failoverPriority?;
    get failoverPriority(): number;
    set failoverPriority(value: number);
    get failoverPriorityInput(): number | undefined;
    get id(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _zoneRedundant?;
    get zoneRedundant(): boolean | cdktn.IResolvable;
    set zoneRedundant(value: boolean | cdktn.IResolvable);
    resetZoneRedundant(): void;
    get zoneRedundantInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class CosmosdbAccountGeoLocationList extends cdktn.ComplexList {
    internalValue?: CosmosdbAccountGeoLocation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbAccountGeoLocationOutputReference;
}
export interface CosmosdbAccountIdentity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#identity_ids CosmosdbAccount#identity_ids}
    */
    readonly identityIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#type CosmosdbAccount#type}
    */
    readonly type: string;
}
export declare function cosmosdbAccountIdentityToTerraform(struct?: CosmosdbAccountIdentityOutputReference | CosmosdbAccountIdentity): any;
export declare function cosmosdbAccountIdentityToHclTerraform(struct?: CosmosdbAccountIdentityOutputReference | CosmosdbAccountIdentity): any;
export declare class CosmosdbAccountIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbAccountIdentity | undefined;
    set internalValue(value: CosmosdbAccountIdentity | undefined);
    private _identityIds?;
    get identityIds(): string[];
    set identityIds(value: string[]);
    resetIdentityIds(): void;
    get identityIdsInput(): string[] | undefined;
    get principalId(): string;
    get tenantId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface CosmosdbAccountRestoreDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#collection_names CosmosdbAccount#collection_names}
    */
    readonly collectionNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#name CosmosdbAccount#name}
    */
    readonly name: string;
}
export declare function cosmosdbAccountRestoreDatabaseToTerraform(struct?: CosmosdbAccountRestoreDatabase | cdktn.IResolvable): any;
export declare function cosmosdbAccountRestoreDatabaseToHclTerraform(struct?: CosmosdbAccountRestoreDatabase | cdktn.IResolvable): any;
export declare class CosmosdbAccountRestoreDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbAccountRestoreDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbAccountRestoreDatabase | cdktn.IResolvable | undefined);
    private _collectionNames?;
    get collectionNames(): string[];
    set collectionNames(value: string[]);
    resetCollectionNames(): void;
    get collectionNamesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class CosmosdbAccountRestoreDatabaseList extends cdktn.ComplexList {
    internalValue?: CosmosdbAccountRestoreDatabase[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbAccountRestoreDatabaseOutputReference;
}
export interface CosmosdbAccountRestoreGremlinDatabase {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#graph_names CosmosdbAccount#graph_names}
    */
    readonly graphNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#name CosmosdbAccount#name}
    */
    readonly name: string;
}
export declare function cosmosdbAccountRestoreGremlinDatabaseToTerraform(struct?: CosmosdbAccountRestoreGremlinDatabase | cdktn.IResolvable): any;
export declare function cosmosdbAccountRestoreGremlinDatabaseToHclTerraform(struct?: CosmosdbAccountRestoreGremlinDatabase | cdktn.IResolvable): any;
export declare class CosmosdbAccountRestoreGremlinDatabaseOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbAccountRestoreGremlinDatabase | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbAccountRestoreGremlinDatabase | cdktn.IResolvable | undefined);
    private _graphNames?;
    get graphNames(): string[];
    set graphNames(value: string[]);
    resetGraphNames(): void;
    get graphNamesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class CosmosdbAccountRestoreGremlinDatabaseList extends cdktn.ComplexList {
    internalValue?: CosmosdbAccountRestoreGremlinDatabase[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbAccountRestoreGremlinDatabaseOutputReference;
}
export interface CosmosdbAccountRestore {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#restore_timestamp_in_utc CosmosdbAccount#restore_timestamp_in_utc}
    */
    readonly restoreTimestampInUtc: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#source_cosmosdb_account_id CosmosdbAccount#source_cosmosdb_account_id}
    */
    readonly sourceCosmosdbAccountId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#tables_to_restore CosmosdbAccount#tables_to_restore}
    */
    readonly tablesToRestore?: string[];
    /**
    * database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#database CosmosdbAccount#database}
    */
    readonly database?: CosmosdbAccountRestoreDatabase[] | cdktn.IResolvable;
    /**
    * gremlin_database block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#gremlin_database CosmosdbAccount#gremlin_database}
    */
    readonly gremlinDatabase?: CosmosdbAccountRestoreGremlinDatabase[] | cdktn.IResolvable;
}
export declare function cosmosdbAccountRestoreToTerraform(struct?: CosmosdbAccountRestoreOutputReference | CosmosdbAccountRestore): any;
export declare function cosmosdbAccountRestoreToHclTerraform(struct?: CosmosdbAccountRestoreOutputReference | CosmosdbAccountRestore): any;
export declare class CosmosdbAccountRestoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbAccountRestore | undefined;
    set internalValue(value: CosmosdbAccountRestore | undefined);
    private _restoreTimestampInUtc?;
    get restoreTimestampInUtc(): string;
    set restoreTimestampInUtc(value: string);
    get restoreTimestampInUtcInput(): string | undefined;
    private _sourceCosmosdbAccountId?;
    get sourceCosmosdbAccountId(): string;
    set sourceCosmosdbAccountId(value: string);
    get sourceCosmosdbAccountIdInput(): string | undefined;
    private _tablesToRestore?;
    get tablesToRestore(): string[];
    set tablesToRestore(value: string[]);
    resetTablesToRestore(): void;
    get tablesToRestoreInput(): string[] | undefined;
    private _database;
    get database(): CosmosdbAccountRestoreDatabaseList;
    putDatabase(value: CosmosdbAccountRestoreDatabase[] | cdktn.IResolvable): void;
    resetDatabase(): void;
    get databaseInput(): cdktn.IResolvable | CosmosdbAccountRestoreDatabase[] | undefined;
    private _gremlinDatabase;
    get gremlinDatabase(): CosmosdbAccountRestoreGremlinDatabaseList;
    putGremlinDatabase(value: CosmosdbAccountRestoreGremlinDatabase[] | cdktn.IResolvable): void;
    resetGremlinDatabase(): void;
    get gremlinDatabaseInput(): cdktn.IResolvable | CosmosdbAccountRestoreGremlinDatabase[] | undefined;
}
export interface CosmosdbAccountTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#create CosmosdbAccount#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#delete CosmosdbAccount#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#read CosmosdbAccount#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#update CosmosdbAccount#update}
    */
    readonly update?: string;
}
export declare function cosmosdbAccountTimeoutsToTerraform(struct?: CosmosdbAccountTimeouts | cdktn.IResolvable): any;
export declare function cosmosdbAccountTimeoutsToHclTerraform(struct?: CosmosdbAccountTimeouts | cdktn.IResolvable): any;
export declare class CosmosdbAccountTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbAccountTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbAccountTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CosmosdbAccountVirtualNetworkRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#id CosmosdbAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#ignore_missing_vnet_service_endpoint CosmosdbAccount#ignore_missing_vnet_service_endpoint}
    */
    readonly ignoreMissingVnetServiceEndpoint?: boolean | cdktn.IResolvable;
}
export declare function cosmosdbAccountVirtualNetworkRuleToTerraform(struct?: CosmosdbAccountVirtualNetworkRule | cdktn.IResolvable): any;
export declare function cosmosdbAccountVirtualNetworkRuleToHclTerraform(struct?: CosmosdbAccountVirtualNetworkRule | cdktn.IResolvable): any;
export declare class CosmosdbAccountVirtualNetworkRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbAccountVirtualNetworkRule | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbAccountVirtualNetworkRule | cdktn.IResolvable | undefined);
    private _id?;
    get id(): string;
    set id(value: string);
    get idInput(): string | undefined;
    private _ignoreMissingVnetServiceEndpoint?;
    get ignoreMissingVnetServiceEndpoint(): boolean | cdktn.IResolvable;
    set ignoreMissingVnetServiceEndpoint(value: boolean | cdktn.IResolvable);
    resetIgnoreMissingVnetServiceEndpoint(): void;
    get ignoreMissingVnetServiceEndpointInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class CosmosdbAccountVirtualNetworkRuleList extends cdktn.ComplexList {
    internalValue?: CosmosdbAccountVirtualNetworkRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbAccountVirtualNetworkRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account azurerm_cosmosdb_account}
*/
export declare class CosmosdbAccount extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_cosmosdb_account";
    /**
    * Generates CDKTN code for importing a CosmosdbAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CosmosdbAccount to import
    * @param importFromId The id of the existing CosmosdbAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CosmosdbAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cosmosdb_account azurerm_cosmosdb_account} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CosmosdbAccountConfig
    */
    constructor(scope: Construct, id: string, config: CosmosdbAccountConfig);
    private _accessKeyMetadataWritesEnabled?;
    get accessKeyMetadataWritesEnabled(): boolean | cdktn.IResolvable;
    set accessKeyMetadataWritesEnabled(value: boolean | cdktn.IResolvable);
    resetAccessKeyMetadataWritesEnabled(): void;
    get accessKeyMetadataWritesEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _analyticalStorageEnabled?;
    get analyticalStorageEnabled(): boolean | cdktn.IResolvable;
    set analyticalStorageEnabled(value: boolean | cdktn.IResolvable);
    resetAnalyticalStorageEnabled(): void;
    get analyticalStorageEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _automaticFailoverEnabled?;
    get automaticFailoverEnabled(): boolean | cdktn.IResolvable;
    set automaticFailoverEnabled(value: boolean | cdktn.IResolvable);
    resetAutomaticFailoverEnabled(): void;
    get automaticFailoverEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _burstCapacityEnabled?;
    get burstCapacityEnabled(): boolean | cdktn.IResolvable;
    set burstCapacityEnabled(value: boolean | cdktn.IResolvable);
    resetBurstCapacityEnabled(): void;
    get burstCapacityEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _createMode?;
    get createMode(): string;
    set createMode(value: string);
    resetCreateMode(): void;
    get createModeInput(): string | undefined;
    private _defaultIdentityType?;
    get defaultIdentityType(): string;
    set defaultIdentityType(value: string);
    resetDefaultIdentityType(): void;
    get defaultIdentityTypeInput(): string | undefined;
    get endpoint(): string;
    private _freeTierEnabled?;
    get freeTierEnabled(): boolean | cdktn.IResolvable;
    set freeTierEnabled(value: boolean | cdktn.IResolvable);
    resetFreeTierEnabled(): void;
    get freeTierEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipRangeFilter?;
    get ipRangeFilter(): string[];
    set ipRangeFilter(value: string[]);
    resetIpRangeFilter(): void;
    get ipRangeFilterInput(): string[] | undefined;
    private _isVirtualNetworkFilterEnabled?;
    get isVirtualNetworkFilterEnabled(): boolean | cdktn.IResolvable;
    set isVirtualNetworkFilterEnabled(value: boolean | cdktn.IResolvable);
    resetIsVirtualNetworkFilterEnabled(): void;
    get isVirtualNetworkFilterEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _keyVaultKeyId?;
    get keyVaultKeyId(): string;
    set keyVaultKeyId(value: string);
    resetKeyVaultKeyId(): void;
    get keyVaultKeyIdInput(): string | undefined;
    private _kind?;
    get kind(): string;
    set kind(value: string);
    resetKind(): void;
    get kindInput(): string | undefined;
    private _localAuthenticationEnabled?;
    get localAuthenticationEnabled(): boolean | cdktn.IResolvable;
    set localAuthenticationEnabled(value: boolean | cdktn.IResolvable);
    resetLocalAuthenticationEnabled(): void;
    get localAuthenticationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _minimalTlsVersion?;
    get minimalTlsVersion(): string;
    set minimalTlsVersion(value: string);
    resetMinimalTlsVersion(): void;
    get minimalTlsVersionInput(): string | undefined;
    private _mongoServerVersion?;
    get mongoServerVersion(): string;
    set mongoServerVersion(value: string);
    resetMongoServerVersion(): void;
    get mongoServerVersionInput(): string | undefined;
    private _multipleWriteLocationsEnabled?;
    get multipleWriteLocationsEnabled(): boolean | cdktn.IResolvable;
    set multipleWriteLocationsEnabled(value: boolean | cdktn.IResolvable);
    resetMultipleWriteLocationsEnabled(): void;
    get multipleWriteLocationsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkAclBypassForAzureServices?;
    get networkAclBypassForAzureServices(): boolean | cdktn.IResolvable;
    set networkAclBypassForAzureServices(value: boolean | cdktn.IResolvable);
    resetNetworkAclBypassForAzureServices(): void;
    get networkAclBypassForAzureServicesInput(): boolean | cdktn.IResolvable | undefined;
    private _networkAclBypassIds?;
    get networkAclBypassIds(): string[];
    set networkAclBypassIds(value: string[]);
    resetNetworkAclBypassIds(): void;
    get networkAclBypassIdsInput(): string[] | undefined;
    private _offerType?;
    get offerType(): string;
    set offerType(value: string);
    get offerTypeInput(): string | undefined;
    private _partitionMergeEnabled?;
    get partitionMergeEnabled(): boolean | cdktn.IResolvable;
    set partitionMergeEnabled(value: boolean | cdktn.IResolvable);
    resetPartitionMergeEnabled(): void;
    get partitionMergeEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get primaryKey(): string;
    get primaryMongodbConnectionString(): string;
    get primaryReadonlyKey(): string;
    get primaryReadonlyMongodbConnectionString(): string;
    get primaryReadonlySqlConnectionString(): string;
    get primarySqlConnectionString(): string;
    private _publicNetworkAccessEnabled?;
    get publicNetworkAccessEnabled(): boolean | cdktn.IResolvable;
    set publicNetworkAccessEnabled(value: boolean | cdktn.IResolvable);
    resetPublicNetworkAccessEnabled(): void;
    get publicNetworkAccessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get readEndpoints(): string[];
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    get secondaryKey(): string;
    get secondaryMongodbConnectionString(): string;
    get secondaryReadonlyKey(): string;
    get secondaryReadonlyMongodbConnectionString(): string;
    get secondaryReadonlySqlConnectionString(): string;
    get secondarySqlConnectionString(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get writeEndpoints(): string[];
    private _analyticalStorage;
    get analyticalStorage(): CosmosdbAccountAnalyticalStorageOutputReference;
    putAnalyticalStorage(value: CosmosdbAccountAnalyticalStorage): void;
    resetAnalyticalStorage(): void;
    get analyticalStorageInput(): CosmosdbAccountAnalyticalStorage | undefined;
    private _backup;
    get backup(): CosmosdbAccountBackupOutputReference;
    putBackup(value: CosmosdbAccountBackup): void;
    resetBackup(): void;
    get backupInput(): CosmosdbAccountBackup | undefined;
    private _capabilities;
    get capabilities(): CosmosdbAccountCapabilitiesList;
    putCapabilities(value: CosmosdbAccountCapabilities[] | cdktn.IResolvable): void;
    resetCapabilities(): void;
    get capabilitiesInput(): cdktn.IResolvable | CosmosdbAccountCapabilities[] | undefined;
    private _capacity;
    get capacity(): CosmosdbAccountCapacityOutputReference;
    putCapacity(value: CosmosdbAccountCapacity): void;
    resetCapacity(): void;
    get capacityInput(): CosmosdbAccountCapacity | undefined;
    private _consistencyPolicy;
    get consistencyPolicy(): CosmosdbAccountConsistencyPolicyOutputReference;
    putConsistencyPolicy(value: CosmosdbAccountConsistencyPolicy): void;
    get consistencyPolicyInput(): CosmosdbAccountConsistencyPolicy | undefined;
    private _corsRule;
    get corsRule(): CosmosdbAccountCorsRuleOutputReference;
    putCorsRule(value: CosmosdbAccountCorsRule): void;
    resetCorsRule(): void;
    get corsRuleInput(): CosmosdbAccountCorsRule | undefined;
    private _geoLocation;
    get geoLocation(): CosmosdbAccountGeoLocationList;
    putGeoLocation(value: CosmosdbAccountGeoLocation[] | cdktn.IResolvable): void;
    get geoLocationInput(): cdktn.IResolvable | CosmosdbAccountGeoLocation[] | undefined;
    private _identity;
    get identity(): CosmosdbAccountIdentityOutputReference;
    putIdentity(value: CosmosdbAccountIdentity): void;
    resetIdentity(): void;
    get identityInput(): CosmosdbAccountIdentity | undefined;
    private _restore;
    get restore(): CosmosdbAccountRestoreOutputReference;
    putRestore(value: CosmosdbAccountRestore): void;
    resetRestore(): void;
    get restoreInput(): CosmosdbAccountRestore | undefined;
    private _timeouts;
    get timeouts(): CosmosdbAccountTimeoutsOutputReference;
    putTimeouts(value: CosmosdbAccountTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CosmosdbAccountTimeouts | undefined;
    private _virtualNetworkRule;
    get virtualNetworkRule(): CosmosdbAccountVirtualNetworkRuleList;
    putVirtualNetworkRule(value: CosmosdbAccountVirtualNetworkRule[] | cdktn.IResolvable): void;
    resetVirtualNetworkRule(): void;
    get virtualNetworkRuleInput(): cdktn.IResolvable | CosmosdbAccountVirtualNetworkRule[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
