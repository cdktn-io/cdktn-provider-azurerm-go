/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CdnFrontdoorBatchRuleSetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#cdn_frontdoor_profile_id CdnFrontdoorBatchRuleSet#cdn_frontdoor_profile_id}
    */
    readonly cdnFrontdoorProfileId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#name CdnFrontdoorBatchRuleSet#name}
    */
    readonly name: string;
    /**
    * rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#rule CdnFrontdoorBatchRuleSet#rule}
    */
    readonly rule: CdnFrontdoorBatchRuleSetRule[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#timeouts CdnFrontdoorBatchRuleSet#timeouts}
    */
    readonly timeouts?: CdnFrontdoorBatchRuleSetTimeouts;
}
export interface CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#header_name CdnFrontdoorBatchRuleSet#header_name}
    */
    readonly headerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#header_value CdnFrontdoorBatchRuleSet#header_value}
    */
    readonly headerValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
}
export declare function cdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeaderToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeader | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeaderToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeader | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeader | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeader | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeaderList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeaderOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#header_name CdnFrontdoorBatchRuleSet#header_name}
    */
    readonly headerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#header_value CdnFrontdoorBatchRuleSet#header_value}
    */
    readonly headerValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
}
export declare function cdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeaderToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeader | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeaderToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeader | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeader | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeader | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeaderList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeaderOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCaching {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#behaviour CdnFrontdoorBatchRuleSet#behaviour}
    */
    readonly behaviour: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#compression_enabled CdnFrontdoorBatchRuleSet#compression_enabled}
    */
    readonly compressionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#duration CdnFrontdoorBatchRuleSet#duration}
    */
    readonly duration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#query_string_behaviour CdnFrontdoorBatchRuleSet#query_string_behaviour}
    */
    readonly queryStringBehaviour?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#query_string_parameters CdnFrontdoorBatchRuleSet#query_string_parameters}
    */
    readonly queryStringParameters?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCachingToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCachingOutputReference | CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCaching): any;
export declare function cdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCachingToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCachingOutputReference | CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCaching): any;
export declare class CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCachingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCaching | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCaching | undefined);
    private _behaviour?;
    get behaviour(): string;
    set behaviour(value: string);
    get behaviourInput(): string | undefined;
    private _compressionEnabled?;
    get compressionEnabled(): boolean | cdktn.IResolvable;
    set compressionEnabled(value: boolean | cdktn.IResolvable);
    resetCompressionEnabled(): void;
    get compressionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _duration?;
    get duration(): string;
    set duration(value: string);
    resetDuration(): void;
    get durationInput(): string | undefined;
    private _queryStringBehaviour?;
    get queryStringBehaviour(): string;
    set queryStringBehaviour(value: string);
    resetQueryStringBehaviour(): void;
    get queryStringBehaviourInput(): string | undefined;
    private _queryStringParameters?;
    get queryStringParameters(): string[];
    set queryStringParameters(value: string[]);
    resetQueryStringParameters(): void;
    get queryStringParametersInput(): string[] | undefined;
}
export interface CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#cdn_frontdoor_origin_group_id CdnFrontdoorBatchRuleSet#cdn_frontdoor_origin_group_id}
    */
    readonly cdnFrontdoorOriginGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#forwarding_protocol CdnFrontdoorBatchRuleSet#forwarding_protocol}
    */
    readonly forwardingProtocol: string;
}
export declare function cdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroupToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroupOutputReference | CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroup): any;
export declare function cdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroupToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroupOutputReference | CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroup): any;
export declare class CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroup | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroup | undefined);
    private _cdnFrontdoorOriginGroupId?;
    get cdnFrontdoorOriginGroupId(): string;
    set cdnFrontdoorOriginGroupId(value: string);
    get cdnFrontdoorOriginGroupIdInput(): string | undefined;
    private _forwardingProtocol?;
    get forwardingProtocol(): string;
    set forwardingProtocol(value: string);
    get forwardingProtocolInput(): string | undefined;
}
export interface CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverride {
    /**
    * caching block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#caching CdnFrontdoorBatchRuleSet#caching}
    */
    readonly caching: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCaching;
    /**
    * origin_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#origin_group CdnFrontdoorBatchRuleSet#origin_group}
    */
    readonly originGroup?: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroup;
}
export declare function cdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOutputReference | CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverride): any;
export declare function cdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOutputReference | CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverride): any;
export declare class CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverride | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverride | undefined);
    private _caching;
    get caching(): CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCachingOutputReference;
    putCaching(value: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCaching): void;
    get cachingInput(): CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideCaching | undefined;
    private _originGroup;
    get originGroup(): CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroupOutputReference;
    putOriginGroup(value: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroup): void;
    resetOriginGroup(): void;
    get originGroupInput(): CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOriginGroup | undefined;
}
export interface CdnFrontdoorBatchRuleSetRuleActionsUrlRedirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#destination_fragment CdnFrontdoorBatchRuleSet#destination_fragment}
    */
    readonly destinationFragment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#destination_host_name CdnFrontdoorBatchRuleSet#destination_host_name}
    */
    readonly destinationHostName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#destination_path CdnFrontdoorBatchRuleSet#destination_path}
    */
    readonly destinationPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#query_string CdnFrontdoorBatchRuleSet#query_string}
    */
    readonly queryString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#redirect_protocol CdnFrontdoorBatchRuleSet#redirect_protocol}
    */
    readonly redirectProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#redirect_type CdnFrontdoorBatchRuleSet#redirect_type}
    */
    readonly redirectType: string;
}
export declare function cdnFrontdoorBatchRuleSetRuleActionsUrlRedirectToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsUrlRedirectOutputReference | CdnFrontdoorBatchRuleSetRuleActionsUrlRedirect): any;
export declare function cdnFrontdoorBatchRuleSetRuleActionsUrlRedirectToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsUrlRedirectOutputReference | CdnFrontdoorBatchRuleSetRuleActionsUrlRedirect): any;
export declare class CdnFrontdoorBatchRuleSetRuleActionsUrlRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleActionsUrlRedirect | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleActionsUrlRedirect | undefined);
    private _destinationFragment?;
    get destinationFragment(): string;
    set destinationFragment(value: string);
    resetDestinationFragment(): void;
    get destinationFragmentInput(): string | undefined;
    private _destinationHostName?;
    get destinationHostName(): string;
    set destinationHostName(value: string);
    resetDestinationHostName(): void;
    get destinationHostNameInput(): string | undefined;
    private _destinationPath?;
    get destinationPath(): string;
    set destinationPath(value: string);
    resetDestinationPath(): void;
    get destinationPathInput(): string | undefined;
    private _queryString?;
    get queryString(): string;
    set queryString(value: string);
    resetQueryString(): void;
    get queryStringInput(): string | undefined;
    private _redirectProtocol?;
    get redirectProtocol(): string;
    set redirectProtocol(value: string);
    resetRedirectProtocol(): void;
    get redirectProtocolInput(): string | undefined;
    private _redirectType?;
    get redirectType(): string;
    set redirectType(value: string);
    get redirectTypeInput(): string | undefined;
}
export interface CdnFrontdoorBatchRuleSetRuleActionsUrlRewrite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#destination_path CdnFrontdoorBatchRuleSet#destination_path}
    */
    readonly destinationPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#preserve_unmatched_path_enabled CdnFrontdoorBatchRuleSet#preserve_unmatched_path_enabled}
    */
    readonly preserveUnmatchedPathEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#source_pattern CdnFrontdoorBatchRuleSet#source_pattern}
    */
    readonly sourcePattern: string;
}
export declare function cdnFrontdoorBatchRuleSetRuleActionsUrlRewriteToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsUrlRewriteOutputReference | CdnFrontdoorBatchRuleSetRuleActionsUrlRewrite): any;
export declare function cdnFrontdoorBatchRuleSetRuleActionsUrlRewriteToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsUrlRewriteOutputReference | CdnFrontdoorBatchRuleSetRuleActionsUrlRewrite): any;
export declare class CdnFrontdoorBatchRuleSetRuleActionsUrlRewriteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleActionsUrlRewrite | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleActionsUrlRewrite | undefined);
    private _destinationPath?;
    get destinationPath(): string;
    set destinationPath(value: string);
    get destinationPathInput(): string | undefined;
    private _preserveUnmatchedPathEnabled?;
    get preserveUnmatchedPathEnabled(): boolean | cdktn.IResolvable;
    set preserveUnmatchedPathEnabled(value: boolean | cdktn.IResolvable);
    resetPreserveUnmatchedPathEnabled(): void;
    get preserveUnmatchedPathEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sourcePattern?;
    get sourcePattern(): string;
    set sourcePattern(value: string);
    get sourcePatternInput(): string | undefined;
}
export interface CdnFrontdoorBatchRuleSetRuleActions {
    /**
    * modify_request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#modify_request_header CdnFrontdoorBatchRuleSet#modify_request_header}
    */
    readonly modifyRequestHeader?: CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeader[] | cdktn.IResolvable;
    /**
    * modify_response_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#modify_response_header CdnFrontdoorBatchRuleSet#modify_response_header}
    */
    readonly modifyResponseHeader?: CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeader[] | cdktn.IResolvable;
    /**
    * route_configuration_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#route_configuration_override CdnFrontdoorBatchRuleSet#route_configuration_override}
    */
    readonly routeConfigurationOverride?: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverride;
    /**
    * url_redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#url_redirect CdnFrontdoorBatchRuleSet#url_redirect}
    */
    readonly urlRedirect?: CdnFrontdoorBatchRuleSetRuleActionsUrlRedirect;
    /**
    * url_rewrite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#url_rewrite CdnFrontdoorBatchRuleSet#url_rewrite}
    */
    readonly urlRewrite?: CdnFrontdoorBatchRuleSetRuleActionsUrlRewrite;
}
export declare function cdnFrontdoorBatchRuleSetRuleActionsToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsOutputReference | CdnFrontdoorBatchRuleSetRuleActions): any;
export declare function cdnFrontdoorBatchRuleSetRuleActionsToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleActionsOutputReference | CdnFrontdoorBatchRuleSetRuleActions): any;
export declare class CdnFrontdoorBatchRuleSetRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleActions | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleActions | undefined);
    private _modifyRequestHeader;
    get modifyRequestHeader(): CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeaderList;
    putModifyRequestHeader(value: CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeader[] | cdktn.IResolvable): void;
    resetModifyRequestHeader(): void;
    get modifyRequestHeaderInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleActionsModifyRequestHeader[] | undefined;
    private _modifyResponseHeader;
    get modifyResponseHeader(): CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeaderList;
    putModifyResponseHeader(value: CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeader[] | cdktn.IResolvable): void;
    resetModifyResponseHeader(): void;
    get modifyResponseHeaderInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleActionsModifyResponseHeader[] | undefined;
    private _routeConfigurationOverride;
    get routeConfigurationOverride(): CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverrideOutputReference;
    putRouteConfigurationOverride(value: CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverride): void;
    resetRouteConfigurationOverride(): void;
    get routeConfigurationOverrideInput(): CdnFrontdoorBatchRuleSetRuleActionsRouteConfigurationOverride | undefined;
    private _urlRedirect;
    get urlRedirect(): CdnFrontdoorBatchRuleSetRuleActionsUrlRedirectOutputReference;
    putUrlRedirect(value: CdnFrontdoorBatchRuleSetRuleActionsUrlRedirect): void;
    resetUrlRedirect(): void;
    get urlRedirectInput(): CdnFrontdoorBatchRuleSetRuleActionsUrlRedirect | undefined;
    private _urlRewrite;
    get urlRewrite(): CdnFrontdoorBatchRuleSetRuleActionsUrlRewriteOutputReference;
    putUrlRewrite(value: CdnFrontdoorBatchRuleSetRuleActionsUrlRewrite): void;
    resetUrlRewrite(): void;
    get urlRewriteInput(): CdnFrontdoorBatchRuleSetRuleActionsUrlRewrite | undefined;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsClientPort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsClientPortToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsClientPort | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsClientPortToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsClientPort | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsClientPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsClientPort | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsClientPort | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsClientPortList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsClientPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsClientPortOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsDeviceType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsDeviceTypeToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsDeviceType | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsDeviceTypeToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsDeviceType | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsDeviceTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsDeviceType | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsDeviceType | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsDeviceTypeList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsDeviceType[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsDeviceTypeOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsHostName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#transforms CdnFrontdoorBatchRuleSet#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsHostNameToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsHostName | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsHostNameToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsHostName | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsHostNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsHostName | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsHostName | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsHostNameList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsHostName[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsHostNameOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsHttpVersion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsHttpVersionToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsHttpVersion | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsHttpVersionToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsHttpVersion | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsHttpVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsHttpVersion | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsHttpVersion | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsHttpVersionList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsHttpVersion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsHttpVersionOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsPostArgument {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#name CdnFrontdoorBatchRuleSet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#transforms CdnFrontdoorBatchRuleSet#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsPostArgumentToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsPostArgument | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsPostArgumentToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsPostArgument | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsPostArgumentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsPostArgument | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsPostArgument | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsPostArgumentList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsPostArgument[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsPostArgumentOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsQueryString {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#transforms CdnFrontdoorBatchRuleSet#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsQueryStringToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsQueryString | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsQueryStringToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsQueryString | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsQueryStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsQueryString | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsQueryString | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsQueryStringList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsQueryString[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsQueryStringOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRemoteAddressToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddress | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRemoteAddressToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddress | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddress | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddressList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddressOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsRequestBody {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#transforms CdnFrontdoorBatchRuleSet#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestBodyToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestBody | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestBodyToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestBody | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestBodyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsRequestBody | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestBody | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestBodyList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsRequestBody[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsRequestBodyOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsRequestCookies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#name CdnFrontdoorBatchRuleSet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#transforms CdnFrontdoorBatchRuleSet#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestCookiesToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestCookies | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestCookiesToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestCookies | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestCookiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsRequestCookies | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestCookies | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestCookiesList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsRequestCookies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsRequestCookiesOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtension {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#transforms CdnFrontdoorBatchRuleSet#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtensionToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtension | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtensionToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtension | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtensionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtension | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtension | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtensionList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtension[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtensionOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsRequestFilename {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#transforms CdnFrontdoorBatchRuleSet#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestFilenameToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestFilename | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestFilenameToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestFilename | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestFilenameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsRequestFilename | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestFilename | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestFilenameList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsRequestFilename[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsRequestFilenameOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsRequestHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#name CdnFrontdoorBatchRuleSet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#transforms CdnFrontdoorBatchRuleSet#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestHeaderToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestHeader | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestHeaderToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestHeader | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsRequestHeader | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestHeaderList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsRequestHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsRequestHeaderOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsRequestMethod {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestMethodToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestMethod | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestMethodToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestMethod | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsRequestMethod | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestMethod | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestMethodList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsRequestMethod[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsRequestMethodOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsRequestPath {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#transforms CdnFrontdoorBatchRuleSet#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestPathToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestPath | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestPathToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestPath | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsRequestPath | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestPath | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestPathList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsRequestPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsRequestPathOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsRequestScheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestSchemeToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestScheme | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestSchemeToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestScheme | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestSchemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsRequestScheme | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestScheme | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestSchemeList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsRequestScheme[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsRequestSchemeOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsRequestUrl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#transforms CdnFrontdoorBatchRuleSet#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestUrlToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestUrl | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsRequestUrlToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsRequestUrl | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsRequestUrl | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestUrl | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsRequestUrlList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsRequestUrl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsRequestUrlOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsServerPort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsServerPortToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsServerPort | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsServerPortToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsServerPort | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsServerPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsServerPort | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsServerPort | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsServerPortList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsServerPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsServerPortOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsSocketAddress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsSocketAddressToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsSocketAddress | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsSocketAddressToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsSocketAddress | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsSocketAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsSocketAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsSocketAddress | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsSocketAddressList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsSocketAddress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsSocketAddressOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditionsSslProtocol {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#operator CdnFrontdoorBatchRuleSet#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#values CdnFrontdoorBatchRuleSet#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsSslProtocolToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsSslProtocol | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsSslProtocolToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsSslProtocol | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsSslProtocolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditionsSslProtocol | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditionsSslProtocol | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleConditionsSslProtocolList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRuleConditionsSslProtocol[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleConditionsSslProtocolOutputReference;
}
export interface CdnFrontdoorBatchRuleSetRuleConditions {
    /**
    * client_port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#client_port CdnFrontdoorBatchRuleSet#client_port}
    */
    readonly clientPort?: CdnFrontdoorBatchRuleSetRuleConditionsClientPort[] | cdktn.IResolvable;
    /**
    * device_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#device_type CdnFrontdoorBatchRuleSet#device_type}
    */
    readonly deviceType?: CdnFrontdoorBatchRuleSetRuleConditionsDeviceType[] | cdktn.IResolvable;
    /**
    * host_name block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#host_name CdnFrontdoorBatchRuleSet#host_name}
    */
    readonly hostName?: CdnFrontdoorBatchRuleSetRuleConditionsHostName[] | cdktn.IResolvable;
    /**
    * http_version block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#http_version CdnFrontdoorBatchRuleSet#http_version}
    */
    readonly httpVersion?: CdnFrontdoorBatchRuleSetRuleConditionsHttpVersion[] | cdktn.IResolvable;
    /**
    * post_argument block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#post_argument CdnFrontdoorBatchRuleSet#post_argument}
    */
    readonly postArgument?: CdnFrontdoorBatchRuleSetRuleConditionsPostArgument[] | cdktn.IResolvable;
    /**
    * query_string block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#query_string CdnFrontdoorBatchRuleSet#query_string}
    */
    readonly queryString?: CdnFrontdoorBatchRuleSetRuleConditionsQueryString[] | cdktn.IResolvable;
    /**
    * remote_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#remote_address CdnFrontdoorBatchRuleSet#remote_address}
    */
    readonly remoteAddress?: CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddress[] | cdktn.IResolvable;
    /**
    * request_body block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#request_body CdnFrontdoorBatchRuleSet#request_body}
    */
    readonly requestBody?: CdnFrontdoorBatchRuleSetRuleConditionsRequestBody[] | cdktn.IResolvable;
    /**
    * request_cookies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#request_cookies CdnFrontdoorBatchRuleSet#request_cookies}
    */
    readonly requestCookies?: CdnFrontdoorBatchRuleSetRuleConditionsRequestCookies[] | cdktn.IResolvable;
    /**
    * request_file_extension block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#request_file_extension CdnFrontdoorBatchRuleSet#request_file_extension}
    */
    readonly requestFileExtension?: CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtension[] | cdktn.IResolvable;
    /**
    * request_filename block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#request_filename CdnFrontdoorBatchRuleSet#request_filename}
    */
    readonly requestFilename?: CdnFrontdoorBatchRuleSetRuleConditionsRequestFilename[] | cdktn.IResolvable;
    /**
    * request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#request_header CdnFrontdoorBatchRuleSet#request_header}
    */
    readonly requestHeader?: CdnFrontdoorBatchRuleSetRuleConditionsRequestHeader[] | cdktn.IResolvable;
    /**
    * request_method block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#request_method CdnFrontdoorBatchRuleSet#request_method}
    */
    readonly requestMethod?: CdnFrontdoorBatchRuleSetRuleConditionsRequestMethod[] | cdktn.IResolvable;
    /**
    * request_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#request_path CdnFrontdoorBatchRuleSet#request_path}
    */
    readonly requestPath?: CdnFrontdoorBatchRuleSetRuleConditionsRequestPath[] | cdktn.IResolvable;
    /**
    * request_scheme block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#request_scheme CdnFrontdoorBatchRuleSet#request_scheme}
    */
    readonly requestScheme?: CdnFrontdoorBatchRuleSetRuleConditionsRequestScheme[] | cdktn.IResolvable;
    /**
    * request_url block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#request_url CdnFrontdoorBatchRuleSet#request_url}
    */
    readonly requestUrl?: CdnFrontdoorBatchRuleSetRuleConditionsRequestUrl[] | cdktn.IResolvable;
    /**
    * server_port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#server_port CdnFrontdoorBatchRuleSet#server_port}
    */
    readonly serverPort?: CdnFrontdoorBatchRuleSetRuleConditionsServerPort[] | cdktn.IResolvable;
    /**
    * socket_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#socket_address CdnFrontdoorBatchRuleSet#socket_address}
    */
    readonly socketAddress?: CdnFrontdoorBatchRuleSetRuleConditionsSocketAddress[] | cdktn.IResolvable;
    /**
    * ssl_protocol block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#ssl_protocol CdnFrontdoorBatchRuleSet#ssl_protocol}
    */
    readonly sslProtocol?: CdnFrontdoorBatchRuleSetRuleConditionsSslProtocol[] | cdktn.IResolvable;
}
export declare function cdnFrontdoorBatchRuleSetRuleConditionsToTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsOutputReference | CdnFrontdoorBatchRuleSetRuleConditions): any;
export declare function cdnFrontdoorBatchRuleSetRuleConditionsToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRuleConditionsOutputReference | CdnFrontdoorBatchRuleSetRuleConditions): any;
export declare class CdnFrontdoorBatchRuleSetRuleConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorBatchRuleSetRuleConditions | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRuleConditions | undefined);
    private _clientPort;
    get clientPort(): CdnFrontdoorBatchRuleSetRuleConditionsClientPortList;
    putClientPort(value: CdnFrontdoorBatchRuleSetRuleConditionsClientPort[] | cdktn.IResolvable): void;
    resetClientPort(): void;
    get clientPortInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsClientPort[] | undefined;
    private _deviceType;
    get deviceType(): CdnFrontdoorBatchRuleSetRuleConditionsDeviceTypeList;
    putDeviceType(value: CdnFrontdoorBatchRuleSetRuleConditionsDeviceType[] | cdktn.IResolvable): void;
    resetDeviceType(): void;
    get deviceTypeInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsDeviceType[] | undefined;
    private _hostName;
    get hostName(): CdnFrontdoorBatchRuleSetRuleConditionsHostNameList;
    putHostName(value: CdnFrontdoorBatchRuleSetRuleConditionsHostName[] | cdktn.IResolvable): void;
    resetHostName(): void;
    get hostNameInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsHostName[] | undefined;
    private _httpVersion;
    get httpVersion(): CdnFrontdoorBatchRuleSetRuleConditionsHttpVersionList;
    putHttpVersion(value: CdnFrontdoorBatchRuleSetRuleConditionsHttpVersion[] | cdktn.IResolvable): void;
    resetHttpVersion(): void;
    get httpVersionInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsHttpVersion[] | undefined;
    private _postArgument;
    get postArgument(): CdnFrontdoorBatchRuleSetRuleConditionsPostArgumentList;
    putPostArgument(value: CdnFrontdoorBatchRuleSetRuleConditionsPostArgument[] | cdktn.IResolvable): void;
    resetPostArgument(): void;
    get postArgumentInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsPostArgument[] | undefined;
    private _queryString;
    get queryString(): CdnFrontdoorBatchRuleSetRuleConditionsQueryStringList;
    putQueryString(value: CdnFrontdoorBatchRuleSetRuleConditionsQueryString[] | cdktn.IResolvable): void;
    resetQueryString(): void;
    get queryStringInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsQueryString[] | undefined;
    private _remoteAddress;
    get remoteAddress(): CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddressList;
    putRemoteAddress(value: CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddress[] | cdktn.IResolvable): void;
    resetRemoteAddress(): void;
    get remoteAddressInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsRemoteAddress[] | undefined;
    private _requestBody;
    get requestBody(): CdnFrontdoorBatchRuleSetRuleConditionsRequestBodyList;
    putRequestBody(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestBody[] | cdktn.IResolvable): void;
    resetRequestBody(): void;
    get requestBodyInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsRequestBody[] | undefined;
    private _requestCookies;
    get requestCookies(): CdnFrontdoorBatchRuleSetRuleConditionsRequestCookiesList;
    putRequestCookies(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestCookies[] | cdktn.IResolvable): void;
    resetRequestCookies(): void;
    get requestCookiesInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsRequestCookies[] | undefined;
    private _requestFileExtension;
    get requestFileExtension(): CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtensionList;
    putRequestFileExtension(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtension[] | cdktn.IResolvable): void;
    resetRequestFileExtension(): void;
    get requestFileExtensionInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsRequestFileExtension[] | undefined;
    private _requestFilename;
    get requestFilename(): CdnFrontdoorBatchRuleSetRuleConditionsRequestFilenameList;
    putRequestFilename(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestFilename[] | cdktn.IResolvable): void;
    resetRequestFilename(): void;
    get requestFilenameInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsRequestFilename[] | undefined;
    private _requestHeader;
    get requestHeader(): CdnFrontdoorBatchRuleSetRuleConditionsRequestHeaderList;
    putRequestHeader(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestHeader[] | cdktn.IResolvable): void;
    resetRequestHeader(): void;
    get requestHeaderInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsRequestHeader[] | undefined;
    private _requestMethod;
    get requestMethod(): CdnFrontdoorBatchRuleSetRuleConditionsRequestMethodList;
    putRequestMethod(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestMethod[] | cdktn.IResolvable): void;
    resetRequestMethod(): void;
    get requestMethodInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsRequestMethod[] | undefined;
    private _requestPath;
    get requestPath(): CdnFrontdoorBatchRuleSetRuleConditionsRequestPathList;
    putRequestPath(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestPath[] | cdktn.IResolvable): void;
    resetRequestPath(): void;
    get requestPathInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsRequestPath[] | undefined;
    private _requestScheme;
    get requestScheme(): CdnFrontdoorBatchRuleSetRuleConditionsRequestSchemeList;
    putRequestScheme(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestScheme[] | cdktn.IResolvable): void;
    resetRequestScheme(): void;
    get requestSchemeInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsRequestScheme[] | undefined;
    private _requestUrl;
    get requestUrl(): CdnFrontdoorBatchRuleSetRuleConditionsRequestUrlList;
    putRequestUrl(value: CdnFrontdoorBatchRuleSetRuleConditionsRequestUrl[] | cdktn.IResolvable): void;
    resetRequestUrl(): void;
    get requestUrlInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsRequestUrl[] | undefined;
    private _serverPort;
    get serverPort(): CdnFrontdoorBatchRuleSetRuleConditionsServerPortList;
    putServerPort(value: CdnFrontdoorBatchRuleSetRuleConditionsServerPort[] | cdktn.IResolvable): void;
    resetServerPort(): void;
    get serverPortInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsServerPort[] | undefined;
    private _socketAddress;
    get socketAddress(): CdnFrontdoorBatchRuleSetRuleConditionsSocketAddressList;
    putSocketAddress(value: CdnFrontdoorBatchRuleSetRuleConditionsSocketAddress[] | cdktn.IResolvable): void;
    resetSocketAddress(): void;
    get socketAddressInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsSocketAddress[] | undefined;
    private _sslProtocol;
    get sslProtocol(): CdnFrontdoorBatchRuleSetRuleConditionsSslProtocolList;
    putSslProtocol(value: CdnFrontdoorBatchRuleSetRuleConditionsSslProtocol[] | cdktn.IResolvable): void;
    resetSslProtocol(): void;
    get sslProtocolInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRuleConditionsSslProtocol[] | undefined;
}
export interface CdnFrontdoorBatchRuleSetRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#behaviour_on_match CdnFrontdoorBatchRuleSet#behaviour_on_match}
    */
    readonly behaviourOnMatch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#name CdnFrontdoorBatchRuleSet#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#order CdnFrontdoorBatchRuleSet#order}
    */
    readonly order: number;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#actions CdnFrontdoorBatchRuleSet#actions}
    */
    readonly actions: CdnFrontdoorBatchRuleSetRuleActions;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#conditions CdnFrontdoorBatchRuleSet#conditions}
    */
    readonly conditions?: CdnFrontdoorBatchRuleSetRuleConditions;
}
export declare function cdnFrontdoorBatchRuleSetRuleToTerraform(struct?: CdnFrontdoorBatchRuleSetRule | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetRuleToHclTerraform(struct?: CdnFrontdoorBatchRuleSetRule | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorBatchRuleSetRule | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetRule | cdktn.IResolvable | undefined);
    private _behaviourOnMatch?;
    get behaviourOnMatch(): string;
    set behaviourOnMatch(value: string);
    resetBehaviourOnMatch(): void;
    get behaviourOnMatchInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _order?;
    get order(): number;
    set order(value: number);
    get orderInput(): number | undefined;
    private _actions;
    get actions(): CdnFrontdoorBatchRuleSetRuleActionsOutputReference;
    putActions(value: CdnFrontdoorBatchRuleSetRuleActions): void;
    get actionsInput(): CdnFrontdoorBatchRuleSetRuleActions | undefined;
    private _conditions;
    get conditions(): CdnFrontdoorBatchRuleSetRuleConditionsOutputReference;
    putConditions(value: CdnFrontdoorBatchRuleSetRuleConditions): void;
    resetConditions(): void;
    get conditionsInput(): CdnFrontdoorBatchRuleSetRuleConditions | undefined;
}
export declare class CdnFrontdoorBatchRuleSetRuleList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorBatchRuleSetRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorBatchRuleSetRuleOutputReference;
}
export interface CdnFrontdoorBatchRuleSetTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#create CdnFrontdoorBatchRuleSet#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#delete CdnFrontdoorBatchRuleSet#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#read CdnFrontdoorBatchRuleSet#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#update CdnFrontdoorBatchRuleSet#update}
    */
    readonly update?: string;
}
export declare function cdnFrontdoorBatchRuleSetTimeoutsToTerraform(struct?: CdnFrontdoorBatchRuleSetTimeouts | cdktn.IResolvable): any;
export declare function cdnFrontdoorBatchRuleSetTimeoutsToHclTerraform(struct?: CdnFrontdoorBatchRuleSetTimeouts | cdktn.IResolvable): any;
export declare class CdnFrontdoorBatchRuleSetTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorBatchRuleSetTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorBatchRuleSetTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set azurerm_cdn_frontdoor_batch_rule_set}
*/
export declare class CdnFrontdoorBatchRuleSet extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_cdn_frontdoor_batch_rule_set";
    /**
    * Generates CDKTN code for importing a CdnFrontdoorBatchRuleSet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CdnFrontdoorBatchRuleSet to import
    * @param importFromId The id of the existing CdnFrontdoorBatchRuleSet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CdnFrontdoorBatchRuleSet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.11.0/docs/resources/cdn_frontdoor_batch_rule_set azurerm_cdn_frontdoor_batch_rule_set} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CdnFrontdoorBatchRuleSetConfig
    */
    constructor(scope: Construct, id: string, config: CdnFrontdoorBatchRuleSetConfig);
    private _cdnFrontdoorProfileId?;
    get cdnFrontdoorProfileId(): string;
    set cdnFrontdoorProfileId(value: string);
    get cdnFrontdoorProfileIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rule;
    get rule(): CdnFrontdoorBatchRuleSetRuleList;
    putRule(value: CdnFrontdoorBatchRuleSetRule[] | cdktn.IResolvable): void;
    get ruleInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetRule[] | undefined;
    private _timeouts;
    get timeouts(): CdnFrontdoorBatchRuleSetTimeoutsOutputReference;
    putTimeouts(value: CdnFrontdoorBatchRuleSetTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CdnFrontdoorBatchRuleSetTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
