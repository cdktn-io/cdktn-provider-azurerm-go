/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApiManagementAuthorizationServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#api_management_name ApiManagementAuthorizationServer#api_management_name}
    */
    readonly apiManagementName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#authorization_endpoint ApiManagementAuthorizationServer#authorization_endpoint}
    */
    readonly authorizationEndpoint: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#authorization_methods ApiManagementAuthorizationServer#authorization_methods}
    */
    readonly authorizationMethods: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#bearer_token_sending_methods ApiManagementAuthorizationServer#bearer_token_sending_methods}
    */
    readonly bearerTokenSendingMethods?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#client_authentication_method ApiManagementAuthorizationServer#client_authentication_method}
    */
    readonly clientAuthenticationMethod?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#client_id ApiManagementAuthorizationServer#client_id}
    */
    readonly clientId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#client_registration_endpoint ApiManagementAuthorizationServer#client_registration_endpoint}
    */
    readonly clientRegistrationEndpoint: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#client_secret ApiManagementAuthorizationServer#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#default_scope ApiManagementAuthorizationServer#default_scope}
    */
    readonly defaultScope?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#description ApiManagementAuthorizationServer#description}
    */
    readonly description?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#display_name ApiManagementAuthorizationServer#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#grant_types ApiManagementAuthorizationServer#grant_types}
    */
    readonly grantTypes: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#id ApiManagementAuthorizationServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#name ApiManagementAuthorizationServer#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#resource_group_name ApiManagementAuthorizationServer#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#resource_owner_password ApiManagementAuthorizationServer#resource_owner_password}
    */
    readonly resourceOwnerPassword?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#resource_owner_username ApiManagementAuthorizationServer#resource_owner_username}
    */
    readonly resourceOwnerUsername?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#support_state ApiManagementAuthorizationServer#support_state}
    */
    readonly supportState?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#token_endpoint ApiManagementAuthorizationServer#token_endpoint}
    */
    readonly tokenEndpoint?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#timeouts ApiManagementAuthorizationServer#timeouts}
    */
    readonly timeouts?: ApiManagementAuthorizationServerTimeouts;
    /**
    * token_body_parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#token_body_parameter ApiManagementAuthorizationServer#token_body_parameter}
    */
    readonly tokenBodyParameter?: ApiManagementAuthorizationServerTokenBodyParameter[] | cdktn.IResolvable;
}
export interface ApiManagementAuthorizationServerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#create ApiManagementAuthorizationServer#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#delete ApiManagementAuthorizationServer#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#read ApiManagementAuthorizationServer#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#update ApiManagementAuthorizationServer#update}
    */
    readonly update?: string;
}
export declare function apiManagementAuthorizationServerTimeoutsToTerraform(struct?: ApiManagementAuthorizationServerTimeouts | cdktn.IResolvable): any;
export declare function apiManagementAuthorizationServerTimeoutsToHclTerraform(struct?: ApiManagementAuthorizationServerTimeouts | cdktn.IResolvable): any;
export declare class ApiManagementAuthorizationServerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApiManagementAuthorizationServerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementAuthorizationServerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ApiManagementAuthorizationServerTokenBodyParameter {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#name ApiManagementAuthorizationServer#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#value ApiManagementAuthorizationServer#value}
    */
    readonly value: string;
}
export declare function apiManagementAuthorizationServerTokenBodyParameterToTerraform(struct?: ApiManagementAuthorizationServerTokenBodyParameter | cdktn.IResolvable): any;
export declare function apiManagementAuthorizationServerTokenBodyParameterToHclTerraform(struct?: ApiManagementAuthorizationServerTokenBodyParameter | cdktn.IResolvable): any;
export declare class ApiManagementAuthorizationServerTokenBodyParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApiManagementAuthorizationServerTokenBodyParameter | cdktn.IResolvable | undefined;
    set internalValue(value: ApiManagementAuthorizationServerTokenBodyParameter | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class ApiManagementAuthorizationServerTokenBodyParameterList extends cdktn.ComplexList {
    internalValue?: ApiManagementAuthorizationServerTokenBodyParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApiManagementAuthorizationServerTokenBodyParameterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server azurerm_api_management_authorization_server}
*/
export declare class ApiManagementAuthorizationServer extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_api_management_authorization_server";
    /**
    * Generates CDKTN code for importing a ApiManagementAuthorizationServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApiManagementAuthorizationServer to import
    * @param importFromId The id of the existing ApiManagementAuthorizationServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApiManagementAuthorizationServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/api_management_authorization_server azurerm_api_management_authorization_server} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApiManagementAuthorizationServerConfig
    */
    constructor(scope: Construct, id: string, config: ApiManagementAuthorizationServerConfig);
    private _apiManagementName?;
    get apiManagementName(): string;
    set apiManagementName(value: string);
    get apiManagementNameInput(): string | undefined;
    private _authorizationEndpoint?;
    get authorizationEndpoint(): string;
    set authorizationEndpoint(value: string);
    get authorizationEndpointInput(): string | undefined;
    private _authorizationMethods?;
    get authorizationMethods(): string[];
    set authorizationMethods(value: string[]);
    get authorizationMethodsInput(): string[] | undefined;
    private _bearerTokenSendingMethods?;
    get bearerTokenSendingMethods(): string[];
    set bearerTokenSendingMethods(value: string[]);
    resetBearerTokenSendingMethods(): void;
    get bearerTokenSendingMethodsInput(): string[] | undefined;
    private _clientAuthenticationMethod?;
    get clientAuthenticationMethod(): string[];
    set clientAuthenticationMethod(value: string[]);
    resetClientAuthenticationMethod(): void;
    get clientAuthenticationMethodInput(): string[] | undefined;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    get clientIdInput(): string | undefined;
    private _clientRegistrationEndpoint?;
    get clientRegistrationEndpoint(): string;
    set clientRegistrationEndpoint(value: string);
    get clientRegistrationEndpointInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string;
    set clientSecret(value: string);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _defaultScope?;
    get defaultScope(): string;
    set defaultScope(value: string);
    resetDefaultScope(): void;
    get defaultScopeInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _grantTypes?;
    get grantTypes(): string[];
    set grantTypes(value: string[]);
    get grantTypesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _resourceOwnerPassword?;
    get resourceOwnerPassword(): string;
    set resourceOwnerPassword(value: string);
    resetResourceOwnerPassword(): void;
    get resourceOwnerPasswordInput(): string | undefined;
    private _resourceOwnerUsername?;
    get resourceOwnerUsername(): string;
    set resourceOwnerUsername(value: string);
    resetResourceOwnerUsername(): void;
    get resourceOwnerUsernameInput(): string | undefined;
    private _supportState?;
    get supportState(): boolean | cdktn.IResolvable;
    set supportState(value: boolean | cdktn.IResolvable);
    resetSupportState(): void;
    get supportStateInput(): boolean | cdktn.IResolvable | undefined;
    private _tokenEndpoint?;
    get tokenEndpoint(): string;
    set tokenEndpoint(value: string);
    resetTokenEndpoint(): void;
    get tokenEndpointInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApiManagementAuthorizationServerTimeoutsOutputReference;
    putTimeouts(value: ApiManagementAuthorizationServerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApiManagementAuthorizationServerTimeouts | undefined;
    private _tokenBodyParameter;
    get tokenBodyParameter(): ApiManagementAuthorizationServerTokenBodyParameterList;
    putTokenBodyParameter(value: ApiManagementAuthorizationServerTokenBodyParameter[] | cdktn.IResolvable): void;
    resetTokenBodyParameter(): void;
    get tokenBodyParameterInput(): cdktn.IResolvable | ApiManagementAuthorizationServerTokenBodyParameter[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
