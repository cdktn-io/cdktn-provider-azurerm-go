/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CosmosdbGremlinGraphConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#account_name CosmosdbGremlinGraph#account_name}
    */
    readonly accountName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#analytical_storage_ttl CosmosdbGremlinGraph#analytical_storage_ttl}
    */
    readonly analyticalStorageTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#database_name CosmosdbGremlinGraph#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#default_ttl CosmosdbGremlinGraph#default_ttl}
    */
    readonly defaultTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#id CosmosdbGremlinGraph#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#name CosmosdbGremlinGraph#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#partition_key_path CosmosdbGremlinGraph#partition_key_path}
    */
    readonly partitionKeyPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#partition_key_version CosmosdbGremlinGraph#partition_key_version}
    */
    readonly partitionKeyVersion?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#resource_group_name CosmosdbGremlinGraph#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#throughput CosmosdbGremlinGraph#throughput}
    */
    readonly throughput?: number;
    /**
    * autoscale_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#autoscale_settings CosmosdbGremlinGraph#autoscale_settings}
    */
    readonly autoscaleSettings?: CosmosdbGremlinGraphAutoscaleSettings;
    /**
    * conflict_resolution_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#conflict_resolution_policy CosmosdbGremlinGraph#conflict_resolution_policy}
    */
    readonly conflictResolutionPolicy?: CosmosdbGremlinGraphConflictResolutionPolicy;
    /**
    * index_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#index_policy CosmosdbGremlinGraph#index_policy}
    */
    readonly indexPolicy?: CosmosdbGremlinGraphIndexPolicy;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#timeouts CosmosdbGremlinGraph#timeouts}
    */
    readonly timeouts?: CosmosdbGremlinGraphTimeouts;
    /**
    * unique_key block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#unique_key CosmosdbGremlinGraph#unique_key}
    */
    readonly uniqueKey?: CosmosdbGremlinGraphUniqueKey[] | cdktn.IResolvable;
}
export interface CosmosdbGremlinGraphAutoscaleSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#max_throughput CosmosdbGremlinGraph#max_throughput}
    */
    readonly maxThroughput?: number;
}
export declare function cosmosdbGremlinGraphAutoscaleSettingsToTerraform(struct?: CosmosdbGremlinGraphAutoscaleSettingsOutputReference | CosmosdbGremlinGraphAutoscaleSettings): any;
export declare function cosmosdbGremlinGraphAutoscaleSettingsToHclTerraform(struct?: CosmosdbGremlinGraphAutoscaleSettingsOutputReference | CosmosdbGremlinGraphAutoscaleSettings): any;
export declare class CosmosdbGremlinGraphAutoscaleSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbGremlinGraphAutoscaleSettings | undefined;
    set internalValue(value: CosmosdbGremlinGraphAutoscaleSettings | undefined);
    private _maxThroughput?;
    get maxThroughput(): number;
    set maxThroughput(value: number);
    resetMaxThroughput(): void;
    get maxThroughputInput(): number | undefined;
}
export interface CosmosdbGremlinGraphConflictResolutionPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#conflict_resolution_path CosmosdbGremlinGraph#conflict_resolution_path}
    */
    readonly conflictResolutionPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#conflict_resolution_procedure CosmosdbGremlinGraph#conflict_resolution_procedure}
    */
    readonly conflictResolutionProcedure?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#mode CosmosdbGremlinGraph#mode}
    */
    readonly mode: string;
}
export declare function cosmosdbGremlinGraphConflictResolutionPolicyToTerraform(struct?: CosmosdbGremlinGraphConflictResolutionPolicyOutputReference | CosmosdbGremlinGraphConflictResolutionPolicy): any;
export declare function cosmosdbGremlinGraphConflictResolutionPolicyToHclTerraform(struct?: CosmosdbGremlinGraphConflictResolutionPolicyOutputReference | CosmosdbGremlinGraphConflictResolutionPolicy): any;
export declare class CosmosdbGremlinGraphConflictResolutionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbGremlinGraphConflictResolutionPolicy | undefined;
    set internalValue(value: CosmosdbGremlinGraphConflictResolutionPolicy | undefined);
    private _conflictResolutionPath?;
    get conflictResolutionPath(): string;
    set conflictResolutionPath(value: string);
    resetConflictResolutionPath(): void;
    get conflictResolutionPathInput(): string | undefined;
    private _conflictResolutionProcedure?;
    get conflictResolutionProcedure(): string;
    set conflictResolutionProcedure(value: string);
    resetConflictResolutionProcedure(): void;
    get conflictResolutionProcedureInput(): string | undefined;
    private _mode?;
    get mode(): string;
    set mode(value: string);
    get modeInput(): string | undefined;
}
export interface CosmosdbGremlinGraphIndexPolicyCompositeIndexIndex {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#order CosmosdbGremlinGraph#order}
    */
    readonly order: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#path CosmosdbGremlinGraph#path}
    */
    readonly path: string;
}
export declare function cosmosdbGremlinGraphIndexPolicyCompositeIndexIndexToTerraform(struct?: CosmosdbGremlinGraphIndexPolicyCompositeIndexIndex | cdktn.IResolvable): any;
export declare function cosmosdbGremlinGraphIndexPolicyCompositeIndexIndexToHclTerraform(struct?: CosmosdbGremlinGraphIndexPolicyCompositeIndexIndex | cdktn.IResolvable): any;
export declare class CosmosdbGremlinGraphIndexPolicyCompositeIndexIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbGremlinGraphIndexPolicyCompositeIndexIndex | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbGremlinGraphIndexPolicyCompositeIndexIndex | cdktn.IResolvable | undefined);
    private _order?;
    get order(): string;
    set order(value: string);
    get orderInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
}
export declare class CosmosdbGremlinGraphIndexPolicyCompositeIndexIndexList extends cdktn.ComplexList {
    internalValue?: CosmosdbGremlinGraphIndexPolicyCompositeIndexIndex[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbGremlinGraphIndexPolicyCompositeIndexIndexOutputReference;
}
export interface CosmosdbGremlinGraphIndexPolicyCompositeIndex {
    /**
    * index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#index CosmosdbGremlinGraph#index}
    */
    readonly index: CosmosdbGremlinGraphIndexPolicyCompositeIndexIndex[] | cdktn.IResolvable;
}
export declare function cosmosdbGremlinGraphIndexPolicyCompositeIndexToTerraform(struct?: CosmosdbGremlinGraphIndexPolicyCompositeIndex | cdktn.IResolvable): any;
export declare function cosmosdbGremlinGraphIndexPolicyCompositeIndexToHclTerraform(struct?: CosmosdbGremlinGraphIndexPolicyCompositeIndex | cdktn.IResolvable): any;
export declare class CosmosdbGremlinGraphIndexPolicyCompositeIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbGremlinGraphIndexPolicyCompositeIndex | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbGremlinGraphIndexPolicyCompositeIndex | cdktn.IResolvable | undefined);
    private _index;
    get index(): CosmosdbGremlinGraphIndexPolicyCompositeIndexIndexList;
    putIndex(value: CosmosdbGremlinGraphIndexPolicyCompositeIndexIndex[] | cdktn.IResolvable): void;
    get indexInput(): cdktn.IResolvable | CosmosdbGremlinGraphIndexPolicyCompositeIndexIndex[] | undefined;
}
export declare class CosmosdbGremlinGraphIndexPolicyCompositeIndexList extends cdktn.ComplexList {
    internalValue?: CosmosdbGremlinGraphIndexPolicyCompositeIndex[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbGremlinGraphIndexPolicyCompositeIndexOutputReference;
}
export interface CosmosdbGremlinGraphIndexPolicySpatialIndex {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#path CosmosdbGremlinGraph#path}
    */
    readonly path: string;
}
export declare function cosmosdbGremlinGraphIndexPolicySpatialIndexToTerraform(struct?: CosmosdbGremlinGraphIndexPolicySpatialIndex | cdktn.IResolvable): any;
export declare function cosmosdbGremlinGraphIndexPolicySpatialIndexToHclTerraform(struct?: CosmosdbGremlinGraphIndexPolicySpatialIndex | cdktn.IResolvable): any;
export declare class CosmosdbGremlinGraphIndexPolicySpatialIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbGremlinGraphIndexPolicySpatialIndex | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbGremlinGraphIndexPolicySpatialIndex | cdktn.IResolvable | undefined);
    private _path?;
    get path(): string;
    set path(value: string);
    get pathInput(): string | undefined;
    get types(): string[];
}
export declare class CosmosdbGremlinGraphIndexPolicySpatialIndexList extends cdktn.ComplexList {
    internalValue?: CosmosdbGremlinGraphIndexPolicySpatialIndex[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbGremlinGraphIndexPolicySpatialIndexOutputReference;
}
export interface CosmosdbGremlinGraphIndexPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#automatic CosmosdbGremlinGraph#automatic}
    */
    readonly automatic?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#excluded_paths CosmosdbGremlinGraph#excluded_paths}
    */
    readonly excludedPaths?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#included_paths CosmosdbGremlinGraph#included_paths}
    */
    readonly includedPaths?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#indexing_mode CosmosdbGremlinGraph#indexing_mode}
    */
    readonly indexingMode: string;
    /**
    * composite_index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#composite_index CosmosdbGremlinGraph#composite_index}
    */
    readonly compositeIndex?: CosmosdbGremlinGraphIndexPolicyCompositeIndex[] | cdktn.IResolvable;
    /**
    * spatial_index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#spatial_index CosmosdbGremlinGraph#spatial_index}
    */
    readonly spatialIndex?: CosmosdbGremlinGraphIndexPolicySpatialIndex[] | cdktn.IResolvable;
}
export declare function cosmosdbGremlinGraphIndexPolicyToTerraform(struct?: CosmosdbGremlinGraphIndexPolicyOutputReference | CosmosdbGremlinGraphIndexPolicy): any;
export declare function cosmosdbGremlinGraphIndexPolicyToHclTerraform(struct?: CosmosdbGremlinGraphIndexPolicyOutputReference | CosmosdbGremlinGraphIndexPolicy): any;
export declare class CosmosdbGremlinGraphIndexPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbGremlinGraphIndexPolicy | undefined;
    set internalValue(value: CosmosdbGremlinGraphIndexPolicy | undefined);
    private _automatic?;
    get automatic(): boolean | cdktn.IResolvable;
    set automatic(value: boolean | cdktn.IResolvable);
    resetAutomatic(): void;
    get automaticInput(): boolean | cdktn.IResolvable | undefined;
    private _excludedPaths?;
    get excludedPaths(): string[];
    set excludedPaths(value: string[]);
    resetExcludedPaths(): void;
    get excludedPathsInput(): string[] | undefined;
    private _includedPaths?;
    get includedPaths(): string[];
    set includedPaths(value: string[]);
    resetIncludedPaths(): void;
    get includedPathsInput(): string[] | undefined;
    private _indexingMode?;
    get indexingMode(): string;
    set indexingMode(value: string);
    get indexingModeInput(): string | undefined;
    private _compositeIndex;
    get compositeIndex(): CosmosdbGremlinGraphIndexPolicyCompositeIndexList;
    putCompositeIndex(value: CosmosdbGremlinGraphIndexPolicyCompositeIndex[] | cdktn.IResolvable): void;
    resetCompositeIndex(): void;
    get compositeIndexInput(): cdktn.IResolvable | CosmosdbGremlinGraphIndexPolicyCompositeIndex[] | undefined;
    private _spatialIndex;
    get spatialIndex(): CosmosdbGremlinGraphIndexPolicySpatialIndexList;
    putSpatialIndex(value: CosmosdbGremlinGraphIndexPolicySpatialIndex[] | cdktn.IResolvable): void;
    resetSpatialIndex(): void;
    get spatialIndexInput(): cdktn.IResolvable | CosmosdbGremlinGraphIndexPolicySpatialIndex[] | undefined;
}
export interface CosmosdbGremlinGraphTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#create CosmosdbGremlinGraph#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#delete CosmosdbGremlinGraph#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#read CosmosdbGremlinGraph#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#update CosmosdbGremlinGraph#update}
    */
    readonly update?: string;
}
export declare function cosmosdbGremlinGraphTimeoutsToTerraform(struct?: CosmosdbGremlinGraphTimeouts | cdktn.IResolvable): any;
export declare function cosmosdbGremlinGraphTimeoutsToHclTerraform(struct?: CosmosdbGremlinGraphTimeouts | cdktn.IResolvable): any;
export declare class CosmosdbGremlinGraphTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbGremlinGraphTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbGremlinGraphTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CosmosdbGremlinGraphUniqueKey {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#paths CosmosdbGremlinGraph#paths}
    */
    readonly paths: string[];
}
export declare function cosmosdbGremlinGraphUniqueKeyToTerraform(struct?: CosmosdbGremlinGraphUniqueKey | cdktn.IResolvable): any;
export declare function cosmosdbGremlinGraphUniqueKeyToHclTerraform(struct?: CosmosdbGremlinGraphUniqueKey | cdktn.IResolvable): any;
export declare class CosmosdbGremlinGraphUniqueKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbGremlinGraphUniqueKey | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbGremlinGraphUniqueKey | cdktn.IResolvable | undefined);
    private _paths?;
    get paths(): string[];
    set paths(value: string[]);
    get pathsInput(): string[] | undefined;
}
export declare class CosmosdbGremlinGraphUniqueKeyList extends cdktn.ComplexList {
    internalValue?: CosmosdbGremlinGraphUniqueKey[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbGremlinGraphUniqueKeyOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph azurerm_cosmosdb_gremlin_graph}
*/
export declare class CosmosdbGremlinGraph extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_cosmosdb_gremlin_graph";
    /**
    * Generates CDKTN code for importing a CosmosdbGremlinGraph resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CosmosdbGremlinGraph to import
    * @param importFromId The id of the existing CosmosdbGremlinGraph that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CosmosdbGremlinGraph to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_gremlin_graph azurerm_cosmosdb_gremlin_graph} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CosmosdbGremlinGraphConfig
    */
    constructor(scope: Construct, id: string, config: CosmosdbGremlinGraphConfig);
    private _accountName?;
    get accountName(): string;
    set accountName(value: string);
    get accountNameInput(): string | undefined;
    private _analyticalStorageTtl?;
    get analyticalStorageTtl(): number;
    set analyticalStorageTtl(value: number);
    resetAnalyticalStorageTtl(): void;
    get analyticalStorageTtlInput(): number | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _defaultTtl?;
    get defaultTtl(): number;
    set defaultTtl(value: number);
    resetDefaultTtl(): void;
    get defaultTtlInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _partitionKeyPath?;
    get partitionKeyPath(): string;
    set partitionKeyPath(value: string);
    get partitionKeyPathInput(): string | undefined;
    private _partitionKeyVersion?;
    get partitionKeyVersion(): number;
    set partitionKeyVersion(value: number);
    resetPartitionKeyVersion(): void;
    get partitionKeyVersionInput(): number | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _throughput?;
    get throughput(): number;
    set throughput(value: number);
    resetThroughput(): void;
    get throughputInput(): number | undefined;
    private _autoscaleSettings;
    get autoscaleSettings(): CosmosdbGremlinGraphAutoscaleSettingsOutputReference;
    putAutoscaleSettings(value: CosmosdbGremlinGraphAutoscaleSettings): void;
    resetAutoscaleSettings(): void;
    get autoscaleSettingsInput(): CosmosdbGremlinGraphAutoscaleSettings | undefined;
    private _conflictResolutionPolicy;
    get conflictResolutionPolicy(): CosmosdbGremlinGraphConflictResolutionPolicyOutputReference;
    putConflictResolutionPolicy(value: CosmosdbGremlinGraphConflictResolutionPolicy): void;
    resetConflictResolutionPolicy(): void;
    get conflictResolutionPolicyInput(): CosmosdbGremlinGraphConflictResolutionPolicy | undefined;
    private _indexPolicy;
    get indexPolicy(): CosmosdbGremlinGraphIndexPolicyOutputReference;
    putIndexPolicy(value: CosmosdbGremlinGraphIndexPolicy): void;
    resetIndexPolicy(): void;
    get indexPolicyInput(): CosmosdbGremlinGraphIndexPolicy | undefined;
    private _timeouts;
    get timeouts(): CosmosdbGremlinGraphTimeoutsOutputReference;
    putTimeouts(value: CosmosdbGremlinGraphTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CosmosdbGremlinGraphTimeouts | undefined;
    private _uniqueKey;
    get uniqueKey(): CosmosdbGremlinGraphUniqueKeyList;
    putUniqueKey(value: CosmosdbGremlinGraphUniqueKey[] | cdktn.IResolvable): void;
    resetUniqueKey(): void;
    get uniqueKeyInput(): cdktn.IResolvable | CosmosdbGremlinGraphUniqueKey[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
