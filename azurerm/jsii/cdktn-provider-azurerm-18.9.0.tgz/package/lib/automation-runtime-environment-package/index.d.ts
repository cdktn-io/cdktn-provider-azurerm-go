/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AutomationRuntimeEnvironmentPackageConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#automation_runtime_environment_id AutomationRuntimeEnvironmentPackage#automation_runtime_environment_id}
    */
    readonly automationRuntimeEnvironmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#content_uri AutomationRuntimeEnvironmentPackage#content_uri}
    */
    readonly contentUri: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#content_version AutomationRuntimeEnvironmentPackage#content_version}
    */
    readonly contentVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#hash_algorithm AutomationRuntimeEnvironmentPackage#hash_algorithm}
    */
    readonly hashAlgorithm?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#hash_value AutomationRuntimeEnvironmentPackage#hash_value}
    */
    readonly hashValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#id AutomationRuntimeEnvironmentPackage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#name AutomationRuntimeEnvironmentPackage#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#timeouts AutomationRuntimeEnvironmentPackage#timeouts}
    */
    readonly timeouts?: AutomationRuntimeEnvironmentPackageTimeouts;
}
export interface AutomationRuntimeEnvironmentPackageTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#create AutomationRuntimeEnvironmentPackage#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#delete AutomationRuntimeEnvironmentPackage#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#read AutomationRuntimeEnvironmentPackage#read}
    */
    readonly read?: string;
}
export declare function automationRuntimeEnvironmentPackageTimeoutsToTerraform(struct?: AutomationRuntimeEnvironmentPackageTimeouts | cdktn.IResolvable): any;
export declare function automationRuntimeEnvironmentPackageTimeoutsToHclTerraform(struct?: AutomationRuntimeEnvironmentPackageTimeouts | cdktn.IResolvable): any;
export declare class AutomationRuntimeEnvironmentPackageTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AutomationRuntimeEnvironmentPackageTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AutomationRuntimeEnvironmentPackageTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package azurerm_automation_runtime_environment_package}
*/
export declare class AutomationRuntimeEnvironmentPackage extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_automation_runtime_environment_package";
    /**
    * Generates CDKTN code for importing a AutomationRuntimeEnvironmentPackage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AutomationRuntimeEnvironmentPackage to import
    * @param importFromId The id of the existing AutomationRuntimeEnvironmentPackage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AutomationRuntimeEnvironmentPackage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/automation_runtime_environment_package azurerm_automation_runtime_environment_package} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AutomationRuntimeEnvironmentPackageConfig
    */
    constructor(scope: Construct, id: string, config: AutomationRuntimeEnvironmentPackageConfig);
    private _automationRuntimeEnvironmentId?;
    get automationRuntimeEnvironmentId(): string;
    set automationRuntimeEnvironmentId(value: string);
    get automationRuntimeEnvironmentIdInput(): string | undefined;
    private _contentUri?;
    get contentUri(): string;
    set contentUri(value: string);
    get contentUriInput(): string | undefined;
    private _contentVersion?;
    get contentVersion(): string;
    set contentVersion(value: string);
    resetContentVersion(): void;
    get contentVersionInput(): string | undefined;
    get default(): cdktn.IResolvable;
    private _hashAlgorithm?;
    get hashAlgorithm(): string;
    set hashAlgorithm(value: string);
    resetHashAlgorithm(): void;
    get hashAlgorithmInput(): string | undefined;
    private _hashValue?;
    get hashValue(): string;
    set hashValue(value: string);
    resetHashValue(): void;
    get hashValueInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get sizeInBytes(): number;
    get version(): string;
    private _timeouts;
    get timeouts(): AutomationRuntimeEnvironmentPackageTimeoutsOutputReference;
    putTimeouts(value: AutomationRuntimeEnvironmentPackageTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AutomationRuntimeEnvironmentPackageTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
