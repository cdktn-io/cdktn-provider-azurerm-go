/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ContainerRegistryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#admin_enabled ContainerRegistry#admin_enabled}
    */
    readonly adminEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#anonymous_pull_enabled ContainerRegistry#anonymous_pull_enabled}
    */
    readonly anonymousPullEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#azuread_authentication_as_arm_policy_enabled ContainerRegistry#azuread_authentication_as_arm_policy_enabled}
    */
    readonly azureadAuthenticationAsArmPolicyEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#data_endpoint_enabled ContainerRegistry#data_endpoint_enabled}
    */
    readonly dataEndpointEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#encryption ContainerRegistry#encryption}
    */
    readonly encryption?: ContainerRegistryEncryption[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#export_policy_enabled ContainerRegistry#export_policy_enabled}
    */
    readonly exportPolicyEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#id ContainerRegistry#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#location ContainerRegistry#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#name ContainerRegistry#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#network_rule_bypass_for_tasks_enabled ContainerRegistry#network_rule_bypass_for_tasks_enabled}
    */
    readonly networkRuleBypassForTasksEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#network_rule_bypass_option ContainerRegistry#network_rule_bypass_option}
    */
    readonly networkRuleBypassOption?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#network_rule_set ContainerRegistry#network_rule_set}
    */
    readonly networkRuleSet?: ContainerRegistryNetworkRuleSet[] | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#public_network_access_enabled ContainerRegistry#public_network_access_enabled}
    */
    readonly publicNetworkAccessEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#quarantine_policy_enabled ContainerRegistry#quarantine_policy_enabled}
    */
    readonly quarantinePolicyEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#resource_group_name ContainerRegistry#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#retention_policy_in_days ContainerRegistry#retention_policy_in_days}
    */
    readonly retentionPolicyInDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#role_assignment_mode ContainerRegistry#role_assignment_mode}
    */
    readonly roleAssignmentMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#sku ContainerRegistry#sku}
    */
    readonly sku: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#tags ContainerRegistry#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#zone_redundancy_enabled ContainerRegistry#zone_redundancy_enabled}
    */
    readonly zoneRedundancyEnabled?: boolean | cdktn.IResolvable;
    /**
    * georeplications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#georeplications ContainerRegistry#georeplications}
    */
    readonly georeplications?: ContainerRegistryGeoreplications[] | cdktn.IResolvable;
    /**
    * identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#identity ContainerRegistry#identity}
    */
    readonly identity?: ContainerRegistryIdentity;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#timeouts ContainerRegistry#timeouts}
    */
    readonly timeouts?: ContainerRegistryTimeouts;
}
export interface ContainerRegistryEncryption {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#identity_client_id ContainerRegistry#identity_client_id}
    */
    readonly identityClientId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#key_vault_key_id ContainerRegistry#key_vault_key_id}
    */
    readonly keyVaultKeyId?: string;
}
export declare function containerRegistryEncryptionToTerraform(struct?: ContainerRegistryEncryption | cdktn.IResolvable): any;
export declare function containerRegistryEncryptionToHclTerraform(struct?: ContainerRegistryEncryption | cdktn.IResolvable): any;
export declare class ContainerRegistryEncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerRegistryEncryption | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerRegistryEncryption | cdktn.IResolvable | undefined);
    private _identityClientId?;
    get identityClientId(): string;
    set identityClientId(value: string);
    resetIdentityClientId(): void;
    get identityClientIdInput(): string | undefined;
    private _keyVaultKeyId?;
    get keyVaultKeyId(): string;
    set keyVaultKeyId(value: string);
    resetKeyVaultKeyId(): void;
    get keyVaultKeyIdInput(): string | undefined;
}
export declare class ContainerRegistryEncryptionList extends cdktn.ComplexList {
    internalValue?: ContainerRegistryEncryption[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerRegistryEncryptionOutputReference;
}
export interface ContainerRegistryNetworkRuleSetIpRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#action ContainerRegistry#action}
    */
    readonly action?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#ip_range ContainerRegistry#ip_range}
    */
    readonly ipRange?: string;
}
export declare function containerRegistryNetworkRuleSetIpRuleToTerraform(struct?: ContainerRegistryNetworkRuleSetIpRule | cdktn.IResolvable): any;
export declare function containerRegistryNetworkRuleSetIpRuleToHclTerraform(struct?: ContainerRegistryNetworkRuleSetIpRule | cdktn.IResolvable): any;
export declare class ContainerRegistryNetworkRuleSetIpRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerRegistryNetworkRuleSetIpRule | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerRegistryNetworkRuleSetIpRule | cdktn.IResolvable | undefined);
    private _action?;
    get action(): string;
    set action(value: string);
    resetAction(): void;
    get actionInput(): string | undefined;
    private _ipRange?;
    get ipRange(): string;
    set ipRange(value: string);
    resetIpRange(): void;
    get ipRangeInput(): string | undefined;
}
export declare class ContainerRegistryNetworkRuleSetIpRuleList extends cdktn.ComplexList {
    internalValue?: ContainerRegistryNetworkRuleSetIpRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerRegistryNetworkRuleSetIpRuleOutputReference;
}
export interface ContainerRegistryNetworkRuleSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#default_action ContainerRegistry#default_action}
    */
    readonly defaultAction?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#ip_rule ContainerRegistry#ip_rule}
    */
    readonly ipRule?: ContainerRegistryNetworkRuleSetIpRule[] | cdktn.IResolvable;
}
export declare function containerRegistryNetworkRuleSetToTerraform(struct?: ContainerRegistryNetworkRuleSet | cdktn.IResolvable): any;
export declare function containerRegistryNetworkRuleSetToHclTerraform(struct?: ContainerRegistryNetworkRuleSet | cdktn.IResolvable): any;
export declare class ContainerRegistryNetworkRuleSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerRegistryNetworkRuleSet | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerRegistryNetworkRuleSet | cdktn.IResolvable | undefined);
    private _defaultAction?;
    get defaultAction(): string;
    set defaultAction(value: string);
    resetDefaultAction(): void;
    get defaultActionInput(): string | undefined;
    private _ipRule;
    get ipRule(): ContainerRegistryNetworkRuleSetIpRuleList;
    putIpRule(value: ContainerRegistryNetworkRuleSetIpRule[] | cdktn.IResolvable): void;
    resetIpRule(): void;
    get ipRuleInput(): cdktn.IResolvable | ContainerRegistryNetworkRuleSetIpRule[] | undefined;
}
export declare class ContainerRegistryNetworkRuleSetList extends cdktn.ComplexList {
    internalValue?: ContainerRegistryNetworkRuleSet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerRegistryNetworkRuleSetOutputReference;
}
export interface ContainerRegistryGeoreplications {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#global_endpoint_routing_enabled ContainerRegistry#global_endpoint_routing_enabled}
    */
    readonly globalEndpointRoutingEnabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#location ContainerRegistry#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#tags ContainerRegistry#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#zone_redundancy_enabled ContainerRegistry#zone_redundancy_enabled}
    */
    readonly zoneRedundancyEnabled?: boolean | cdktn.IResolvable;
}
export declare function containerRegistryGeoreplicationsToTerraform(struct?: ContainerRegistryGeoreplications | cdktn.IResolvable): any;
export declare function containerRegistryGeoreplicationsToHclTerraform(struct?: ContainerRegistryGeoreplications | cdktn.IResolvable): any;
export declare class ContainerRegistryGeoreplicationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ContainerRegistryGeoreplications | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerRegistryGeoreplications | cdktn.IResolvable | undefined);
    private _globalEndpointRoutingEnabled?;
    get globalEndpointRoutingEnabled(): boolean | cdktn.IResolvable;
    set globalEndpointRoutingEnabled(value: boolean | cdktn.IResolvable);
    get globalEndpointRoutingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _zoneRedundancyEnabled?;
    get zoneRedundancyEnabled(): boolean | cdktn.IResolvable;
    set zoneRedundancyEnabled(value: boolean | cdktn.IResolvable);
    resetZoneRedundancyEnabled(): void;
    get zoneRedundancyEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class ContainerRegistryGeoreplicationsList extends cdktn.ComplexList {
    internalValue?: ContainerRegistryGeoreplications[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ContainerRegistryGeoreplicationsOutputReference;
}
export interface ContainerRegistryIdentity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#identity_ids ContainerRegistry#identity_ids}
    */
    readonly identityIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#type ContainerRegistry#type}
    */
    readonly type: string;
}
export declare function containerRegistryIdentityToTerraform(struct?: ContainerRegistryIdentityOutputReference | ContainerRegistryIdentity): any;
export declare function containerRegistryIdentityToHclTerraform(struct?: ContainerRegistryIdentityOutputReference | ContainerRegistryIdentity): any;
export declare class ContainerRegistryIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerRegistryIdentity | undefined;
    set internalValue(value: ContainerRegistryIdentity | undefined);
    private _identityIds?;
    get identityIds(): string[];
    set identityIds(value: string[]);
    resetIdentityIds(): void;
    get identityIdsInput(): string[] | undefined;
    get principalId(): string;
    get tenantId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ContainerRegistryTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#create ContainerRegistry#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#delete ContainerRegistry#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#read ContainerRegistry#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#update ContainerRegistry#update}
    */
    readonly update?: string;
}
export declare function containerRegistryTimeoutsToTerraform(struct?: ContainerRegistryTimeouts | cdktn.IResolvable): any;
export declare function containerRegistryTimeoutsToHclTerraform(struct?: ContainerRegistryTimeouts | cdktn.IResolvable): any;
export declare class ContainerRegistryTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerRegistryTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerRegistryTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry azurerm_container_registry}
*/
export declare class ContainerRegistry extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_container_registry";
    /**
    * Generates CDKTN code for importing a ContainerRegistry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ContainerRegistry to import
    * @param importFromId The id of the existing ContainerRegistry that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ContainerRegistry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_registry azurerm_container_registry} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ContainerRegistryConfig
    */
    constructor(scope: Construct, id: string, config: ContainerRegistryConfig);
    private _adminEnabled?;
    get adminEnabled(): boolean | cdktn.IResolvable;
    set adminEnabled(value: boolean | cdktn.IResolvable);
    resetAdminEnabled(): void;
    get adminEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get adminPassword(): string;
    get adminUsername(): string;
    private _anonymousPullEnabled?;
    get anonymousPullEnabled(): boolean | cdktn.IResolvable;
    set anonymousPullEnabled(value: boolean | cdktn.IResolvable);
    resetAnonymousPullEnabled(): void;
    get anonymousPullEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _azureadAuthenticationAsArmPolicyEnabled?;
    get azureadAuthenticationAsArmPolicyEnabled(): boolean | cdktn.IResolvable;
    set azureadAuthenticationAsArmPolicyEnabled(value: boolean | cdktn.IResolvable);
    resetAzureadAuthenticationAsArmPolicyEnabled(): void;
    get azureadAuthenticationAsArmPolicyEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _dataEndpointEnabled?;
    get dataEndpointEnabled(): boolean | cdktn.IResolvable;
    set dataEndpointEnabled(value: boolean | cdktn.IResolvable);
    resetDataEndpointEnabled(): void;
    get dataEndpointEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get dataEndpointHostNames(): string[];
    private _encryption;
    get encryption(): ContainerRegistryEncryptionList;
    putEncryption(value: ContainerRegistryEncryption[] | cdktn.IResolvable): void;
    resetEncryption(): void;
    get encryptionInput(): cdktn.IResolvable | ContainerRegistryEncryption[] | undefined;
    private _exportPolicyEnabled?;
    get exportPolicyEnabled(): boolean | cdktn.IResolvable;
    set exportPolicyEnabled(value: boolean | cdktn.IResolvable);
    resetExportPolicyEnabled(): void;
    get exportPolicyEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get loginServer(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkRuleBypassForTasksEnabled?;
    get networkRuleBypassForTasksEnabled(): boolean | cdktn.IResolvable;
    set networkRuleBypassForTasksEnabled(value: boolean | cdktn.IResolvable);
    resetNetworkRuleBypassForTasksEnabled(): void;
    get networkRuleBypassForTasksEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _networkRuleBypassOption?;
    get networkRuleBypassOption(): string;
    set networkRuleBypassOption(value: string);
    resetNetworkRuleBypassOption(): void;
    get networkRuleBypassOptionInput(): string | undefined;
    private _networkRuleSet;
    get networkRuleSet(): ContainerRegistryNetworkRuleSetList;
    putNetworkRuleSet(value: ContainerRegistryNetworkRuleSet[] | cdktn.IResolvable): void;
    resetNetworkRuleSet(): void;
    get networkRuleSetInput(): cdktn.IResolvable | ContainerRegistryNetworkRuleSet[] | undefined;
    private _publicNetworkAccessEnabled?;
    get publicNetworkAccessEnabled(): boolean | cdktn.IResolvable;
    set publicNetworkAccessEnabled(value: boolean | cdktn.IResolvable);
    resetPublicNetworkAccessEnabled(): void;
    get publicNetworkAccessEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _quarantinePolicyEnabled?;
    get quarantinePolicyEnabled(): boolean | cdktn.IResolvable;
    set quarantinePolicyEnabled(value: boolean | cdktn.IResolvable);
    resetQuarantinePolicyEnabled(): void;
    get quarantinePolicyEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _retentionPolicyInDays?;
    get retentionPolicyInDays(): number;
    set retentionPolicyInDays(value: number);
    resetRetentionPolicyInDays(): void;
    get retentionPolicyInDaysInput(): number | undefined;
    private _roleAssignmentMode?;
    get roleAssignmentMode(): string;
    set roleAssignmentMode(value: string);
    resetRoleAssignmentMode(): void;
    get roleAssignmentModeInput(): string | undefined;
    private _sku?;
    get sku(): string;
    set sku(value: string);
    get skuInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _zoneRedundancyEnabled?;
    get zoneRedundancyEnabled(): boolean | cdktn.IResolvable;
    set zoneRedundancyEnabled(value: boolean | cdktn.IResolvable);
    resetZoneRedundancyEnabled(): void;
    get zoneRedundancyEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _georeplications;
    get georeplications(): ContainerRegistryGeoreplicationsList;
    putGeoreplications(value: ContainerRegistryGeoreplications[] | cdktn.IResolvable): void;
    resetGeoreplications(): void;
    get georeplicationsInput(): cdktn.IResolvable | ContainerRegistryGeoreplications[] | undefined;
    private _identity;
    get identity(): ContainerRegistryIdentityOutputReference;
    putIdentity(value: ContainerRegistryIdentity): void;
    resetIdentity(): void;
    get identityInput(): ContainerRegistryIdentity | undefined;
    private _timeouts;
    get timeouts(): ContainerRegistryTimeoutsOutputReference;
    putTimeouts(value: ContainerRegistryTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ContainerRegistryTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
