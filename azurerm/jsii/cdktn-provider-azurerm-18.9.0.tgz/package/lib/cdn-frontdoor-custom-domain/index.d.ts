/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CdnFrontdoorCustomDomainConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#cdn_frontdoor_profile_id CdnFrontdoorCustomDomain#cdn_frontdoor_profile_id}
    */
    readonly cdnFrontdoorProfileId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#dns_zone_id CdnFrontdoorCustomDomain#dns_zone_id}
    */
    readonly dnsZoneId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#host_name CdnFrontdoorCustomDomain#host_name}
    */
    readonly hostName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#id CdnFrontdoorCustomDomain#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#name CdnFrontdoorCustomDomain#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#timeouts CdnFrontdoorCustomDomain#timeouts}
    */
    readonly timeouts?: CdnFrontdoorCustomDomainTimeouts;
    /**
    * tls block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#tls CdnFrontdoorCustomDomain#tls}
    */
    readonly tls: CdnFrontdoorCustomDomainTls;
}
export interface CdnFrontdoorCustomDomainTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#create CdnFrontdoorCustomDomain#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#delete CdnFrontdoorCustomDomain#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#read CdnFrontdoorCustomDomain#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#update CdnFrontdoorCustomDomain#update}
    */
    readonly update?: string;
}
export declare function cdnFrontdoorCustomDomainTimeoutsToTerraform(struct?: CdnFrontdoorCustomDomainTimeouts | cdktn.IResolvable): any;
export declare function cdnFrontdoorCustomDomainTimeoutsToHclTerraform(struct?: CdnFrontdoorCustomDomainTimeouts | cdktn.IResolvable): any;
export declare class CdnFrontdoorCustomDomainTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorCustomDomainTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorCustomDomainTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#tls12 CdnFrontdoorCustomDomain#tls12}
    */
    readonly tls12?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#tls13 CdnFrontdoorCustomDomain#tls13}
    */
    readonly tls13?: string[];
}
export declare function cdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersToTerraform(struct?: CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersOutputReference | CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers): any;
export declare function cdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersToHclTerraform(struct?: CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersOutputReference | CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers): any;
export declare class CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers | undefined;
    set internalValue(value: CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers | undefined);
    private _tls12?;
    get tls12(): string[];
    set tls12(value: string[]);
    resetTls12(): void;
    get tls12Input(): string[] | undefined;
    private _tls13?;
    get tls13(): string[];
    set tls13(value: string[]);
    resetTls13(): void;
    get tls13Input(): string[] | undefined;
}
export interface CdnFrontdoorCustomDomainTlsCipherSuite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#type CdnFrontdoorCustomDomain#type}
    */
    readonly type: string;
    /**
    * custom_ciphers block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#custom_ciphers CdnFrontdoorCustomDomain#custom_ciphers}
    */
    readonly customCiphers?: CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers;
}
export declare function cdnFrontdoorCustomDomainTlsCipherSuiteToTerraform(struct?: CdnFrontdoorCustomDomainTlsCipherSuiteOutputReference | CdnFrontdoorCustomDomainTlsCipherSuite): any;
export declare function cdnFrontdoorCustomDomainTlsCipherSuiteToHclTerraform(struct?: CdnFrontdoorCustomDomainTlsCipherSuiteOutputReference | CdnFrontdoorCustomDomainTlsCipherSuite): any;
export declare class CdnFrontdoorCustomDomainTlsCipherSuiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorCustomDomainTlsCipherSuite | undefined;
    set internalValue(value: CdnFrontdoorCustomDomainTlsCipherSuite | undefined);
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _customCiphers;
    get customCiphers(): CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphersOutputReference;
    putCustomCiphers(value: CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers): void;
    resetCustomCiphers(): void;
    get customCiphersInput(): CdnFrontdoorCustomDomainTlsCipherSuiteCustomCiphers | undefined;
}
export interface CdnFrontdoorCustomDomainTls {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#cdn_frontdoor_secret_id CdnFrontdoorCustomDomain#cdn_frontdoor_secret_id}
    */
    readonly cdnFrontdoorSecretId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#certificate_type CdnFrontdoorCustomDomain#certificate_type}
    */
    readonly certificateType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#minimum_version CdnFrontdoorCustomDomain#minimum_version}
    */
    readonly minimumVersion?: string;
    /**
    * cipher_suite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#cipher_suite CdnFrontdoorCustomDomain#cipher_suite}
    */
    readonly cipherSuite?: CdnFrontdoorCustomDomainTlsCipherSuite;
}
export declare function cdnFrontdoorCustomDomainTlsToTerraform(struct?: CdnFrontdoorCustomDomainTlsOutputReference | CdnFrontdoorCustomDomainTls): any;
export declare function cdnFrontdoorCustomDomainTlsToHclTerraform(struct?: CdnFrontdoorCustomDomainTlsOutputReference | CdnFrontdoorCustomDomainTls): any;
export declare class CdnFrontdoorCustomDomainTlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorCustomDomainTls | undefined;
    set internalValue(value: CdnFrontdoorCustomDomainTls | undefined);
    private _cdnFrontdoorSecretId?;
    get cdnFrontdoorSecretId(): string;
    set cdnFrontdoorSecretId(value: string);
    resetCdnFrontdoorSecretId(): void;
    get cdnFrontdoorSecretIdInput(): string | undefined;
    private _certificateType?;
    get certificateType(): string;
    set certificateType(value: string);
    resetCertificateType(): void;
    get certificateTypeInput(): string | undefined;
    private _minimumVersion?;
    get minimumVersion(): string;
    set minimumVersion(value: string);
    resetMinimumVersion(): void;
    get minimumVersionInput(): string | undefined;
    private _cipherSuite;
    get cipherSuite(): CdnFrontdoorCustomDomainTlsCipherSuiteOutputReference;
    putCipherSuite(value: CdnFrontdoorCustomDomainTlsCipherSuite): void;
    resetCipherSuite(): void;
    get cipherSuiteInput(): CdnFrontdoorCustomDomainTlsCipherSuite | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain azurerm_cdn_frontdoor_custom_domain}
*/
export declare class CdnFrontdoorCustomDomain extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_cdn_frontdoor_custom_domain";
    /**
    * Generates CDKTN code for importing a CdnFrontdoorCustomDomain resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CdnFrontdoorCustomDomain to import
    * @param importFromId The id of the existing CdnFrontdoorCustomDomain that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CdnFrontdoorCustomDomain to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_custom_domain azurerm_cdn_frontdoor_custom_domain} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CdnFrontdoorCustomDomainConfig
    */
    constructor(scope: Construct, id: string, config: CdnFrontdoorCustomDomainConfig);
    private _cdnFrontdoorProfileId?;
    get cdnFrontdoorProfileId(): string;
    set cdnFrontdoorProfileId(value: string);
    get cdnFrontdoorProfileIdInput(): string | undefined;
    private _dnsZoneId?;
    get dnsZoneId(): string;
    set dnsZoneId(value: string);
    resetDnsZoneId(): void;
    get dnsZoneIdInput(): string | undefined;
    get expirationDate(): string;
    private _hostName?;
    get hostName(): string;
    set hostName(value: string);
    get hostNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get validationToken(): string;
    private _timeouts;
    get timeouts(): CdnFrontdoorCustomDomainTimeoutsOutputReference;
    putTimeouts(value: CdnFrontdoorCustomDomainTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CdnFrontdoorCustomDomainTimeouts | undefined;
    private _tls;
    get tls(): CdnFrontdoorCustomDomainTlsOutputReference;
    putTls(value: CdnFrontdoorCustomDomainTls): void;
    get tlsInput(): CdnFrontdoorCustomDomainTls | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
