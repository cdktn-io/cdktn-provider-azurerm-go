/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BlueprintAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#id BlueprintAssignment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#location BlueprintAssignment#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#lock_exclude_actions BlueprintAssignment#lock_exclude_actions}
    */
    readonly lockExcludeActions?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#lock_exclude_principals BlueprintAssignment#lock_exclude_principals}
    */
    readonly lockExcludePrincipals?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#lock_mode BlueprintAssignment#lock_mode}
    */
    readonly lockMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#name BlueprintAssignment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#parameter_values BlueprintAssignment#parameter_values}
    */
    readonly parameterValues?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#resource_groups BlueprintAssignment#resource_groups}
    */
    readonly resourceGroups?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#target_subscription_id BlueprintAssignment#target_subscription_id}
    */
    readonly targetSubscriptionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#version_id BlueprintAssignment#version_id}
    */
    readonly versionId: string;
    /**
    * identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#identity BlueprintAssignment#identity}
    */
    readonly identity: BlueprintAssignmentIdentity;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#timeouts BlueprintAssignment#timeouts}
    */
    readonly timeouts?: BlueprintAssignmentTimeouts;
}
export interface BlueprintAssignmentIdentity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#identity_ids BlueprintAssignment#identity_ids}
    */
    readonly identityIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#type BlueprintAssignment#type}
    */
    readonly type: string;
}
export declare function blueprintAssignmentIdentityToTerraform(struct?: BlueprintAssignmentIdentityOutputReference | BlueprintAssignmentIdentity): any;
export declare function blueprintAssignmentIdentityToHclTerraform(struct?: BlueprintAssignmentIdentityOutputReference | BlueprintAssignmentIdentity): any;
export declare class BlueprintAssignmentIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BlueprintAssignmentIdentity | undefined;
    set internalValue(value: BlueprintAssignmentIdentity | undefined);
    private _identityIds?;
    get identityIds(): string[];
    set identityIds(value: string[]);
    resetIdentityIds(): void;
    get identityIdsInput(): string[] | undefined;
    get principalId(): string;
    get tenantId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface BlueprintAssignmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#create BlueprintAssignment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#delete BlueprintAssignment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#read BlueprintAssignment#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#update BlueprintAssignment#update}
    */
    readonly update?: string;
}
export declare function blueprintAssignmentTimeoutsToTerraform(struct?: BlueprintAssignmentTimeouts | cdktn.IResolvable): any;
export declare function blueprintAssignmentTimeoutsToHclTerraform(struct?: BlueprintAssignmentTimeouts | cdktn.IResolvable): any;
export declare class BlueprintAssignmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BlueprintAssignmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BlueprintAssignmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment azurerm_blueprint_assignment}
*/
export declare class BlueprintAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_blueprint_assignment";
    /**
    * Generates CDKTN code for importing a BlueprintAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BlueprintAssignment to import
    * @param importFromId The id of the existing BlueprintAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BlueprintAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/blueprint_assignment azurerm_blueprint_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BlueprintAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: BlueprintAssignmentConfig);
    get blueprintName(): string;
    get description(): string;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _lockExcludeActions?;
    get lockExcludeActions(): string[];
    set lockExcludeActions(value: string[]);
    resetLockExcludeActions(): void;
    get lockExcludeActionsInput(): string[] | undefined;
    private _lockExcludePrincipals?;
    get lockExcludePrincipals(): string[];
    set lockExcludePrincipals(value: string[]);
    resetLockExcludePrincipals(): void;
    get lockExcludePrincipalsInput(): string[] | undefined;
    private _lockMode?;
    get lockMode(): string;
    set lockMode(value: string);
    resetLockMode(): void;
    get lockModeInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parameterValues?;
    get parameterValues(): string;
    set parameterValues(value: string);
    resetParameterValues(): void;
    get parameterValuesInput(): string | undefined;
    private _resourceGroups?;
    get resourceGroups(): string;
    set resourceGroups(value: string);
    resetResourceGroups(): void;
    get resourceGroupsInput(): string | undefined;
    private _targetSubscriptionId?;
    get targetSubscriptionId(): string;
    set targetSubscriptionId(value: string);
    get targetSubscriptionIdInput(): string | undefined;
    get type(): string;
    private _versionId?;
    get versionId(): string;
    set versionId(value: string);
    get versionIdInput(): string | undefined;
    private _identity;
    get identity(): BlueprintAssignmentIdentityOutputReference;
    putIdentity(value: BlueprintAssignmentIdentity): void;
    get identityInput(): BlueprintAssignmentIdentity | undefined;
    private _timeouts;
    get timeouts(): BlueprintAssignmentTimeoutsOutputReference;
    putTimeouts(value: BlueprintAssignmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BlueprintAssignmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
