/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface BotChannelWebChatConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#bot_name BotChannelWebChat#bot_name}
    */
    readonly botName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#id BotChannelWebChat#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#location BotChannelWebChat#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#resource_group_name BotChannelWebChat#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * site block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#site BotChannelWebChat#site}
    */
    readonly site?: BotChannelWebChatSite[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#timeouts BotChannelWebChat#timeouts}
    */
    readonly timeouts?: BotChannelWebChatTimeouts;
}
export interface BotChannelWebChatSite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#endpoint_parameters_enabled BotChannelWebChat#endpoint_parameters_enabled}
    */
    readonly endpointParametersEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#name BotChannelWebChat#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#storage_enabled BotChannelWebChat#storage_enabled}
    */
    readonly storageEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#user_upload_enabled BotChannelWebChat#user_upload_enabled}
    */
    readonly userUploadEnabled?: boolean | cdktn.IResolvable;
}
export declare function botChannelWebChatSiteToTerraform(struct?: BotChannelWebChatSite | cdktn.IResolvable): any;
export declare function botChannelWebChatSiteToHclTerraform(struct?: BotChannelWebChatSite | cdktn.IResolvable): any;
export declare class BotChannelWebChatSiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): BotChannelWebChatSite | cdktn.IResolvable | undefined;
    set internalValue(value: BotChannelWebChatSite | cdktn.IResolvable | undefined);
    private _endpointParametersEnabled?;
    get endpointParametersEnabled(): boolean | cdktn.IResolvable;
    set endpointParametersEnabled(value: boolean | cdktn.IResolvable);
    resetEndpointParametersEnabled(): void;
    get endpointParametersEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _storageEnabled?;
    get storageEnabled(): boolean | cdktn.IResolvable;
    set storageEnabled(value: boolean | cdktn.IResolvable);
    resetStorageEnabled(): void;
    get storageEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _userUploadEnabled?;
    get userUploadEnabled(): boolean | cdktn.IResolvable;
    set userUploadEnabled(value: boolean | cdktn.IResolvable);
    resetUserUploadEnabled(): void;
    get userUploadEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class BotChannelWebChatSiteList extends cdktn.ComplexList {
    internalValue?: BotChannelWebChatSite[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): BotChannelWebChatSiteOutputReference;
}
export interface BotChannelWebChatTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#create BotChannelWebChat#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#delete BotChannelWebChat#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#read BotChannelWebChat#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#update BotChannelWebChat#update}
    */
    readonly update?: string;
}
export declare function botChannelWebChatTimeoutsToTerraform(struct?: BotChannelWebChatTimeouts | cdktn.IResolvable): any;
export declare function botChannelWebChatTimeoutsToHclTerraform(struct?: BotChannelWebChatTimeouts | cdktn.IResolvable): any;
export declare class BotChannelWebChatTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): BotChannelWebChatTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: BotChannelWebChatTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat azurerm_bot_channel_web_chat}
*/
export declare class BotChannelWebChat extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_bot_channel_web_chat";
    /**
    * Generates CDKTN code for importing a BotChannelWebChat resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the BotChannelWebChat to import
    * @param importFromId The id of the existing BotChannelWebChat that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the BotChannelWebChat to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/bot_channel_web_chat azurerm_bot_channel_web_chat} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options BotChannelWebChatConfig
    */
    constructor(scope: Construct, id: string, config: BotChannelWebChatConfig);
    private _botName?;
    get botName(): string;
    set botName(value: string);
    get botNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _site;
    get site(): BotChannelWebChatSiteList;
    putSite(value: BotChannelWebChatSite[] | cdktn.IResolvable): void;
    resetSite(): void;
    get siteInput(): cdktn.IResolvable | BotChannelWebChatSite[] | undefined;
    private _timeouts;
    get timeouts(): BotChannelWebChatTimeoutsOutputReference;
    putTimeouts(value: BotChannelWebChatTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | BotChannelWebChatTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
