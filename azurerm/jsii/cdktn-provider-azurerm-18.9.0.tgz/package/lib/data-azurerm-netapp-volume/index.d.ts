/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermNetappVolumeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume#account_name DataAzurermNetappVolume#account_name}
    */
    readonly accountName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume#id DataAzurermNetappVolume#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume#name DataAzurermNetappVolume#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume#pool_name DataAzurermNetappVolume#pool_name}
    */
    readonly poolName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume#resource_group_name DataAzurermNetappVolume#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume#security_style DataAzurermNetappVolume#security_style}
    */
    readonly securityStyle?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume#timeouts DataAzurermNetappVolume#timeouts}
    */
    readonly timeouts?: DataAzurermNetappVolumeTimeouts;
}
export interface DataAzurermNetappVolumeDataProtectionAdvancedRansomware {
}
export declare function dataAzurermNetappVolumeDataProtectionAdvancedRansomwareToTerraform(struct?: DataAzurermNetappVolumeDataProtectionAdvancedRansomware): any;
export declare function dataAzurermNetappVolumeDataProtectionAdvancedRansomwareToHclTerraform(struct?: DataAzurermNetappVolumeDataProtectionAdvancedRansomware): any;
export declare class DataAzurermNetappVolumeDataProtectionAdvancedRansomwareOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermNetappVolumeDataProtectionAdvancedRansomware | undefined;
    set internalValue(value: DataAzurermNetappVolumeDataProtectionAdvancedRansomware | undefined);
    get protectionEnabled(): cdktn.IResolvable;
}
export declare class DataAzurermNetappVolumeDataProtectionAdvancedRansomwareList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermNetappVolumeDataProtectionAdvancedRansomwareOutputReference;
}
export interface DataAzurermNetappVolumeDataProtectionBackupPolicy {
}
export declare function dataAzurermNetappVolumeDataProtectionBackupPolicyToTerraform(struct?: DataAzurermNetappVolumeDataProtectionBackupPolicy): any;
export declare function dataAzurermNetappVolumeDataProtectionBackupPolicyToHclTerraform(struct?: DataAzurermNetappVolumeDataProtectionBackupPolicy): any;
export declare class DataAzurermNetappVolumeDataProtectionBackupPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermNetappVolumeDataProtectionBackupPolicy | undefined;
    set internalValue(value: DataAzurermNetappVolumeDataProtectionBackupPolicy | undefined);
    get backupPolicyId(): string;
    get backupVaultId(): string;
    get policyEnabled(): cdktn.IResolvable;
}
export declare class DataAzurermNetappVolumeDataProtectionBackupPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermNetappVolumeDataProtectionBackupPolicyOutputReference;
}
export interface DataAzurermNetappVolumeDataProtectionReplication {
}
export declare function dataAzurermNetappVolumeDataProtectionReplicationToTerraform(struct?: DataAzurermNetappVolumeDataProtectionReplication): any;
export declare function dataAzurermNetappVolumeDataProtectionReplicationToHclTerraform(struct?: DataAzurermNetappVolumeDataProtectionReplication): any;
export declare class DataAzurermNetappVolumeDataProtectionReplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermNetappVolumeDataProtectionReplication | undefined;
    set internalValue(value: DataAzurermNetappVolumeDataProtectionReplication | undefined);
    get endpointType(): string;
    get remoteVolumeLocation(): string;
    get remoteVolumeResourceId(): string;
    get replicationFrequency(): string;
}
export declare class DataAzurermNetappVolumeDataProtectionReplicationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermNetappVolumeDataProtectionReplicationOutputReference;
}
export interface DataAzurermNetappVolumeMountTarget {
}
export declare function dataAzurermNetappVolumeMountTargetToTerraform(struct?: DataAzurermNetappVolumeMountTarget): any;
export declare function dataAzurermNetappVolumeMountTargetToHclTerraform(struct?: DataAzurermNetappVolumeMountTarget): any;
export declare class DataAzurermNetappVolumeMountTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermNetappVolumeMountTarget | undefined;
    set internalValue(value: DataAzurermNetappVolumeMountTarget | undefined);
    get ipAddress(): string;
    get smbServerFqdn(): string;
}
export declare class DataAzurermNetappVolumeMountTargetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermNetappVolumeMountTargetOutputReference;
}
export interface DataAzurermNetappVolumeTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume#read DataAzurermNetappVolume#read}
    */
    readonly read?: string;
}
export declare function dataAzurermNetappVolumeTimeoutsToTerraform(struct?: DataAzurermNetappVolumeTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermNetappVolumeTimeoutsToHclTerraform(struct?: DataAzurermNetappVolumeTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermNetappVolumeTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermNetappVolumeTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermNetappVolumeTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume azurerm_netapp_volume}
*/
export declare class DataAzurermNetappVolume extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_netapp_volume";
    /**
    * Generates CDKTN code for importing a DataAzurermNetappVolume resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermNetappVolume to import
    * @param importFromId The id of the existing DataAzurermNetappVolume that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermNetappVolume to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume azurerm_netapp_volume} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermNetappVolumeConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermNetappVolumeConfig);
    get acceptGrowCapacityPoolForShortTermCloneSplit(): string;
    private _accountName?;
    get accountName(): string;
    set accountName(value: string);
    get accountNameInput(): string | undefined;
    get breakthroughModeEnabled(): cdktn.IResolvable;
    private _dataProtectionAdvancedRansomware;
    get dataProtectionAdvancedRansomware(): DataAzurermNetappVolumeDataProtectionAdvancedRansomwareList;
    private _dataProtectionBackupPolicy;
    get dataProtectionBackupPolicy(): DataAzurermNetappVolumeDataProtectionBackupPolicyList;
    private _dataProtectionReplication;
    get dataProtectionReplication(): DataAzurermNetappVolumeDataProtectionReplicationList;
    get encryptionKeySource(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get keyVaultPrivateEndpointId(): string;
    get largeVolumeEnabled(): cdktn.IResolvable;
    get location(): string;
    private _mountTarget;
    get mountTarget(): DataAzurermNetappVolumeMountTargetList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkFeatures(): string;
    private _poolName?;
    get poolName(): string;
    set poolName(value: string);
    get poolNameInput(): string | undefined;
    get protocols(): string[];
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _securityStyle?;
    get securityStyle(): string;
    set securityStyle(value: string);
    resetSecurityStyle(): void;
    get securityStyleInput(): string | undefined;
    get serviceLevel(): string;
    get smbAccessBasedEnumerationEnabled(): cdktn.IResolvable;
    get smbNonBrowsableEnabled(): cdktn.IResolvable;
    get storageQuotaInGb(): number;
    get subnetId(): string;
    get volumePath(): string;
    get zone(): string;
    private _timeouts;
    get timeouts(): DataAzurermNetappVolumeTimeoutsOutputReference;
    putTimeouts(value: DataAzurermNetappVolumeTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermNetappVolumeTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
