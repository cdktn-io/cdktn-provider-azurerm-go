/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermEventgridPartnerNamespaceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/eventgrid_partner_namespace#id DataAzurermEventgridPartnerNamespace#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/eventgrid_partner_namespace#name DataAzurermEventgridPartnerNamespace#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/eventgrid_partner_namespace#resource_group_name DataAzurermEventgridPartnerNamespace#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/eventgrid_partner_namespace#timeouts DataAzurermEventgridPartnerNamespace#timeouts}
    */
    readonly timeouts?: DataAzurermEventgridPartnerNamespaceTimeouts;
}
export interface DataAzurermEventgridPartnerNamespaceInboundIpRule {
}
export declare function dataAzurermEventgridPartnerNamespaceInboundIpRuleToTerraform(struct?: DataAzurermEventgridPartnerNamespaceInboundIpRule): any;
export declare function dataAzurermEventgridPartnerNamespaceInboundIpRuleToHclTerraform(struct?: DataAzurermEventgridPartnerNamespaceInboundIpRule): any;
export declare class DataAzurermEventgridPartnerNamespaceInboundIpRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermEventgridPartnerNamespaceInboundIpRule | undefined;
    set internalValue(value: DataAzurermEventgridPartnerNamespaceInboundIpRule | undefined);
    get action(): string;
    get ipMask(): string;
}
export declare class DataAzurermEventgridPartnerNamespaceInboundIpRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermEventgridPartnerNamespaceInboundIpRuleOutputReference;
}
export interface DataAzurermEventgridPartnerNamespaceTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/eventgrid_partner_namespace#read DataAzurermEventgridPartnerNamespace#read}
    */
    readonly read?: string;
}
export declare function dataAzurermEventgridPartnerNamespaceTimeoutsToTerraform(struct?: DataAzurermEventgridPartnerNamespaceTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermEventgridPartnerNamespaceTimeoutsToHclTerraform(struct?: DataAzurermEventgridPartnerNamespaceTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermEventgridPartnerNamespaceTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermEventgridPartnerNamespaceTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermEventgridPartnerNamespaceTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/eventgrid_partner_namespace azurerm_eventgrid_partner_namespace}
*/
export declare class DataAzurermEventgridPartnerNamespace extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_eventgrid_partner_namespace";
    /**
    * Generates CDKTN code for importing a DataAzurermEventgridPartnerNamespace resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermEventgridPartnerNamespace to import
    * @param importFromId The id of the existing DataAzurermEventgridPartnerNamespace that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/eventgrid_partner_namespace#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermEventgridPartnerNamespace to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/eventgrid_partner_namespace azurerm_eventgrid_partner_namespace} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermEventgridPartnerNamespaceConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermEventgridPartnerNamespaceConfig);
    get endpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inboundIpRule;
    get inboundIpRule(): DataAzurermEventgridPartnerNamespaceInboundIpRuleList;
    get localAuthenticationEnabled(): cdktn.IResolvable;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get partnerRegistrationId(): string;
    get partnerTopicRoutingMode(): string;
    get publicNetworkAccess(): string;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): DataAzurermEventgridPartnerNamespaceTimeoutsOutputReference;
    putTimeouts(value: DataAzurermEventgridPartnerNamespaceTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermEventgridPartnerNamespaceTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
