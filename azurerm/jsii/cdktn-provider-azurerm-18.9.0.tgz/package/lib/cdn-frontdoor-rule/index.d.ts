/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CdnFrontdoorRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#behaviour_on_match CdnFrontdoorRule#behaviour_on_match}
    */
    readonly behaviourOnMatch?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#cdn_frontdoor_rule_set_id CdnFrontdoorRule#cdn_frontdoor_rule_set_id}
    */
    readonly cdnFrontdoorRuleSetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#id CdnFrontdoorRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#name CdnFrontdoorRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#order CdnFrontdoorRule#order}
    */
    readonly order: number;
    /**
    * actions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#actions CdnFrontdoorRule#actions}
    */
    readonly actions: CdnFrontdoorRuleActions;
    /**
    * conditions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#conditions CdnFrontdoorRule#conditions}
    */
    readonly conditions?: CdnFrontdoorRuleConditions;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#timeouts CdnFrontdoorRule#timeouts}
    */
    readonly timeouts?: CdnFrontdoorRuleTimeouts;
}
export interface CdnFrontdoorRuleActionsModifyRequestHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#header_name CdnFrontdoorRule#header_name}
    */
    readonly headerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#header_value CdnFrontdoorRule#header_value}
    */
    readonly headerValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
}
export declare function cdnFrontdoorRuleActionsModifyRequestHeaderToTerraform(struct?: CdnFrontdoorRuleActionsModifyRequestHeader | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleActionsModifyRequestHeaderToHclTerraform(struct?: CdnFrontdoorRuleActionsModifyRequestHeader | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleActionsModifyRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleActionsModifyRequestHeader | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleActionsModifyRequestHeader | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
}
export declare class CdnFrontdoorRuleActionsModifyRequestHeaderList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleActionsModifyRequestHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleActionsModifyRequestHeaderOutputReference;
}
export interface CdnFrontdoorRuleActionsModifyResponseHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#header_name CdnFrontdoorRule#header_name}
    */
    readonly headerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#header_value CdnFrontdoorRule#header_value}
    */
    readonly headerValue?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
}
export declare function cdnFrontdoorRuleActionsModifyResponseHeaderToTerraform(struct?: CdnFrontdoorRuleActionsModifyResponseHeader | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleActionsModifyResponseHeaderToHclTerraform(struct?: CdnFrontdoorRuleActionsModifyResponseHeader | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleActionsModifyResponseHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleActionsModifyResponseHeader | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleActionsModifyResponseHeader | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    resetHeaderValue(): void;
    get headerValueInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
}
export declare class CdnFrontdoorRuleActionsModifyResponseHeaderList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleActionsModifyResponseHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleActionsModifyResponseHeaderOutputReference;
}
export interface CdnFrontdoorRuleActionsRouteConfigurationOverrideCaching {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#behaviour CdnFrontdoorRule#behaviour}
    */
    readonly behaviour: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#compression_enabled CdnFrontdoorRule#compression_enabled}
    */
    readonly compressionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#duration CdnFrontdoorRule#duration}
    */
    readonly duration?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#query_string_behaviour CdnFrontdoorRule#query_string_behaviour}
    */
    readonly queryStringBehaviour?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#query_string_parameters CdnFrontdoorRule#query_string_parameters}
    */
    readonly queryStringParameters?: string[];
}
export declare function cdnFrontdoorRuleActionsRouteConfigurationOverrideCachingToTerraform(struct?: CdnFrontdoorRuleActionsRouteConfigurationOverrideCachingOutputReference | CdnFrontdoorRuleActionsRouteConfigurationOverrideCaching): any;
export declare function cdnFrontdoorRuleActionsRouteConfigurationOverrideCachingToHclTerraform(struct?: CdnFrontdoorRuleActionsRouteConfigurationOverrideCachingOutputReference | CdnFrontdoorRuleActionsRouteConfigurationOverrideCaching): any;
export declare class CdnFrontdoorRuleActionsRouteConfigurationOverrideCachingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorRuleActionsRouteConfigurationOverrideCaching | undefined;
    set internalValue(value: CdnFrontdoorRuleActionsRouteConfigurationOverrideCaching | undefined);
    private _behaviour?;
    get behaviour(): string;
    set behaviour(value: string);
    get behaviourInput(): string | undefined;
    private _compressionEnabled?;
    get compressionEnabled(): boolean | cdktn.IResolvable;
    set compressionEnabled(value: boolean | cdktn.IResolvable);
    resetCompressionEnabled(): void;
    get compressionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _duration?;
    get duration(): string;
    set duration(value: string);
    resetDuration(): void;
    get durationInput(): string | undefined;
    private _queryStringBehaviour?;
    get queryStringBehaviour(): string;
    set queryStringBehaviour(value: string);
    resetQueryStringBehaviour(): void;
    get queryStringBehaviourInput(): string | undefined;
    private _queryStringParameters?;
    get queryStringParameters(): string[];
    set queryStringParameters(value: string[]);
    resetQueryStringParameters(): void;
    get queryStringParametersInput(): string[] | undefined;
}
export interface CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#cdn_frontdoor_origin_group_id CdnFrontdoorRule#cdn_frontdoor_origin_group_id}
    */
    readonly cdnFrontdoorOriginGroupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#forwarding_protocol CdnFrontdoorRule#forwarding_protocol}
    */
    readonly forwardingProtocol: string;
}
export declare function cdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroupToTerraform(struct?: CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroupOutputReference | CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroup): any;
export declare function cdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroupToHclTerraform(struct?: CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroupOutputReference | CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroup): any;
export declare class CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroup | undefined;
    set internalValue(value: CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroup | undefined);
    private _cdnFrontdoorOriginGroupId?;
    get cdnFrontdoorOriginGroupId(): string;
    set cdnFrontdoorOriginGroupId(value: string);
    get cdnFrontdoorOriginGroupIdInput(): string | undefined;
    private _forwardingProtocol?;
    get forwardingProtocol(): string;
    set forwardingProtocol(value: string);
    get forwardingProtocolInput(): string | undefined;
}
export interface CdnFrontdoorRuleActionsRouteConfigurationOverride {
    /**
    * caching block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#caching CdnFrontdoorRule#caching}
    */
    readonly caching: CdnFrontdoorRuleActionsRouteConfigurationOverrideCaching;
    /**
    * origin_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#origin_group CdnFrontdoorRule#origin_group}
    */
    readonly originGroup?: CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroup;
}
export declare function cdnFrontdoorRuleActionsRouteConfigurationOverrideToTerraform(struct?: CdnFrontdoorRuleActionsRouteConfigurationOverrideOutputReference | CdnFrontdoorRuleActionsRouteConfigurationOverride): any;
export declare function cdnFrontdoorRuleActionsRouteConfigurationOverrideToHclTerraform(struct?: CdnFrontdoorRuleActionsRouteConfigurationOverrideOutputReference | CdnFrontdoorRuleActionsRouteConfigurationOverride): any;
export declare class CdnFrontdoorRuleActionsRouteConfigurationOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorRuleActionsRouteConfigurationOverride | undefined;
    set internalValue(value: CdnFrontdoorRuleActionsRouteConfigurationOverride | undefined);
    private _caching;
    get caching(): CdnFrontdoorRuleActionsRouteConfigurationOverrideCachingOutputReference;
    putCaching(value: CdnFrontdoorRuleActionsRouteConfigurationOverrideCaching): void;
    get cachingInput(): CdnFrontdoorRuleActionsRouteConfigurationOverrideCaching | undefined;
    private _originGroup;
    get originGroup(): CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroupOutputReference;
    putOriginGroup(value: CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroup): void;
    resetOriginGroup(): void;
    get originGroupInput(): CdnFrontdoorRuleActionsRouteConfigurationOverrideOriginGroup | undefined;
}
export interface CdnFrontdoorRuleActionsUrlRedirect {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#destination_fragment CdnFrontdoorRule#destination_fragment}
    */
    readonly destinationFragment?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#destination_host_name CdnFrontdoorRule#destination_host_name}
    */
    readonly destinationHostName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#destination_path CdnFrontdoorRule#destination_path}
    */
    readonly destinationPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#query_string CdnFrontdoorRule#query_string}
    */
    readonly queryString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#redirect_protocol CdnFrontdoorRule#redirect_protocol}
    */
    readonly redirectProtocol?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#redirect_type CdnFrontdoorRule#redirect_type}
    */
    readonly redirectType: string;
}
export declare function cdnFrontdoorRuleActionsUrlRedirectToTerraform(struct?: CdnFrontdoorRuleActionsUrlRedirectOutputReference | CdnFrontdoorRuleActionsUrlRedirect): any;
export declare function cdnFrontdoorRuleActionsUrlRedirectToHclTerraform(struct?: CdnFrontdoorRuleActionsUrlRedirectOutputReference | CdnFrontdoorRuleActionsUrlRedirect): any;
export declare class CdnFrontdoorRuleActionsUrlRedirectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorRuleActionsUrlRedirect | undefined;
    set internalValue(value: CdnFrontdoorRuleActionsUrlRedirect | undefined);
    private _destinationFragment?;
    get destinationFragment(): string;
    set destinationFragment(value: string);
    resetDestinationFragment(): void;
    get destinationFragmentInput(): string | undefined;
    private _destinationHostName?;
    get destinationHostName(): string;
    set destinationHostName(value: string);
    resetDestinationHostName(): void;
    get destinationHostNameInput(): string | undefined;
    private _destinationPath?;
    get destinationPath(): string;
    set destinationPath(value: string);
    resetDestinationPath(): void;
    get destinationPathInput(): string | undefined;
    private _queryString?;
    get queryString(): string;
    set queryString(value: string);
    resetQueryString(): void;
    get queryStringInput(): string | undefined;
    private _redirectProtocol?;
    get redirectProtocol(): string;
    set redirectProtocol(value: string);
    resetRedirectProtocol(): void;
    get redirectProtocolInput(): string | undefined;
    private _redirectType?;
    get redirectType(): string;
    set redirectType(value: string);
    get redirectTypeInput(): string | undefined;
}
export interface CdnFrontdoorRuleActionsUrlRewrite {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#destination_path CdnFrontdoorRule#destination_path}
    */
    readonly destinationPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#preserve_unmatched_path_enabled CdnFrontdoorRule#preserve_unmatched_path_enabled}
    */
    readonly preserveUnmatchedPathEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#source_pattern CdnFrontdoorRule#source_pattern}
    */
    readonly sourcePattern: string;
}
export declare function cdnFrontdoorRuleActionsUrlRewriteToTerraform(struct?: CdnFrontdoorRuleActionsUrlRewriteOutputReference | CdnFrontdoorRuleActionsUrlRewrite): any;
export declare function cdnFrontdoorRuleActionsUrlRewriteToHclTerraform(struct?: CdnFrontdoorRuleActionsUrlRewriteOutputReference | CdnFrontdoorRuleActionsUrlRewrite): any;
export declare class CdnFrontdoorRuleActionsUrlRewriteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorRuleActionsUrlRewrite | undefined;
    set internalValue(value: CdnFrontdoorRuleActionsUrlRewrite | undefined);
    private _destinationPath?;
    get destinationPath(): string;
    set destinationPath(value: string);
    get destinationPathInput(): string | undefined;
    private _preserveUnmatchedPathEnabled?;
    get preserveUnmatchedPathEnabled(): boolean | cdktn.IResolvable;
    set preserveUnmatchedPathEnabled(value: boolean | cdktn.IResolvable);
    resetPreserveUnmatchedPathEnabled(): void;
    get preserveUnmatchedPathEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _sourcePattern?;
    get sourcePattern(): string;
    set sourcePattern(value: string);
    get sourcePatternInput(): string | undefined;
}
export interface CdnFrontdoorRuleActions {
    /**
    * modify_request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#modify_request_header CdnFrontdoorRule#modify_request_header}
    */
    readonly modifyRequestHeader?: CdnFrontdoorRuleActionsModifyRequestHeader[] | cdktn.IResolvable;
    /**
    * modify_response_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#modify_response_header CdnFrontdoorRule#modify_response_header}
    */
    readonly modifyResponseHeader?: CdnFrontdoorRuleActionsModifyResponseHeader[] | cdktn.IResolvable;
    /**
    * route_configuration_override block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#route_configuration_override CdnFrontdoorRule#route_configuration_override}
    */
    readonly routeConfigurationOverride?: CdnFrontdoorRuleActionsRouteConfigurationOverride;
    /**
    * url_redirect block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#url_redirect CdnFrontdoorRule#url_redirect}
    */
    readonly urlRedirect?: CdnFrontdoorRuleActionsUrlRedirect;
    /**
    * url_rewrite block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#url_rewrite CdnFrontdoorRule#url_rewrite}
    */
    readonly urlRewrite?: CdnFrontdoorRuleActionsUrlRewrite;
}
export declare function cdnFrontdoorRuleActionsToTerraform(struct?: CdnFrontdoorRuleActionsOutputReference | CdnFrontdoorRuleActions): any;
export declare function cdnFrontdoorRuleActionsToHclTerraform(struct?: CdnFrontdoorRuleActionsOutputReference | CdnFrontdoorRuleActions): any;
export declare class CdnFrontdoorRuleActionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorRuleActions | undefined;
    set internalValue(value: CdnFrontdoorRuleActions | undefined);
    private _modifyRequestHeader;
    get modifyRequestHeader(): CdnFrontdoorRuleActionsModifyRequestHeaderList;
    putModifyRequestHeader(value: CdnFrontdoorRuleActionsModifyRequestHeader[] | cdktn.IResolvable): void;
    resetModifyRequestHeader(): void;
    get modifyRequestHeaderInput(): cdktn.IResolvable | CdnFrontdoorRuleActionsModifyRequestHeader[] | undefined;
    private _modifyResponseHeader;
    get modifyResponseHeader(): CdnFrontdoorRuleActionsModifyResponseHeaderList;
    putModifyResponseHeader(value: CdnFrontdoorRuleActionsModifyResponseHeader[] | cdktn.IResolvable): void;
    resetModifyResponseHeader(): void;
    get modifyResponseHeaderInput(): cdktn.IResolvable | CdnFrontdoorRuleActionsModifyResponseHeader[] | undefined;
    private _routeConfigurationOverride;
    get routeConfigurationOverride(): CdnFrontdoorRuleActionsRouteConfigurationOverrideOutputReference;
    putRouteConfigurationOverride(value: CdnFrontdoorRuleActionsRouteConfigurationOverride): void;
    resetRouteConfigurationOverride(): void;
    get routeConfigurationOverrideInput(): CdnFrontdoorRuleActionsRouteConfigurationOverride | undefined;
    private _urlRedirect;
    get urlRedirect(): CdnFrontdoorRuleActionsUrlRedirectOutputReference;
    putUrlRedirect(value: CdnFrontdoorRuleActionsUrlRedirect): void;
    resetUrlRedirect(): void;
    get urlRedirectInput(): CdnFrontdoorRuleActionsUrlRedirect | undefined;
    private _urlRewrite;
    get urlRewrite(): CdnFrontdoorRuleActionsUrlRewriteOutputReference;
    putUrlRewrite(value: CdnFrontdoorRuleActionsUrlRewrite): void;
    resetUrlRewrite(): void;
    get urlRewriteInput(): CdnFrontdoorRuleActionsUrlRewrite | undefined;
}
export interface CdnFrontdoorRuleConditionsClientPort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsClientPortToTerraform(struct?: CdnFrontdoorRuleConditionsClientPort | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsClientPortToHclTerraform(struct?: CdnFrontdoorRuleConditionsClientPort | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsClientPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsClientPort | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsClientPort | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsClientPortList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsClientPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsClientPortOutputReference;
}
export interface CdnFrontdoorRuleConditionsDeviceType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorRuleConditionsDeviceTypeToTerraform(struct?: CdnFrontdoorRuleConditionsDeviceType | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsDeviceTypeToHclTerraform(struct?: CdnFrontdoorRuleConditionsDeviceType | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsDeviceTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsDeviceType | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsDeviceType | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsDeviceTypeList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsDeviceType[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsDeviceTypeOutputReference;
}
export interface CdnFrontdoorRuleConditionsHostName {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#transforms CdnFrontdoorRule#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsHostNameToTerraform(struct?: CdnFrontdoorRuleConditionsHostName | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsHostNameToHclTerraform(struct?: CdnFrontdoorRuleConditionsHostName | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsHostNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsHostName | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsHostName | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsHostNameList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsHostName[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsHostNameOutputReference;
}
export interface CdnFrontdoorRuleConditionsHttpVersion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorRuleConditionsHttpVersionToTerraform(struct?: CdnFrontdoorRuleConditionsHttpVersion | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsHttpVersionToHclTerraform(struct?: CdnFrontdoorRuleConditionsHttpVersion | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsHttpVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsHttpVersion | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsHttpVersion | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsHttpVersionList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsHttpVersion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsHttpVersionOutputReference;
}
export interface CdnFrontdoorRuleConditionsPostArgument {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#name CdnFrontdoorRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#transforms CdnFrontdoorRule#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsPostArgumentToTerraform(struct?: CdnFrontdoorRuleConditionsPostArgument | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsPostArgumentToHclTerraform(struct?: CdnFrontdoorRuleConditionsPostArgument | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsPostArgumentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsPostArgument | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsPostArgument | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsPostArgumentList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsPostArgument[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsPostArgumentOutputReference;
}
export interface CdnFrontdoorRuleConditionsQueryString {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#transforms CdnFrontdoorRule#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsQueryStringToTerraform(struct?: CdnFrontdoorRuleConditionsQueryString | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsQueryStringToHclTerraform(struct?: CdnFrontdoorRuleConditionsQueryString | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsQueryStringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsQueryString | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsQueryString | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsQueryStringList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsQueryString[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsQueryStringOutputReference;
}
export interface CdnFrontdoorRuleConditionsRemoteAddress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorRuleConditionsRemoteAddressToTerraform(struct?: CdnFrontdoorRuleConditionsRemoteAddress | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsRemoteAddressToHclTerraform(struct?: CdnFrontdoorRuleConditionsRemoteAddress | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsRemoteAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsRemoteAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsRemoteAddress | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsRemoteAddressList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsRemoteAddress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsRemoteAddressOutputReference;
}
export interface CdnFrontdoorRuleConditionsRequestBody {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#transforms CdnFrontdoorRule#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsRequestBodyToTerraform(struct?: CdnFrontdoorRuleConditionsRequestBody | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsRequestBodyToHclTerraform(struct?: CdnFrontdoorRuleConditionsRequestBody | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsRequestBodyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsRequestBody | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsRequestBody | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsRequestBodyList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsRequestBody[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsRequestBodyOutputReference;
}
export interface CdnFrontdoorRuleConditionsRequestCookies {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#name CdnFrontdoorRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#transforms CdnFrontdoorRule#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsRequestCookiesToTerraform(struct?: CdnFrontdoorRuleConditionsRequestCookies | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsRequestCookiesToHclTerraform(struct?: CdnFrontdoorRuleConditionsRequestCookies | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsRequestCookiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsRequestCookies | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsRequestCookies | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsRequestCookiesList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsRequestCookies[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsRequestCookiesOutputReference;
}
export interface CdnFrontdoorRuleConditionsRequestFileExtension {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#transforms CdnFrontdoorRule#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsRequestFileExtensionToTerraform(struct?: CdnFrontdoorRuleConditionsRequestFileExtension | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsRequestFileExtensionToHclTerraform(struct?: CdnFrontdoorRuleConditionsRequestFileExtension | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsRequestFileExtensionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsRequestFileExtension | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsRequestFileExtension | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsRequestFileExtensionList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsRequestFileExtension[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsRequestFileExtensionOutputReference;
}
export interface CdnFrontdoorRuleConditionsRequestFilename {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#transforms CdnFrontdoorRule#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsRequestFilenameToTerraform(struct?: CdnFrontdoorRuleConditionsRequestFilename | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsRequestFilenameToHclTerraform(struct?: CdnFrontdoorRuleConditionsRequestFilename | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsRequestFilenameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsRequestFilename | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsRequestFilename | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsRequestFilenameList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsRequestFilename[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsRequestFilenameOutputReference;
}
export interface CdnFrontdoorRuleConditionsRequestHeader {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#name CdnFrontdoorRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#transforms CdnFrontdoorRule#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsRequestHeaderToTerraform(struct?: CdnFrontdoorRuleConditionsRequestHeader | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsRequestHeaderToHclTerraform(struct?: CdnFrontdoorRuleConditionsRequestHeader | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsRequestHeader | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsRequestHeader | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsRequestHeaderList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsRequestHeader[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsRequestHeaderOutputReference;
}
export interface CdnFrontdoorRuleConditionsRequestMethod {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorRuleConditionsRequestMethodToTerraform(struct?: CdnFrontdoorRuleConditionsRequestMethod | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsRequestMethodToHclTerraform(struct?: CdnFrontdoorRuleConditionsRequestMethod | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsRequestMethodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsRequestMethod | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsRequestMethod | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsRequestMethodList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsRequestMethod[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsRequestMethodOutputReference;
}
export interface CdnFrontdoorRuleConditionsRequestPath {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#transforms CdnFrontdoorRule#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsRequestPathToTerraform(struct?: CdnFrontdoorRuleConditionsRequestPath | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsRequestPathToHclTerraform(struct?: CdnFrontdoorRuleConditionsRequestPath | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsRequestPathOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsRequestPath | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsRequestPath | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsRequestPathList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsRequestPath[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsRequestPathOutputReference;
}
export interface CdnFrontdoorRuleConditionsRequestScheme {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorRuleConditionsRequestSchemeToTerraform(struct?: CdnFrontdoorRuleConditionsRequestScheme | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsRequestSchemeToHclTerraform(struct?: CdnFrontdoorRuleConditionsRequestScheme | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsRequestSchemeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsRequestScheme | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsRequestScheme | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsRequestSchemeList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsRequestScheme[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsRequestSchemeOutputReference;
}
export interface CdnFrontdoorRuleConditionsRequestUrl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#transforms CdnFrontdoorRule#transforms}
    */
    readonly transforms?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsRequestUrlToTerraform(struct?: CdnFrontdoorRuleConditionsRequestUrl | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsRequestUrlToHclTerraform(struct?: CdnFrontdoorRuleConditionsRequestUrl | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsRequestUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsRequestUrl | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsRequestUrl | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _transforms?;
    get transforms(): string[];
    set transforms(value: string[]);
    resetTransforms(): void;
    get transformsInput(): string[] | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsRequestUrlList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsRequestUrl[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsRequestUrlOutputReference;
}
export interface CdnFrontdoorRuleConditionsServerPort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values?: string[];
}
export declare function cdnFrontdoorRuleConditionsServerPortToTerraform(struct?: CdnFrontdoorRuleConditionsServerPort | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsServerPortToHclTerraform(struct?: CdnFrontdoorRuleConditionsServerPort | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsServerPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsServerPort | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsServerPort | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    resetValues(): void;
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsServerPortList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsServerPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsServerPortOutputReference;
}
export interface CdnFrontdoorRuleConditionsSocketAddress {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorRuleConditionsSocketAddressToTerraform(struct?: CdnFrontdoorRuleConditionsSocketAddress | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsSocketAddressToHclTerraform(struct?: CdnFrontdoorRuleConditionsSocketAddress | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsSocketAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsSocketAddress | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsSocketAddress | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsSocketAddressList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsSocketAddress[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsSocketAddressOutputReference;
}
export interface CdnFrontdoorRuleConditionsSslProtocol {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#operator CdnFrontdoorRule#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#values CdnFrontdoorRule#values}
    */
    readonly values: string[];
}
export declare function cdnFrontdoorRuleConditionsSslProtocolToTerraform(struct?: CdnFrontdoorRuleConditionsSslProtocol | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleConditionsSslProtocolToHclTerraform(struct?: CdnFrontdoorRuleConditionsSslProtocol | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleConditionsSslProtocolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CdnFrontdoorRuleConditionsSslProtocol | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleConditionsSslProtocol | cdktn.IResolvable | undefined);
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class CdnFrontdoorRuleConditionsSslProtocolList extends cdktn.ComplexList {
    internalValue?: CdnFrontdoorRuleConditionsSslProtocol[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CdnFrontdoorRuleConditionsSslProtocolOutputReference;
}
export interface CdnFrontdoorRuleConditions {
    /**
    * client_port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#client_port CdnFrontdoorRule#client_port}
    */
    readonly clientPort?: CdnFrontdoorRuleConditionsClientPort[] | cdktn.IResolvable;
    /**
    * device_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#device_type CdnFrontdoorRule#device_type}
    */
    readonly deviceType?: CdnFrontdoorRuleConditionsDeviceType[] | cdktn.IResolvable;
    /**
    * host_name block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#host_name CdnFrontdoorRule#host_name}
    */
    readonly hostName?: CdnFrontdoorRuleConditionsHostName[] | cdktn.IResolvable;
    /**
    * http_version block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#http_version CdnFrontdoorRule#http_version}
    */
    readonly httpVersion?: CdnFrontdoorRuleConditionsHttpVersion[] | cdktn.IResolvable;
    /**
    * post_argument block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#post_argument CdnFrontdoorRule#post_argument}
    */
    readonly postArgument?: CdnFrontdoorRuleConditionsPostArgument[] | cdktn.IResolvable;
    /**
    * query_string block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#query_string CdnFrontdoorRule#query_string}
    */
    readonly queryString?: CdnFrontdoorRuleConditionsQueryString[] | cdktn.IResolvable;
    /**
    * remote_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#remote_address CdnFrontdoorRule#remote_address}
    */
    readonly remoteAddress?: CdnFrontdoorRuleConditionsRemoteAddress[] | cdktn.IResolvable;
    /**
    * request_body block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#request_body CdnFrontdoorRule#request_body}
    */
    readonly requestBody?: CdnFrontdoorRuleConditionsRequestBody[] | cdktn.IResolvable;
    /**
    * request_cookies block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#request_cookies CdnFrontdoorRule#request_cookies}
    */
    readonly requestCookies?: CdnFrontdoorRuleConditionsRequestCookies[] | cdktn.IResolvable;
    /**
    * request_file_extension block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#request_file_extension CdnFrontdoorRule#request_file_extension}
    */
    readonly requestFileExtension?: CdnFrontdoorRuleConditionsRequestFileExtension[] | cdktn.IResolvable;
    /**
    * request_filename block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#request_filename CdnFrontdoorRule#request_filename}
    */
    readonly requestFilename?: CdnFrontdoorRuleConditionsRequestFilename[] | cdktn.IResolvable;
    /**
    * request_header block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#request_header CdnFrontdoorRule#request_header}
    */
    readonly requestHeader?: CdnFrontdoorRuleConditionsRequestHeader[] | cdktn.IResolvable;
    /**
    * request_method block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#request_method CdnFrontdoorRule#request_method}
    */
    readonly requestMethod?: CdnFrontdoorRuleConditionsRequestMethod[] | cdktn.IResolvable;
    /**
    * request_path block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#request_path CdnFrontdoorRule#request_path}
    */
    readonly requestPath?: CdnFrontdoorRuleConditionsRequestPath[] | cdktn.IResolvable;
    /**
    * request_scheme block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#request_scheme CdnFrontdoorRule#request_scheme}
    */
    readonly requestScheme?: CdnFrontdoorRuleConditionsRequestScheme[] | cdktn.IResolvable;
    /**
    * request_url block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#request_url CdnFrontdoorRule#request_url}
    */
    readonly requestUrl?: CdnFrontdoorRuleConditionsRequestUrl[] | cdktn.IResolvable;
    /**
    * server_port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#server_port CdnFrontdoorRule#server_port}
    */
    readonly serverPort?: CdnFrontdoorRuleConditionsServerPort[] | cdktn.IResolvable;
    /**
    * socket_address block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#socket_address CdnFrontdoorRule#socket_address}
    */
    readonly socketAddress?: CdnFrontdoorRuleConditionsSocketAddress[] | cdktn.IResolvable;
    /**
    * ssl_protocol block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#ssl_protocol CdnFrontdoorRule#ssl_protocol}
    */
    readonly sslProtocol?: CdnFrontdoorRuleConditionsSslProtocol[] | cdktn.IResolvable;
}
export declare function cdnFrontdoorRuleConditionsToTerraform(struct?: CdnFrontdoorRuleConditionsOutputReference | CdnFrontdoorRuleConditions): any;
export declare function cdnFrontdoorRuleConditionsToHclTerraform(struct?: CdnFrontdoorRuleConditionsOutputReference | CdnFrontdoorRuleConditions): any;
export declare class CdnFrontdoorRuleConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorRuleConditions | undefined;
    set internalValue(value: CdnFrontdoorRuleConditions | undefined);
    private _clientPort;
    get clientPort(): CdnFrontdoorRuleConditionsClientPortList;
    putClientPort(value: CdnFrontdoorRuleConditionsClientPort[] | cdktn.IResolvable): void;
    resetClientPort(): void;
    get clientPortInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsClientPort[] | undefined;
    private _deviceType;
    get deviceType(): CdnFrontdoorRuleConditionsDeviceTypeList;
    putDeviceType(value: CdnFrontdoorRuleConditionsDeviceType[] | cdktn.IResolvable): void;
    resetDeviceType(): void;
    get deviceTypeInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsDeviceType[] | undefined;
    private _hostName;
    get hostName(): CdnFrontdoorRuleConditionsHostNameList;
    putHostName(value: CdnFrontdoorRuleConditionsHostName[] | cdktn.IResolvable): void;
    resetHostName(): void;
    get hostNameInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsHostName[] | undefined;
    private _httpVersion;
    get httpVersion(): CdnFrontdoorRuleConditionsHttpVersionList;
    putHttpVersion(value: CdnFrontdoorRuleConditionsHttpVersion[] | cdktn.IResolvable): void;
    resetHttpVersion(): void;
    get httpVersionInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsHttpVersion[] | undefined;
    private _postArgument;
    get postArgument(): CdnFrontdoorRuleConditionsPostArgumentList;
    putPostArgument(value: CdnFrontdoorRuleConditionsPostArgument[] | cdktn.IResolvable): void;
    resetPostArgument(): void;
    get postArgumentInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsPostArgument[] | undefined;
    private _queryString;
    get queryString(): CdnFrontdoorRuleConditionsQueryStringList;
    putQueryString(value: CdnFrontdoorRuleConditionsQueryString[] | cdktn.IResolvable): void;
    resetQueryString(): void;
    get queryStringInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsQueryString[] | undefined;
    private _remoteAddress;
    get remoteAddress(): CdnFrontdoorRuleConditionsRemoteAddressList;
    putRemoteAddress(value: CdnFrontdoorRuleConditionsRemoteAddress[] | cdktn.IResolvable): void;
    resetRemoteAddress(): void;
    get remoteAddressInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsRemoteAddress[] | undefined;
    private _requestBody;
    get requestBody(): CdnFrontdoorRuleConditionsRequestBodyList;
    putRequestBody(value: CdnFrontdoorRuleConditionsRequestBody[] | cdktn.IResolvable): void;
    resetRequestBody(): void;
    get requestBodyInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsRequestBody[] | undefined;
    private _requestCookies;
    get requestCookies(): CdnFrontdoorRuleConditionsRequestCookiesList;
    putRequestCookies(value: CdnFrontdoorRuleConditionsRequestCookies[] | cdktn.IResolvable): void;
    resetRequestCookies(): void;
    get requestCookiesInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsRequestCookies[] | undefined;
    private _requestFileExtension;
    get requestFileExtension(): CdnFrontdoorRuleConditionsRequestFileExtensionList;
    putRequestFileExtension(value: CdnFrontdoorRuleConditionsRequestFileExtension[] | cdktn.IResolvable): void;
    resetRequestFileExtension(): void;
    get requestFileExtensionInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsRequestFileExtension[] | undefined;
    private _requestFilename;
    get requestFilename(): CdnFrontdoorRuleConditionsRequestFilenameList;
    putRequestFilename(value: CdnFrontdoorRuleConditionsRequestFilename[] | cdktn.IResolvable): void;
    resetRequestFilename(): void;
    get requestFilenameInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsRequestFilename[] | undefined;
    private _requestHeader;
    get requestHeader(): CdnFrontdoorRuleConditionsRequestHeaderList;
    putRequestHeader(value: CdnFrontdoorRuleConditionsRequestHeader[] | cdktn.IResolvable): void;
    resetRequestHeader(): void;
    get requestHeaderInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsRequestHeader[] | undefined;
    private _requestMethod;
    get requestMethod(): CdnFrontdoorRuleConditionsRequestMethodList;
    putRequestMethod(value: CdnFrontdoorRuleConditionsRequestMethod[] | cdktn.IResolvable): void;
    resetRequestMethod(): void;
    get requestMethodInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsRequestMethod[] | undefined;
    private _requestPath;
    get requestPath(): CdnFrontdoorRuleConditionsRequestPathList;
    putRequestPath(value: CdnFrontdoorRuleConditionsRequestPath[] | cdktn.IResolvable): void;
    resetRequestPath(): void;
    get requestPathInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsRequestPath[] | undefined;
    private _requestScheme;
    get requestScheme(): CdnFrontdoorRuleConditionsRequestSchemeList;
    putRequestScheme(value: CdnFrontdoorRuleConditionsRequestScheme[] | cdktn.IResolvable): void;
    resetRequestScheme(): void;
    get requestSchemeInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsRequestScheme[] | undefined;
    private _requestUrl;
    get requestUrl(): CdnFrontdoorRuleConditionsRequestUrlList;
    putRequestUrl(value: CdnFrontdoorRuleConditionsRequestUrl[] | cdktn.IResolvable): void;
    resetRequestUrl(): void;
    get requestUrlInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsRequestUrl[] | undefined;
    private _serverPort;
    get serverPort(): CdnFrontdoorRuleConditionsServerPortList;
    putServerPort(value: CdnFrontdoorRuleConditionsServerPort[] | cdktn.IResolvable): void;
    resetServerPort(): void;
    get serverPortInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsServerPort[] | undefined;
    private _socketAddress;
    get socketAddress(): CdnFrontdoorRuleConditionsSocketAddressList;
    putSocketAddress(value: CdnFrontdoorRuleConditionsSocketAddress[] | cdktn.IResolvable): void;
    resetSocketAddress(): void;
    get socketAddressInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsSocketAddress[] | undefined;
    private _sslProtocol;
    get sslProtocol(): CdnFrontdoorRuleConditionsSslProtocolList;
    putSslProtocol(value: CdnFrontdoorRuleConditionsSslProtocol[] | cdktn.IResolvable): void;
    resetSslProtocol(): void;
    get sslProtocolInput(): cdktn.IResolvable | CdnFrontdoorRuleConditionsSslProtocol[] | undefined;
}
export interface CdnFrontdoorRuleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#create CdnFrontdoorRule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#delete CdnFrontdoorRule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#read CdnFrontdoorRule#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#update CdnFrontdoorRule#update}
    */
    readonly update?: string;
}
export declare function cdnFrontdoorRuleTimeoutsToTerraform(struct?: CdnFrontdoorRuleTimeouts | cdktn.IResolvable): any;
export declare function cdnFrontdoorRuleTimeoutsToHclTerraform(struct?: CdnFrontdoorRuleTimeouts | cdktn.IResolvable): any;
export declare class CdnFrontdoorRuleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CdnFrontdoorRuleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CdnFrontdoorRuleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule azurerm_cdn_frontdoor_rule}
*/
export declare class CdnFrontdoorRule extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_cdn_frontdoor_rule";
    /**
    * Generates CDKTN code for importing a CdnFrontdoorRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CdnFrontdoorRule to import
    * @param importFromId The id of the existing CdnFrontdoorRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CdnFrontdoorRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cdn_frontdoor_rule azurerm_cdn_frontdoor_rule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CdnFrontdoorRuleConfig
    */
    constructor(scope: Construct, id: string, config: CdnFrontdoorRuleConfig);
    private _behaviourOnMatch?;
    get behaviourOnMatch(): string;
    set behaviourOnMatch(value: string);
    resetBehaviourOnMatch(): void;
    get behaviourOnMatchInput(): string | undefined;
    private _cdnFrontdoorRuleSetId?;
    get cdnFrontdoorRuleSetId(): string;
    set cdnFrontdoorRuleSetId(value: string);
    get cdnFrontdoorRuleSetIdInput(): string | undefined;
    get cdnFrontdoorRuleSetName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _order?;
    get order(): number;
    set order(value: number);
    get orderInput(): number | undefined;
    private _actions;
    get actions(): CdnFrontdoorRuleActionsOutputReference;
    putActions(value: CdnFrontdoorRuleActions): void;
    get actionsInput(): CdnFrontdoorRuleActions | undefined;
    private _conditions;
    get conditions(): CdnFrontdoorRuleConditionsOutputReference;
    putConditions(value: CdnFrontdoorRuleConditions): void;
    resetConditions(): void;
    get conditionsInput(): CdnFrontdoorRuleConditions | undefined;
    private _timeouts;
    get timeouts(): CdnFrontdoorRuleTimeoutsOutputReference;
    putTimeouts(value: CdnFrontdoorRuleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CdnFrontdoorRuleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
