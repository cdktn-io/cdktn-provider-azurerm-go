/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermDatabricksWorkspacePrivateEndpointConnectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/databricks_workspace_private_endpoint_connection#id DataAzurermDatabricksWorkspacePrivateEndpointConnection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/databricks_workspace_private_endpoint_connection#private_endpoint_id DataAzurermDatabricksWorkspacePrivateEndpointConnection#private_endpoint_id}
    */
    readonly privateEndpointId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/databricks_workspace_private_endpoint_connection#workspace_id DataAzurermDatabricksWorkspacePrivateEndpointConnection#workspace_id}
    */
    readonly workspaceId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/databricks_workspace_private_endpoint_connection#timeouts DataAzurermDatabricksWorkspacePrivateEndpointConnection#timeouts}
    */
    readonly timeouts?: DataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeouts;
}
export interface DataAzurermDatabricksWorkspacePrivateEndpointConnectionConnections {
}
export declare function dataAzurermDatabricksWorkspacePrivateEndpointConnectionConnectionsToTerraform(struct?: DataAzurermDatabricksWorkspacePrivateEndpointConnectionConnections): any;
export declare function dataAzurermDatabricksWorkspacePrivateEndpointConnectionConnectionsToHclTerraform(struct?: DataAzurermDatabricksWorkspacePrivateEndpointConnectionConnections): any;
export declare class DataAzurermDatabricksWorkspacePrivateEndpointConnectionConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermDatabricksWorkspacePrivateEndpointConnectionConnections | undefined;
    set internalValue(value: DataAzurermDatabricksWorkspacePrivateEndpointConnectionConnections | undefined);
    get actionRequired(): string;
    get description(): string;
    get name(): string;
    get status(): string;
    get workspacePrivateEndpointId(): string;
}
export declare class DataAzurermDatabricksWorkspacePrivateEndpointConnectionConnectionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermDatabricksWorkspacePrivateEndpointConnectionConnectionsOutputReference;
}
export interface DataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/databricks_workspace_private_endpoint_connection#read DataAzurermDatabricksWorkspacePrivateEndpointConnection#read}
    */
    readonly read?: string;
}
export declare function dataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeoutsToTerraform(struct?: DataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeoutsToHclTerraform(struct?: DataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/databricks_workspace_private_endpoint_connection azurerm_databricks_workspace_private_endpoint_connection}
*/
export declare class DataAzurermDatabricksWorkspacePrivateEndpointConnection extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_databricks_workspace_private_endpoint_connection";
    /**
    * Generates CDKTN code for importing a DataAzurermDatabricksWorkspacePrivateEndpointConnection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermDatabricksWorkspacePrivateEndpointConnection to import
    * @param importFromId The id of the existing DataAzurermDatabricksWorkspacePrivateEndpointConnection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/databricks_workspace_private_endpoint_connection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermDatabricksWorkspacePrivateEndpointConnection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/databricks_workspace_private_endpoint_connection azurerm_databricks_workspace_private_endpoint_connection} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermDatabricksWorkspacePrivateEndpointConnectionConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermDatabricksWorkspacePrivateEndpointConnectionConfig);
    private _connections;
    get connections(): DataAzurermDatabricksWorkspacePrivateEndpointConnectionConnectionsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _privateEndpointId?;
    get privateEndpointId(): string;
    set privateEndpointId(value: string);
    get privateEndpointIdInput(): string | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    get workspaceIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeoutsOutputReference;
    putTimeouts(value: DataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermDatabricksWorkspacePrivateEndpointConnectionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
