/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/key_vault_managed_hardware_security_module_role_definition#id DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinition#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/key_vault_managed_hardware_security_module_role_definition#managed_hsm_id DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinition#managed_hsm_id}
    */
    readonly managedHsmId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/key_vault_managed_hardware_security_module_role_definition#name DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinition#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/key_vault_managed_hardware_security_module_role_definition#timeouts DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinition#timeouts}
    */
    readonly timeouts?: DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeouts;
}
export interface DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermission {
}
export declare function dataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermissionToTerraform(struct?: DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermission): any;
export declare function dataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermissionToHclTerraform(struct?: DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermission): any;
export declare class DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermissionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermission | undefined;
    set internalValue(value: DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermission | undefined);
    get actions(): string[];
    get dataActions(): string[];
    get notActions(): string[];
    get notDataActions(): string[];
}
export declare class DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermissionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermissionOutputReference;
}
export interface DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/key_vault_managed_hardware_security_module_role_definition#read DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinition#read}
    */
    readonly read?: string;
}
export declare function dataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeoutsToTerraform(struct?: DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeoutsToHclTerraform(struct?: DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/key_vault_managed_hardware_security_module_role_definition azurerm_key_vault_managed_hardware_security_module_role_definition}
*/
export declare class DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinition extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_key_vault_managed_hardware_security_module_role_definition";
    /**
    * Generates CDKTN code for importing a DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinition resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinition to import
    * @param importFromId The id of the existing DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinition that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/key_vault_managed_hardware_security_module_role_definition#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinition to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/key_vault_managed_hardware_security_module_role_definition azurerm_key_vault_managed_hardware_security_module_role_definition} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionConfig);
    get assignableScopes(): string[];
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _managedHsmId?;
    get managedHsmId(): string;
    set managedHsmId(value: string);
    get managedHsmIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _permission;
    get permission(): DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionPermissionList;
    get resourceManagerId(): string;
    get roleName(): string;
    get roleType(): string;
    private _timeouts;
    get timeouts(): DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeoutsOutputReference;
    putTimeouts(value: DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermKeyVaultManagedHardwareSecurityModuleRoleDefinitionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
