/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationInsightsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#application_type ApplicationInsights#application_type}
    */
    readonly applicationType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#daily_data_cap_in_gb ApplicationInsights#daily_data_cap_in_gb}
    */
    readonly dailyDataCapInGb?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#daily_data_cap_notifications_enabled ApplicationInsights#daily_data_cap_notifications_enabled}
    */
    readonly dailyDataCapNotificationsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#force_customer_storage_for_profiler ApplicationInsights#force_customer_storage_for_profiler}
    */
    readonly forceCustomerStorageForProfiler?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#id ApplicationInsights#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#internet_ingestion_enabled ApplicationInsights#internet_ingestion_enabled}
    */
    readonly internetIngestionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#internet_query_enabled ApplicationInsights#internet_query_enabled}
    */
    readonly internetQueryEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#ip_masking_enabled ApplicationInsights#ip_masking_enabled}
    */
    readonly ipMaskingEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#local_authentication_enabled ApplicationInsights#local_authentication_enabled}
    */
    readonly localAuthenticationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#location ApplicationInsights#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#name ApplicationInsights#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#resource_group_name ApplicationInsights#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#retention_in_days ApplicationInsights#retention_in_days}
    */
    readonly retentionInDays?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#sampling_percentage ApplicationInsights#sampling_percentage}
    */
    readonly samplingPercentage?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#tags ApplicationInsights#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#workspace_id ApplicationInsights#workspace_id}
    */
    readonly workspaceId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#timeouts ApplicationInsights#timeouts}
    */
    readonly timeouts?: ApplicationInsightsTimeouts;
}
export interface ApplicationInsightsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#create ApplicationInsights#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#delete ApplicationInsights#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#read ApplicationInsights#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#update ApplicationInsights#update}
    */
    readonly update?: string;
}
export declare function applicationInsightsTimeoutsToTerraform(struct?: ApplicationInsightsTimeouts | cdktn.IResolvable): any;
export declare function applicationInsightsTimeoutsToHclTerraform(struct?: ApplicationInsightsTimeouts | cdktn.IResolvable): any;
export declare class ApplicationInsightsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationInsightsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationInsightsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights azurerm_application_insights}
*/
export declare class ApplicationInsights extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_application_insights";
    /**
    * Generates CDKTN code for importing a ApplicationInsights resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationInsights to import
    * @param importFromId The id of the existing ApplicationInsights that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationInsights to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_insights azurerm_application_insights} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationInsightsConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationInsightsConfig);
    get appId(): string;
    private _applicationType?;
    get applicationType(): string;
    set applicationType(value: string);
    get applicationTypeInput(): string | undefined;
    get connectionString(): string;
    private _dailyDataCapInGb?;
    get dailyDataCapInGb(): number;
    set dailyDataCapInGb(value: number);
    resetDailyDataCapInGb(): void;
    get dailyDataCapInGbInput(): number | undefined;
    private _dailyDataCapNotificationsEnabled?;
    get dailyDataCapNotificationsEnabled(): boolean | cdktn.IResolvable;
    set dailyDataCapNotificationsEnabled(value: boolean | cdktn.IResolvable);
    resetDailyDataCapNotificationsEnabled(): void;
    get dailyDataCapNotificationsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _forceCustomerStorageForProfiler?;
    get forceCustomerStorageForProfiler(): boolean | cdktn.IResolvable;
    set forceCustomerStorageForProfiler(value: boolean | cdktn.IResolvable);
    resetForceCustomerStorageForProfiler(): void;
    get forceCustomerStorageForProfilerInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get instrumentationKey(): string;
    private _internetIngestionEnabled?;
    get internetIngestionEnabled(): boolean | cdktn.IResolvable;
    set internetIngestionEnabled(value: boolean | cdktn.IResolvable);
    resetInternetIngestionEnabled(): void;
    get internetIngestionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _internetQueryEnabled?;
    get internetQueryEnabled(): boolean | cdktn.IResolvable;
    set internetQueryEnabled(value: boolean | cdktn.IResolvable);
    resetInternetQueryEnabled(): void;
    get internetQueryEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _ipMaskingEnabled?;
    get ipMaskingEnabled(): boolean | cdktn.IResolvable;
    set ipMaskingEnabled(value: boolean | cdktn.IResolvable);
    resetIpMaskingEnabled(): void;
    get ipMaskingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _localAuthenticationEnabled?;
    get localAuthenticationEnabled(): boolean | cdktn.IResolvable;
    set localAuthenticationEnabled(value: boolean | cdktn.IResolvable);
    resetLocalAuthenticationEnabled(): void;
    get localAuthenticationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _retentionInDays?;
    get retentionInDays(): number;
    set retentionInDays(value: number);
    resetRetentionInDays(): void;
    get retentionInDaysInput(): number | undefined;
    private _samplingPercentage?;
    get samplingPercentage(): number;
    set samplingPercentage(value: number);
    resetSamplingPercentage(): void;
    get samplingPercentageInput(): number | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _workspaceId?;
    get workspaceId(): string;
    set workspaceId(value: string);
    resetWorkspaceId(): void;
    get workspaceIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApplicationInsightsTimeoutsOutputReference;
    putTimeouts(value: ApplicationInsightsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationInsightsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
