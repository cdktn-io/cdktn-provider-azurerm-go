/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#fips_enabled ApplicationGateway#fips_enabled}
    */
    readonly fipsEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#firewall_policy_id ApplicationGateway#firewall_policy_id}
    */
    readonly firewallPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#force_firewall_policy_association ApplicationGateway#force_firewall_policy_association}
    */
    readonly forceFirewallPolicyAssociation?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#http2_enabled ApplicationGateway#http2_enabled}
    */
    readonly http2Enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#id ApplicationGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#location ApplicationGateway#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#resource_group_name ApplicationGateway#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#tags ApplicationGateway#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#zones ApplicationGateway#zones}
    */
    readonly zones?: string[];
    /**
    * autoscale_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#autoscale_configuration ApplicationGateway#autoscale_configuration}
    */
    readonly autoscaleConfiguration?: ApplicationGatewayAutoscaleConfiguration;
    /**
    * backend block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#backend ApplicationGateway#backend}
    */
    readonly backend?: ApplicationGatewayBackend[] | cdktn.IResolvable;
    /**
    * backend_address_pool block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#backend_address_pool ApplicationGateway#backend_address_pool}
    */
    readonly backendAddressPool: ApplicationGatewayBackendAddressPool[] | cdktn.IResolvable;
    /**
    * backend_http_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#backend_http_settings ApplicationGateway#backend_http_settings}
    */
    readonly backendHttpSettings?: ApplicationGatewayBackendHttpSettings[] | cdktn.IResolvable;
    /**
    * custom_error_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#custom_error_configuration ApplicationGateway#custom_error_configuration}
    */
    readonly customErrorConfiguration?: ApplicationGatewayCustomErrorConfiguration[] | cdktn.IResolvable;
    /**
    * frontend_ip_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#frontend_ip_configuration ApplicationGateway#frontend_ip_configuration}
    */
    readonly frontendIpConfiguration: ApplicationGatewayFrontendIpConfiguration[] | cdktn.IResolvable;
    /**
    * frontend_port block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#frontend_port ApplicationGateway#frontend_port}
    */
    readonly frontendPort: ApplicationGatewayFrontendPort[] | cdktn.IResolvable;
    /**
    * gateway_ip_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#gateway_ip_configuration ApplicationGateway#gateway_ip_configuration}
    */
    readonly gatewayIpConfiguration: ApplicationGatewayGatewayIpConfiguration[] | cdktn.IResolvable;
    /**
    * global block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#global ApplicationGateway#global}
    */
    readonly global?: ApplicationGatewayGlobal;
    /**
    * http_listener block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#http_listener ApplicationGateway#http_listener}
    */
    readonly httpListener?: ApplicationGatewayHttpListener[] | cdktn.IResolvable;
    /**
    * identity block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#identity ApplicationGateway#identity}
    */
    readonly identity?: ApplicationGatewayIdentity;
    /**
    * listener block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#listener ApplicationGateway#listener}
    */
    readonly listener?: ApplicationGatewayListener[] | cdktn.IResolvable;
    /**
    * private_link_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#private_link_configuration ApplicationGateway#private_link_configuration}
    */
    readonly privateLinkConfiguration?: ApplicationGatewayPrivateLinkConfiguration[] | cdktn.IResolvable;
    /**
    * probe block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#probe ApplicationGateway#probe}
    */
    readonly probe?: ApplicationGatewayProbe[] | cdktn.IResolvable;
    /**
    * redirect_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#redirect_configuration ApplicationGateway#redirect_configuration}
    */
    readonly redirectConfiguration?: ApplicationGatewayRedirectConfiguration[] | cdktn.IResolvable;
    /**
    * request_routing_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#request_routing_rule ApplicationGateway#request_routing_rule}
    */
    readonly requestRoutingRule?: ApplicationGatewayRequestRoutingRule[] | cdktn.IResolvable;
    /**
    * rewrite_rule_set block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#rewrite_rule_set ApplicationGateway#rewrite_rule_set}
    */
    readonly rewriteRuleSet?: ApplicationGatewayRewriteRuleSet[] | cdktn.IResolvable;
    /**
    * routing_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#routing_rule ApplicationGateway#routing_rule}
    */
    readonly routingRule?: ApplicationGatewayRoutingRule[] | cdktn.IResolvable;
    /**
    * sku block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#sku ApplicationGateway#sku}
    */
    readonly sku: ApplicationGatewaySku;
    /**
    * ssl_certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ssl_certificate ApplicationGateway#ssl_certificate}
    */
    readonly sslCertificate?: ApplicationGatewaySslCertificate[] | cdktn.IResolvable;
    /**
    * ssl_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ssl_policy ApplicationGateway#ssl_policy}
    */
    readonly sslPolicy?: ApplicationGatewaySslPolicy;
    /**
    * ssl_profile block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ssl_profile ApplicationGateway#ssl_profile}
    */
    readonly sslProfile?: ApplicationGatewaySslProfile[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#timeouts ApplicationGateway#timeouts}
    */
    readonly timeouts?: ApplicationGatewayTimeouts;
    /**
    * trusted_client_certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#trusted_client_certificate ApplicationGateway#trusted_client_certificate}
    */
    readonly trustedClientCertificate?: ApplicationGatewayTrustedClientCertificate[] | cdktn.IResolvable;
    /**
    * trusted_root_certificate block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#trusted_root_certificate ApplicationGateway#trusted_root_certificate}
    */
    readonly trustedRootCertificate?: ApplicationGatewayTrustedRootCertificate[] | cdktn.IResolvable;
    /**
    * url_path_map block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#url_path_map ApplicationGateway#url_path_map}
    */
    readonly urlPathMap?: ApplicationGatewayUrlPathMap[] | cdktn.IResolvable;
    /**
    * waf_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#waf_configuration ApplicationGateway#waf_configuration}
    */
    readonly wafConfiguration?: ApplicationGatewayWafConfiguration;
}
export interface ApplicationGatewayPrivateEndpointConnection {
}
export declare function applicationGatewayPrivateEndpointConnectionToTerraform(struct?: ApplicationGatewayPrivateEndpointConnection): any;
export declare function applicationGatewayPrivateEndpointConnectionToHclTerraform(struct?: ApplicationGatewayPrivateEndpointConnection): any;
export declare class ApplicationGatewayPrivateEndpointConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayPrivateEndpointConnection | undefined;
    set internalValue(value: ApplicationGatewayPrivateEndpointConnection | undefined);
    get id(): string;
    get name(): string;
}
export declare class ApplicationGatewayPrivateEndpointConnectionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayPrivateEndpointConnectionOutputReference;
}
export interface ApplicationGatewayAutoscaleConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#max_capacity ApplicationGateway#max_capacity}
    */
    readonly maxCapacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#min_capacity ApplicationGateway#min_capacity}
    */
    readonly minCapacity: number;
}
export declare function applicationGatewayAutoscaleConfigurationToTerraform(struct?: ApplicationGatewayAutoscaleConfigurationOutputReference | ApplicationGatewayAutoscaleConfiguration): any;
export declare function applicationGatewayAutoscaleConfigurationToHclTerraform(struct?: ApplicationGatewayAutoscaleConfigurationOutputReference | ApplicationGatewayAutoscaleConfiguration): any;
export declare class ApplicationGatewayAutoscaleConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewayAutoscaleConfiguration | undefined;
    set internalValue(value: ApplicationGatewayAutoscaleConfiguration | undefined);
    private _maxCapacity?;
    get maxCapacity(): number;
    set maxCapacity(value: number);
    resetMaxCapacity(): void;
    get maxCapacityInput(): number | undefined;
    private _minCapacity?;
    get minCapacity(): number;
    set minCapacity(value: number);
    get minCapacityInput(): number | undefined;
}
export interface ApplicationGatewayBackend {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#client_ip_preservation_enabled ApplicationGateway#client_ip_preservation_enabled}
    */
    readonly clientIpPreservationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#host_name ApplicationGateway#host_name}
    */
    readonly hostName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#port ApplicationGateway#port}
    */
    readonly port: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#probe_name ApplicationGateway#probe_name}
    */
    readonly probeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#protocol ApplicationGateway#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#timeout_in_seconds ApplicationGateway#timeout_in_seconds}
    */
    readonly timeoutInSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#trusted_root_certificate_names ApplicationGateway#trusted_root_certificate_names}
    */
    readonly trustedRootCertificateNames?: string[];
}
export declare function applicationGatewayBackendToTerraform(struct?: ApplicationGatewayBackend | cdktn.IResolvable): any;
export declare function applicationGatewayBackendToHclTerraform(struct?: ApplicationGatewayBackend | cdktn.IResolvable): any;
export declare class ApplicationGatewayBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayBackend | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayBackend | cdktn.IResolvable | undefined);
    private _clientIpPreservationEnabled?;
    get clientIpPreservationEnabled(): boolean | cdktn.IResolvable;
    set clientIpPreservationEnabled(value: boolean | cdktn.IResolvable);
    resetClientIpPreservationEnabled(): void;
    get clientIpPreservationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _hostName?;
    get hostName(): string;
    set hostName(value: string);
    resetHostName(): void;
    get hostNameInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    get probeId(): string;
    private _probeName?;
    get probeName(): string;
    set probeName(value: string);
    resetProbeName(): void;
    get probeNameInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _timeoutInSeconds?;
    get timeoutInSeconds(): number;
    set timeoutInSeconds(value: number);
    resetTimeoutInSeconds(): void;
    get timeoutInSecondsInput(): number | undefined;
    private _trustedRootCertificateNames?;
    get trustedRootCertificateNames(): string[];
    set trustedRootCertificateNames(value: string[]);
    resetTrustedRootCertificateNames(): void;
    get trustedRootCertificateNamesInput(): string[] | undefined;
}
export declare class ApplicationGatewayBackendList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayBackend[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayBackendOutputReference;
}
export interface ApplicationGatewayBackendAddressPool {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#fqdns ApplicationGateway#fqdns}
    */
    readonly fqdns?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ip_addresses ApplicationGateway#ip_addresses}
    */
    readonly ipAddresses?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
}
export declare function applicationGatewayBackendAddressPoolToTerraform(struct?: ApplicationGatewayBackendAddressPool | cdktn.IResolvable): any;
export declare function applicationGatewayBackendAddressPoolToHclTerraform(struct?: ApplicationGatewayBackendAddressPool | cdktn.IResolvable): any;
export declare class ApplicationGatewayBackendAddressPoolOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayBackendAddressPool | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayBackendAddressPool | cdktn.IResolvable | undefined);
    private _fqdns?;
    get fqdns(): string[];
    set fqdns(value: string[]);
    resetFqdns(): void;
    get fqdnsInput(): string[] | undefined;
    get id(): string;
    private _ipAddresses?;
    get ipAddresses(): string[];
    set ipAddresses(value: string[]);
    resetIpAddresses(): void;
    get ipAddressesInput(): string[] | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ApplicationGatewayBackendAddressPoolList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayBackendAddressPool[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayBackendAddressPoolOutputReference;
}
export interface ApplicationGatewayBackendHttpSettingsConnectionDraining {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#drain_timeout_sec ApplicationGateway#drain_timeout_sec}
    */
    readonly drainTimeoutSec: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#enabled ApplicationGateway#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
}
export declare function applicationGatewayBackendHttpSettingsConnectionDrainingToTerraform(struct?: ApplicationGatewayBackendHttpSettingsConnectionDrainingOutputReference | ApplicationGatewayBackendHttpSettingsConnectionDraining): any;
export declare function applicationGatewayBackendHttpSettingsConnectionDrainingToHclTerraform(struct?: ApplicationGatewayBackendHttpSettingsConnectionDrainingOutputReference | ApplicationGatewayBackendHttpSettingsConnectionDraining): any;
export declare class ApplicationGatewayBackendHttpSettingsConnectionDrainingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewayBackendHttpSettingsConnectionDraining | undefined;
    set internalValue(value: ApplicationGatewayBackendHttpSettingsConnectionDraining | undefined);
    private _drainTimeoutSec?;
    get drainTimeoutSec(): number;
    set drainTimeoutSec(value: number);
    get drainTimeoutSecInput(): number | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApplicationGatewayBackendHttpSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#affinity_cookie_name ApplicationGateway#affinity_cookie_name}
    */
    readonly affinityCookieName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#certificate_chain_validation_enabled ApplicationGateway#certificate_chain_validation_enabled}
    */
    readonly certificateChainValidationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#cookie_based_affinity ApplicationGateway#cookie_based_affinity}
    */
    readonly cookieBasedAffinity: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#dedicated_backend_connection_enabled ApplicationGateway#dedicated_backend_connection_enabled}
    */
    readonly dedicatedBackendConnectionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#host_name ApplicationGateway#host_name}
    */
    readonly hostName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#path ApplicationGateway#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#pick_host_name_from_backend_address ApplicationGateway#pick_host_name_from_backend_address}
    */
    readonly pickHostNameFromBackendAddress?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#port ApplicationGateway#port}
    */
    readonly port: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#probe_name ApplicationGateway#probe_name}
    */
    readonly probeName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#protocol ApplicationGateway#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#request_timeout ApplicationGateway#request_timeout}
    */
    readonly requestTimeout?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#sni_name ApplicationGateway#sni_name}
    */
    readonly sniName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#sni_validation_enabled ApplicationGateway#sni_validation_enabled}
    */
    readonly sniValidationEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#trusted_root_certificate_names ApplicationGateway#trusted_root_certificate_names}
    */
    readonly trustedRootCertificateNames?: string[];
    /**
    * connection_draining block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#connection_draining ApplicationGateway#connection_draining}
    */
    readonly connectionDraining?: ApplicationGatewayBackendHttpSettingsConnectionDraining;
}
export declare function applicationGatewayBackendHttpSettingsToTerraform(struct?: ApplicationGatewayBackendHttpSettings | cdktn.IResolvable): any;
export declare function applicationGatewayBackendHttpSettingsToHclTerraform(struct?: ApplicationGatewayBackendHttpSettings | cdktn.IResolvable): any;
export declare class ApplicationGatewayBackendHttpSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayBackendHttpSettings | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayBackendHttpSettings | cdktn.IResolvable | undefined);
    private _affinityCookieName?;
    get affinityCookieName(): string;
    set affinityCookieName(value: string);
    resetAffinityCookieName(): void;
    get affinityCookieNameInput(): string | undefined;
    private _certificateChainValidationEnabled?;
    get certificateChainValidationEnabled(): boolean | cdktn.IResolvable;
    set certificateChainValidationEnabled(value: boolean | cdktn.IResolvable);
    resetCertificateChainValidationEnabled(): void;
    get certificateChainValidationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _cookieBasedAffinity?;
    get cookieBasedAffinity(): string;
    set cookieBasedAffinity(value: string);
    get cookieBasedAffinityInput(): string | undefined;
    private _dedicatedBackendConnectionEnabled?;
    get dedicatedBackendConnectionEnabled(): boolean | cdktn.IResolvable;
    set dedicatedBackendConnectionEnabled(value: boolean | cdktn.IResolvable);
    resetDedicatedBackendConnectionEnabled(): void;
    get dedicatedBackendConnectionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _hostName?;
    get hostName(): string;
    set hostName(value: string);
    resetHostName(): void;
    get hostNameInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _pickHostNameFromBackendAddress?;
    get pickHostNameFromBackendAddress(): boolean | cdktn.IResolvable;
    set pickHostNameFromBackendAddress(value: boolean | cdktn.IResolvable);
    resetPickHostNameFromBackendAddress(): void;
    get pickHostNameFromBackendAddressInput(): boolean | cdktn.IResolvable | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
    get probeId(): string;
    private _probeName?;
    get probeName(): string;
    set probeName(value: string);
    resetProbeName(): void;
    get probeNameInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _requestTimeout?;
    get requestTimeout(): number;
    set requestTimeout(value: number);
    resetRequestTimeout(): void;
    get requestTimeoutInput(): number | undefined;
    private _sniName?;
    get sniName(): string;
    set sniName(value: string);
    resetSniName(): void;
    get sniNameInput(): string | undefined;
    private _sniValidationEnabled?;
    get sniValidationEnabled(): boolean | cdktn.IResolvable;
    set sniValidationEnabled(value: boolean | cdktn.IResolvable);
    resetSniValidationEnabled(): void;
    get sniValidationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _trustedRootCertificateNames?;
    get trustedRootCertificateNames(): string[];
    set trustedRootCertificateNames(value: string[]);
    resetTrustedRootCertificateNames(): void;
    get trustedRootCertificateNamesInput(): string[] | undefined;
    private _connectionDraining;
    get connectionDraining(): ApplicationGatewayBackendHttpSettingsConnectionDrainingOutputReference;
    putConnectionDraining(value: ApplicationGatewayBackendHttpSettingsConnectionDraining): void;
    resetConnectionDraining(): void;
    get connectionDrainingInput(): ApplicationGatewayBackendHttpSettingsConnectionDraining | undefined;
}
export declare class ApplicationGatewayBackendHttpSettingsList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayBackendHttpSettings[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayBackendHttpSettingsOutputReference;
}
export interface ApplicationGatewayCustomErrorConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#custom_error_page_url ApplicationGateway#custom_error_page_url}
    */
    readonly customErrorPageUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#status_code ApplicationGateway#status_code}
    */
    readonly statusCode: string;
}
export declare function applicationGatewayCustomErrorConfigurationToTerraform(struct?: ApplicationGatewayCustomErrorConfiguration | cdktn.IResolvable): any;
export declare function applicationGatewayCustomErrorConfigurationToHclTerraform(struct?: ApplicationGatewayCustomErrorConfiguration | cdktn.IResolvable): any;
export declare class ApplicationGatewayCustomErrorConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayCustomErrorConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayCustomErrorConfiguration | cdktn.IResolvable | undefined);
    private _customErrorPageUrl?;
    get customErrorPageUrl(): string;
    set customErrorPageUrl(value: string);
    get customErrorPageUrlInput(): string | undefined;
    get id(): string;
    private _statusCode?;
    get statusCode(): string;
    set statusCode(value: string);
    get statusCodeInput(): string | undefined;
}
export declare class ApplicationGatewayCustomErrorConfigurationList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayCustomErrorConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayCustomErrorConfigurationOutputReference;
}
export interface ApplicationGatewayFrontendIpConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#private_ip_address ApplicationGateway#private_ip_address}
    */
    readonly privateIpAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#private_ip_address_allocation ApplicationGateway#private_ip_address_allocation}
    */
    readonly privateIpAddressAllocation?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#private_link_configuration_name ApplicationGateway#private_link_configuration_name}
    */
    readonly privateLinkConfigurationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#public_ip_address_id ApplicationGateway#public_ip_address_id}
    */
    readonly publicIpAddressId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#subnet_id ApplicationGateway#subnet_id}
    */
    readonly subnetId?: string;
}
export declare function applicationGatewayFrontendIpConfigurationToTerraform(struct?: ApplicationGatewayFrontendIpConfiguration | cdktn.IResolvable): any;
export declare function applicationGatewayFrontendIpConfigurationToHclTerraform(struct?: ApplicationGatewayFrontendIpConfiguration | cdktn.IResolvable): any;
export declare class ApplicationGatewayFrontendIpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayFrontendIpConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayFrontendIpConfiguration | cdktn.IResolvable | undefined);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _privateIpAddress?;
    get privateIpAddress(): string;
    set privateIpAddress(value: string);
    resetPrivateIpAddress(): void;
    get privateIpAddressInput(): string | undefined;
    private _privateIpAddressAllocation?;
    get privateIpAddressAllocation(): string;
    set privateIpAddressAllocation(value: string);
    resetPrivateIpAddressAllocation(): void;
    get privateIpAddressAllocationInput(): string | undefined;
    get privateLinkConfigurationId(): string;
    private _privateLinkConfigurationName?;
    get privateLinkConfigurationName(): string;
    set privateLinkConfigurationName(value: string);
    resetPrivateLinkConfigurationName(): void;
    get privateLinkConfigurationNameInput(): string | undefined;
    private _publicIpAddressId?;
    get publicIpAddressId(): string;
    set publicIpAddressId(value: string);
    resetPublicIpAddressId(): void;
    get publicIpAddressIdInput(): string | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    resetSubnetId(): void;
    get subnetIdInput(): string | undefined;
}
export declare class ApplicationGatewayFrontendIpConfigurationList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayFrontendIpConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayFrontendIpConfigurationOutputReference;
}
export interface ApplicationGatewayFrontendPort {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#port ApplicationGateway#port}
    */
    readonly port: number;
}
export declare function applicationGatewayFrontendPortToTerraform(struct?: ApplicationGatewayFrontendPort | cdktn.IResolvable): any;
export declare function applicationGatewayFrontendPortToHclTerraform(struct?: ApplicationGatewayFrontendPort | cdktn.IResolvable): any;
export declare class ApplicationGatewayFrontendPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayFrontendPort | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayFrontendPort | cdktn.IResolvable | undefined);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    get portInput(): number | undefined;
}
export declare class ApplicationGatewayFrontendPortList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayFrontendPort[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayFrontendPortOutputReference;
}
export interface ApplicationGatewayGatewayIpConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#subnet_id ApplicationGateway#subnet_id}
    */
    readonly subnetId: string;
}
export declare function applicationGatewayGatewayIpConfigurationToTerraform(struct?: ApplicationGatewayGatewayIpConfiguration | cdktn.IResolvable): any;
export declare function applicationGatewayGatewayIpConfigurationToHclTerraform(struct?: ApplicationGatewayGatewayIpConfiguration | cdktn.IResolvable): any;
export declare class ApplicationGatewayGatewayIpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayGatewayIpConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayGatewayIpConfiguration | cdktn.IResolvable | undefined);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
}
export declare class ApplicationGatewayGatewayIpConfigurationList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayGatewayIpConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayGatewayIpConfigurationOutputReference;
}
export interface ApplicationGatewayGlobal {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#request_buffering_enabled ApplicationGateway#request_buffering_enabled}
    */
    readonly requestBufferingEnabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#response_buffering_enabled ApplicationGateway#response_buffering_enabled}
    */
    readonly responseBufferingEnabled: boolean | cdktn.IResolvable;
}
export declare function applicationGatewayGlobalToTerraform(struct?: ApplicationGatewayGlobalOutputReference | ApplicationGatewayGlobal): any;
export declare function applicationGatewayGlobalToHclTerraform(struct?: ApplicationGatewayGlobalOutputReference | ApplicationGatewayGlobal): any;
export declare class ApplicationGatewayGlobalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewayGlobal | undefined;
    set internalValue(value: ApplicationGatewayGlobal | undefined);
    private _requestBufferingEnabled?;
    get requestBufferingEnabled(): boolean | cdktn.IResolvable;
    set requestBufferingEnabled(value: boolean | cdktn.IResolvable);
    get requestBufferingEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _responseBufferingEnabled?;
    get responseBufferingEnabled(): boolean | cdktn.IResolvable;
    set responseBufferingEnabled(value: boolean | cdktn.IResolvable);
    get responseBufferingEnabledInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApplicationGatewayHttpListenerCustomErrorConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#custom_error_page_url ApplicationGateway#custom_error_page_url}
    */
    readonly customErrorPageUrl: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#status_code ApplicationGateway#status_code}
    */
    readonly statusCode: string;
}
export declare function applicationGatewayHttpListenerCustomErrorConfigurationToTerraform(struct?: ApplicationGatewayHttpListenerCustomErrorConfiguration | cdktn.IResolvable): any;
export declare function applicationGatewayHttpListenerCustomErrorConfigurationToHclTerraform(struct?: ApplicationGatewayHttpListenerCustomErrorConfiguration | cdktn.IResolvable): any;
export declare class ApplicationGatewayHttpListenerCustomErrorConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayHttpListenerCustomErrorConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayHttpListenerCustomErrorConfiguration | cdktn.IResolvable | undefined);
    private _customErrorPageUrl?;
    get customErrorPageUrl(): string;
    set customErrorPageUrl(value: string);
    get customErrorPageUrlInput(): string | undefined;
    get id(): string;
    private _statusCode?;
    get statusCode(): string;
    set statusCode(value: string);
    get statusCodeInput(): string | undefined;
}
export declare class ApplicationGatewayHttpListenerCustomErrorConfigurationList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayHttpListenerCustomErrorConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayHttpListenerCustomErrorConfigurationOutputReference;
}
export interface ApplicationGatewayHttpListener {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#firewall_policy_id ApplicationGateway#firewall_policy_id}
    */
    readonly firewallPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#frontend_ip_configuration_name ApplicationGateway#frontend_ip_configuration_name}
    */
    readonly frontendIpConfigurationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#frontend_port_name ApplicationGateway#frontend_port_name}
    */
    readonly frontendPortName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#host_name ApplicationGateway#host_name}
    */
    readonly hostName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#host_names ApplicationGateway#host_names}
    */
    readonly hostNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#protocol ApplicationGateway#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#require_sni ApplicationGateway#require_sni}
    */
    readonly requireSni?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ssl_certificate_name ApplicationGateway#ssl_certificate_name}
    */
    readonly sslCertificateName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ssl_profile_name ApplicationGateway#ssl_profile_name}
    */
    readonly sslProfileName?: string;
    /**
    * custom_error_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#custom_error_configuration ApplicationGateway#custom_error_configuration}
    */
    readonly customErrorConfiguration?: ApplicationGatewayHttpListenerCustomErrorConfiguration[] | cdktn.IResolvable;
}
export declare function applicationGatewayHttpListenerToTerraform(struct?: ApplicationGatewayHttpListener | cdktn.IResolvable): any;
export declare function applicationGatewayHttpListenerToHclTerraform(struct?: ApplicationGatewayHttpListener | cdktn.IResolvable): any;
export declare class ApplicationGatewayHttpListenerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayHttpListener | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayHttpListener | cdktn.IResolvable | undefined);
    private _firewallPolicyId?;
    get firewallPolicyId(): string;
    set firewallPolicyId(value: string);
    resetFirewallPolicyId(): void;
    get firewallPolicyIdInput(): string | undefined;
    get frontendIpConfigurationId(): string;
    private _frontendIpConfigurationName?;
    get frontendIpConfigurationName(): string;
    set frontendIpConfigurationName(value: string);
    get frontendIpConfigurationNameInput(): string | undefined;
    get frontendPortId(): string;
    private _frontendPortName?;
    get frontendPortName(): string;
    set frontendPortName(value: string);
    get frontendPortNameInput(): string | undefined;
    private _hostName?;
    get hostName(): string;
    set hostName(value: string);
    resetHostName(): void;
    get hostNameInput(): string | undefined;
    private _hostNames?;
    get hostNames(): string[];
    set hostNames(value: string[]);
    resetHostNames(): void;
    get hostNamesInput(): string[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _requireSni?;
    get requireSni(): boolean | cdktn.IResolvable;
    set requireSni(value: boolean | cdktn.IResolvable);
    resetRequireSni(): void;
    get requireSniInput(): boolean | cdktn.IResolvable | undefined;
    get sslCertificateId(): string;
    private _sslCertificateName?;
    get sslCertificateName(): string;
    set sslCertificateName(value: string);
    resetSslCertificateName(): void;
    get sslCertificateNameInput(): string | undefined;
    get sslProfileId(): string;
    private _sslProfileName?;
    get sslProfileName(): string;
    set sslProfileName(value: string);
    resetSslProfileName(): void;
    get sslProfileNameInput(): string | undefined;
    private _customErrorConfiguration;
    get customErrorConfiguration(): ApplicationGatewayHttpListenerCustomErrorConfigurationList;
    putCustomErrorConfiguration(value: ApplicationGatewayHttpListenerCustomErrorConfiguration[] | cdktn.IResolvable): void;
    resetCustomErrorConfiguration(): void;
    get customErrorConfigurationInput(): cdktn.IResolvable | ApplicationGatewayHttpListenerCustomErrorConfiguration[] | undefined;
}
export declare class ApplicationGatewayHttpListenerList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayHttpListener[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayHttpListenerOutputReference;
}
export interface ApplicationGatewayIdentity {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#identity_ids ApplicationGateway#identity_ids}
    */
    readonly identityIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#type ApplicationGateway#type}
    */
    readonly type: string;
}
export declare function applicationGatewayIdentityToTerraform(struct?: ApplicationGatewayIdentityOutputReference | ApplicationGatewayIdentity): any;
export declare function applicationGatewayIdentityToHclTerraform(struct?: ApplicationGatewayIdentityOutputReference | ApplicationGatewayIdentity): any;
export declare class ApplicationGatewayIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewayIdentity | undefined;
    set internalValue(value: ApplicationGatewayIdentity | undefined);
    private _identityIds?;
    get identityIds(): string[];
    set identityIds(value: string[]);
    resetIdentityIds(): void;
    get identityIdsInput(): string[] | undefined;
    get principalId(): string;
    get tenantId(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
}
export interface ApplicationGatewayListener {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#frontend_ip_configuration_name ApplicationGateway#frontend_ip_configuration_name}
    */
    readonly frontendIpConfigurationName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#frontend_port_name ApplicationGateway#frontend_port_name}
    */
    readonly frontendPortName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#host_names ApplicationGateway#host_names}
    */
    readonly hostNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#protocol ApplicationGateway#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ssl_certificate_name ApplicationGateway#ssl_certificate_name}
    */
    readonly sslCertificateName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ssl_profile_name ApplicationGateway#ssl_profile_name}
    */
    readonly sslProfileName?: string;
}
export declare function applicationGatewayListenerToTerraform(struct?: ApplicationGatewayListener | cdktn.IResolvable): any;
export declare function applicationGatewayListenerToHclTerraform(struct?: ApplicationGatewayListener | cdktn.IResolvable): any;
export declare class ApplicationGatewayListenerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayListener | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayListener | cdktn.IResolvable | undefined);
    get frontendIpConfigurationId(): string;
    private _frontendIpConfigurationName?;
    get frontendIpConfigurationName(): string;
    set frontendIpConfigurationName(value: string);
    get frontendIpConfigurationNameInput(): string | undefined;
    get frontendPortId(): string;
    private _frontendPortName?;
    get frontendPortName(): string;
    set frontendPortName(value: string);
    get frontendPortNameInput(): string | undefined;
    private _hostNames?;
    get hostNames(): string[];
    set hostNames(value: string[]);
    resetHostNames(): void;
    get hostNamesInput(): string[] | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    get sslCertificateId(): string;
    private _sslCertificateName?;
    get sslCertificateName(): string;
    set sslCertificateName(value: string);
    resetSslCertificateName(): void;
    get sslCertificateNameInput(): string | undefined;
    get sslProfileId(): string;
    private _sslProfileName?;
    get sslProfileName(): string;
    set sslProfileName(value: string);
    resetSslProfileName(): void;
    get sslProfileNameInput(): string | undefined;
}
export declare class ApplicationGatewayListenerList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayListener[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayListenerOutputReference;
}
export interface ApplicationGatewayPrivateLinkConfigurationIpConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#primary ApplicationGateway#primary}
    */
    readonly primary: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#private_ip_address ApplicationGateway#private_ip_address}
    */
    readonly privateIpAddress?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#private_ip_address_allocation ApplicationGateway#private_ip_address_allocation}
    */
    readonly privateIpAddressAllocation: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#subnet_id ApplicationGateway#subnet_id}
    */
    readonly subnetId: string;
}
export declare function applicationGatewayPrivateLinkConfigurationIpConfigurationToTerraform(struct?: ApplicationGatewayPrivateLinkConfigurationIpConfiguration | cdktn.IResolvable): any;
export declare function applicationGatewayPrivateLinkConfigurationIpConfigurationToHclTerraform(struct?: ApplicationGatewayPrivateLinkConfigurationIpConfiguration | cdktn.IResolvable): any;
export declare class ApplicationGatewayPrivateLinkConfigurationIpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayPrivateLinkConfigurationIpConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayPrivateLinkConfigurationIpConfiguration | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primary?;
    get primary(): boolean | cdktn.IResolvable;
    set primary(value: boolean | cdktn.IResolvable);
    get primaryInput(): boolean | cdktn.IResolvable | undefined;
    private _privateIpAddress?;
    get privateIpAddress(): string;
    set privateIpAddress(value: string);
    resetPrivateIpAddress(): void;
    get privateIpAddressInput(): string | undefined;
    private _privateIpAddressAllocation?;
    get privateIpAddressAllocation(): string;
    set privateIpAddressAllocation(value: string);
    get privateIpAddressAllocationInput(): string | undefined;
    private _subnetId?;
    get subnetId(): string;
    set subnetId(value: string);
    get subnetIdInput(): string | undefined;
}
export declare class ApplicationGatewayPrivateLinkConfigurationIpConfigurationList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayPrivateLinkConfigurationIpConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayPrivateLinkConfigurationIpConfigurationOutputReference;
}
export interface ApplicationGatewayPrivateLinkConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * ip_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ip_configuration ApplicationGateway#ip_configuration}
    */
    readonly ipConfiguration: ApplicationGatewayPrivateLinkConfigurationIpConfiguration[] | cdktn.IResolvable;
}
export declare function applicationGatewayPrivateLinkConfigurationToTerraform(struct?: ApplicationGatewayPrivateLinkConfiguration | cdktn.IResolvable): any;
export declare function applicationGatewayPrivateLinkConfigurationToHclTerraform(struct?: ApplicationGatewayPrivateLinkConfiguration | cdktn.IResolvable): any;
export declare class ApplicationGatewayPrivateLinkConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayPrivateLinkConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayPrivateLinkConfiguration | cdktn.IResolvable | undefined);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ipConfiguration;
    get ipConfiguration(): ApplicationGatewayPrivateLinkConfigurationIpConfigurationList;
    putIpConfiguration(value: ApplicationGatewayPrivateLinkConfigurationIpConfiguration[] | cdktn.IResolvable): void;
    get ipConfigurationInput(): cdktn.IResolvable | ApplicationGatewayPrivateLinkConfigurationIpConfiguration[] | undefined;
}
export declare class ApplicationGatewayPrivateLinkConfigurationList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayPrivateLinkConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayPrivateLinkConfigurationOutputReference;
}
export interface ApplicationGatewayProbeMatch {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#body ApplicationGateway#body}
    */
    readonly body?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#status_code ApplicationGateway#status_code}
    */
    readonly statusCode: string[];
}
export declare function applicationGatewayProbeMatchToTerraform(struct?: ApplicationGatewayProbeMatchOutputReference | ApplicationGatewayProbeMatch): any;
export declare function applicationGatewayProbeMatchToHclTerraform(struct?: ApplicationGatewayProbeMatchOutputReference | ApplicationGatewayProbeMatch): any;
export declare class ApplicationGatewayProbeMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewayProbeMatch | undefined;
    set internalValue(value: ApplicationGatewayProbeMatch | undefined);
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _statusCode?;
    get statusCode(): string[];
    set statusCode(value: string[]);
    get statusCodeInput(): string[] | undefined;
}
export interface ApplicationGatewayProbe {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#host ApplicationGateway#host}
    */
    readonly host?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#interval ApplicationGateway#interval}
    */
    readonly interval: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#minimum_servers ApplicationGateway#minimum_servers}
    */
    readonly minimumServers?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#path ApplicationGateway#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#pick_host_name_from_backend_http_settings ApplicationGateway#pick_host_name_from_backend_http_settings}
    */
    readonly pickHostNameFromBackendHttpSettings?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#port ApplicationGateway#port}
    */
    readonly port?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#protocol ApplicationGateway#protocol}
    */
    readonly protocol: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#proxy_protocol_header_enabled ApplicationGateway#proxy_protocol_header_enabled}
    */
    readonly proxyProtocolHeaderEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#timeout ApplicationGateway#timeout}
    */
    readonly timeout: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#unhealthy_threshold ApplicationGateway#unhealthy_threshold}
    */
    readonly unhealthyThreshold: number;
    /**
    * match block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#match ApplicationGateway#match}
    */
    readonly match?: ApplicationGatewayProbeMatch;
}
export declare function applicationGatewayProbeToTerraform(struct?: ApplicationGatewayProbe | cdktn.IResolvable): any;
export declare function applicationGatewayProbeToHclTerraform(struct?: ApplicationGatewayProbe | cdktn.IResolvable): any;
export declare class ApplicationGatewayProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayProbe | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayProbe | cdktn.IResolvable | undefined);
    private _host?;
    get host(): string;
    set host(value: string);
    resetHost(): void;
    get hostInput(): string | undefined;
    get id(): string;
    private _interval?;
    get interval(): number;
    set interval(value: number);
    get intervalInput(): number | undefined;
    private _minimumServers?;
    get minimumServers(): number;
    set minimumServers(value: number);
    resetMinimumServers(): void;
    get minimumServersInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _pickHostNameFromBackendHttpSettings?;
    get pickHostNameFromBackendHttpSettings(): boolean | cdktn.IResolvable;
    set pickHostNameFromBackendHttpSettings(value: boolean | cdktn.IResolvable);
    resetPickHostNameFromBackendHttpSettings(): void;
    get pickHostNameFromBackendHttpSettingsInput(): boolean | cdktn.IResolvable | undefined;
    private _port?;
    get port(): number;
    set port(value: number);
    resetPort(): void;
    get portInput(): number | undefined;
    private _protocol?;
    get protocol(): string;
    set protocol(value: string);
    get protocolInput(): string | undefined;
    private _proxyProtocolHeaderEnabled?;
    get proxyProtocolHeaderEnabled(): boolean | cdktn.IResolvable;
    set proxyProtocolHeaderEnabled(value: boolean | cdktn.IResolvable);
    resetProxyProtocolHeaderEnabled(): void;
    get proxyProtocolHeaderEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _timeout?;
    get timeout(): number;
    set timeout(value: number);
    get timeoutInput(): number | undefined;
    private _unhealthyThreshold?;
    get unhealthyThreshold(): number;
    set unhealthyThreshold(value: number);
    get unhealthyThresholdInput(): number | undefined;
    private _match;
    get match(): ApplicationGatewayProbeMatchOutputReference;
    putMatch(value: ApplicationGatewayProbeMatch): void;
    resetMatch(): void;
    get matchInput(): ApplicationGatewayProbeMatch | undefined;
}
export declare class ApplicationGatewayProbeList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayProbe[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayProbeOutputReference;
}
export interface ApplicationGatewayRedirectConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#include_path ApplicationGateway#include_path}
    */
    readonly includePath?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#include_query_string ApplicationGateway#include_query_string}
    */
    readonly includeQueryString?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#redirect_type ApplicationGateway#redirect_type}
    */
    readonly redirectType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#target_listener_name ApplicationGateway#target_listener_name}
    */
    readonly targetListenerName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#target_url ApplicationGateway#target_url}
    */
    readonly targetUrl?: string;
}
export declare function applicationGatewayRedirectConfigurationToTerraform(struct?: ApplicationGatewayRedirectConfiguration | cdktn.IResolvable): any;
export declare function applicationGatewayRedirectConfigurationToHclTerraform(struct?: ApplicationGatewayRedirectConfiguration | cdktn.IResolvable): any;
export declare class ApplicationGatewayRedirectConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayRedirectConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayRedirectConfiguration | cdktn.IResolvable | undefined);
    get id(): string;
    private _includePath?;
    get includePath(): boolean | cdktn.IResolvable;
    set includePath(value: boolean | cdktn.IResolvable);
    resetIncludePath(): void;
    get includePathInput(): boolean | cdktn.IResolvable | undefined;
    private _includeQueryString?;
    get includeQueryString(): boolean | cdktn.IResolvable;
    set includeQueryString(value: boolean | cdktn.IResolvable);
    resetIncludeQueryString(): void;
    get includeQueryStringInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _redirectType?;
    get redirectType(): string;
    set redirectType(value: string);
    get redirectTypeInput(): string | undefined;
    get targetListenerId(): string;
    private _targetListenerName?;
    get targetListenerName(): string;
    set targetListenerName(value: string);
    resetTargetListenerName(): void;
    get targetListenerNameInput(): string | undefined;
    private _targetUrl?;
    get targetUrl(): string;
    set targetUrl(value: string);
    resetTargetUrl(): void;
    get targetUrlInput(): string | undefined;
}
export declare class ApplicationGatewayRedirectConfigurationList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayRedirectConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayRedirectConfigurationOutputReference;
}
export interface ApplicationGatewayRequestRoutingRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#backend_address_pool_name ApplicationGateway#backend_address_pool_name}
    */
    readonly backendAddressPoolName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#backend_http_settings_name ApplicationGateway#backend_http_settings_name}
    */
    readonly backendHttpSettingsName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#http_listener_name ApplicationGateway#http_listener_name}
    */
    readonly httpListenerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#priority ApplicationGateway#priority}
    */
    readonly priority?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#redirect_configuration_name ApplicationGateway#redirect_configuration_name}
    */
    readonly redirectConfigurationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#rewrite_rule_set_name ApplicationGateway#rewrite_rule_set_name}
    */
    readonly rewriteRuleSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#rule_type ApplicationGateway#rule_type}
    */
    readonly ruleType: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#url_path_map_name ApplicationGateway#url_path_map_name}
    */
    readonly urlPathMapName?: string;
}
export declare function applicationGatewayRequestRoutingRuleToTerraform(struct?: ApplicationGatewayRequestRoutingRule | cdktn.IResolvable): any;
export declare function applicationGatewayRequestRoutingRuleToHclTerraform(struct?: ApplicationGatewayRequestRoutingRule | cdktn.IResolvable): any;
export declare class ApplicationGatewayRequestRoutingRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayRequestRoutingRule | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayRequestRoutingRule | cdktn.IResolvable | undefined);
    get backendAddressPoolId(): string;
    private _backendAddressPoolName?;
    get backendAddressPoolName(): string;
    set backendAddressPoolName(value: string);
    resetBackendAddressPoolName(): void;
    get backendAddressPoolNameInput(): string | undefined;
    get backendHttpSettingsId(): string;
    private _backendHttpSettingsName?;
    get backendHttpSettingsName(): string;
    set backendHttpSettingsName(value: string);
    resetBackendHttpSettingsName(): void;
    get backendHttpSettingsNameInput(): string | undefined;
    get httpListenerId(): string;
    private _httpListenerName?;
    get httpListenerName(): string;
    set httpListenerName(value: string);
    get httpListenerNameInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    resetPriority(): void;
    get priorityInput(): number | undefined;
    get redirectConfigurationId(): string;
    private _redirectConfigurationName?;
    get redirectConfigurationName(): string;
    set redirectConfigurationName(value: string);
    resetRedirectConfigurationName(): void;
    get redirectConfigurationNameInput(): string | undefined;
    get rewriteRuleSetId(): string;
    private _rewriteRuleSetName?;
    get rewriteRuleSetName(): string;
    set rewriteRuleSetName(value: string);
    resetRewriteRuleSetName(): void;
    get rewriteRuleSetNameInput(): string | undefined;
    private _ruleType?;
    get ruleType(): string;
    set ruleType(value: string);
    get ruleTypeInput(): string | undefined;
    get urlPathMapId(): string;
    private _urlPathMapName?;
    get urlPathMapName(): string;
    set urlPathMapName(value: string);
    resetUrlPathMapName(): void;
    get urlPathMapNameInput(): string | undefined;
}
export declare class ApplicationGatewayRequestRoutingRuleList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayRequestRoutingRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayRequestRoutingRuleOutputReference;
}
export interface ApplicationGatewayRewriteRuleSetRewriteRuleCondition {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ignore_case ApplicationGateway#ignore_case}
    */
    readonly ignoreCase?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#negate ApplicationGateway#negate}
    */
    readonly negate?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#pattern ApplicationGateway#pattern}
    */
    readonly pattern: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#variable ApplicationGateway#variable}
    */
    readonly variable: string;
}
export declare function applicationGatewayRewriteRuleSetRewriteRuleConditionToTerraform(struct?: ApplicationGatewayRewriteRuleSetRewriteRuleCondition | cdktn.IResolvable): any;
export declare function applicationGatewayRewriteRuleSetRewriteRuleConditionToHclTerraform(struct?: ApplicationGatewayRewriteRuleSetRewriteRuleCondition | cdktn.IResolvable): any;
export declare class ApplicationGatewayRewriteRuleSetRewriteRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayRewriteRuleSetRewriteRuleCondition | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayRewriteRuleSetRewriteRuleCondition | cdktn.IResolvable | undefined);
    private _ignoreCase?;
    get ignoreCase(): boolean | cdktn.IResolvable;
    set ignoreCase(value: boolean | cdktn.IResolvable);
    resetIgnoreCase(): void;
    get ignoreCaseInput(): boolean | cdktn.IResolvable | undefined;
    private _negate?;
    get negate(): boolean | cdktn.IResolvable;
    set negate(value: boolean | cdktn.IResolvable);
    resetNegate(): void;
    get negateInput(): boolean | cdktn.IResolvable | undefined;
    private _pattern?;
    get pattern(): string;
    set pattern(value: string);
    get patternInput(): string | undefined;
    private _variable?;
    get variable(): string;
    set variable(value: string);
    get variableInput(): string | undefined;
}
export declare class ApplicationGatewayRewriteRuleSetRewriteRuleConditionList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayRewriteRuleSetRewriteRuleCondition[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayRewriteRuleSetRewriteRuleConditionOutputReference;
}
export interface ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#header_name ApplicationGateway#header_name}
    */
    readonly headerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#header_value ApplicationGateway#header_value}
    */
    readonly headerValue: string;
}
export declare function applicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfigurationToTerraform(struct?: ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfiguration | cdktn.IResolvable): any;
export declare function applicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfigurationToHclTerraform(struct?: ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfiguration | cdktn.IResolvable): any;
export declare class ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfiguration | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    get headerValueInput(): string | undefined;
}
export declare class ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfigurationList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfigurationOutputReference;
}
export interface ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#header_name ApplicationGateway#header_name}
    */
    readonly headerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#header_value ApplicationGateway#header_value}
    */
    readonly headerValue: string;
}
export declare function applicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfigurationToTerraform(struct?: ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfiguration | cdktn.IResolvable): any;
export declare function applicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfigurationToHclTerraform(struct?: ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfiguration | cdktn.IResolvable): any;
export declare class ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfiguration | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfiguration | cdktn.IResolvable | undefined);
    private _headerName?;
    get headerName(): string;
    set headerName(value: string);
    get headerNameInput(): string | undefined;
    private _headerValue?;
    get headerValue(): string;
    set headerValue(value: string);
    get headerValueInput(): string | undefined;
}
export declare class ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfigurationList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfiguration[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfigurationOutputReference;
}
export interface ApplicationGatewayRewriteRuleSetRewriteRuleUrl {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#components ApplicationGateway#components}
    */
    readonly components?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#path ApplicationGateway#path}
    */
    readonly path?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#query_string ApplicationGateway#query_string}
    */
    readonly queryString?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#reroute ApplicationGateway#reroute}
    */
    readonly reroute?: boolean | cdktn.IResolvable;
}
export declare function applicationGatewayRewriteRuleSetRewriteRuleUrlToTerraform(struct?: ApplicationGatewayRewriteRuleSetRewriteRuleUrlOutputReference | ApplicationGatewayRewriteRuleSetRewriteRuleUrl): any;
export declare function applicationGatewayRewriteRuleSetRewriteRuleUrlToHclTerraform(struct?: ApplicationGatewayRewriteRuleSetRewriteRuleUrlOutputReference | ApplicationGatewayRewriteRuleSetRewriteRuleUrl): any;
export declare class ApplicationGatewayRewriteRuleSetRewriteRuleUrlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewayRewriteRuleSetRewriteRuleUrl | undefined;
    set internalValue(value: ApplicationGatewayRewriteRuleSetRewriteRuleUrl | undefined);
    private _components?;
    get components(): string;
    set components(value: string);
    resetComponents(): void;
    get componentsInput(): string | undefined;
    private _path?;
    get path(): string;
    set path(value: string);
    resetPath(): void;
    get pathInput(): string | undefined;
    private _queryString?;
    get queryString(): string;
    set queryString(value: string);
    resetQueryString(): void;
    get queryStringInput(): string | undefined;
    private _reroute?;
    get reroute(): boolean | cdktn.IResolvable;
    set reroute(value: boolean | cdktn.IResolvable);
    resetReroute(): void;
    get rerouteInput(): boolean | cdktn.IResolvable | undefined;
}
export interface ApplicationGatewayRewriteRuleSetRewriteRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#rule_sequence ApplicationGateway#rule_sequence}
    */
    readonly ruleSequence: number;
    /**
    * condition block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#condition ApplicationGateway#condition}
    */
    readonly condition?: ApplicationGatewayRewriteRuleSetRewriteRuleCondition[] | cdktn.IResolvable;
    /**
    * request_header_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#request_header_configuration ApplicationGateway#request_header_configuration}
    */
    readonly requestHeaderConfiguration?: ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfiguration[] | cdktn.IResolvable;
    /**
    * response_header_configuration block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#response_header_configuration ApplicationGateway#response_header_configuration}
    */
    readonly responseHeaderConfiguration?: ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfiguration[] | cdktn.IResolvable;
    /**
    * url block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#url ApplicationGateway#url}
    */
    readonly url?: ApplicationGatewayRewriteRuleSetRewriteRuleUrl;
}
export declare function applicationGatewayRewriteRuleSetRewriteRuleToTerraform(struct?: ApplicationGatewayRewriteRuleSetRewriteRule | cdktn.IResolvable): any;
export declare function applicationGatewayRewriteRuleSetRewriteRuleToHclTerraform(struct?: ApplicationGatewayRewriteRuleSetRewriteRule | cdktn.IResolvable): any;
export declare class ApplicationGatewayRewriteRuleSetRewriteRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayRewriteRuleSetRewriteRule | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayRewriteRuleSetRewriteRule | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _ruleSequence?;
    get ruleSequence(): number;
    set ruleSequence(value: number);
    get ruleSequenceInput(): number | undefined;
    private _condition;
    get condition(): ApplicationGatewayRewriteRuleSetRewriteRuleConditionList;
    putCondition(value: ApplicationGatewayRewriteRuleSetRewriteRuleCondition[] | cdktn.IResolvable): void;
    resetCondition(): void;
    get conditionInput(): cdktn.IResolvable | ApplicationGatewayRewriteRuleSetRewriteRuleCondition[] | undefined;
    private _requestHeaderConfiguration;
    get requestHeaderConfiguration(): ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfigurationList;
    putRequestHeaderConfiguration(value: ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfiguration[] | cdktn.IResolvable): void;
    resetRequestHeaderConfiguration(): void;
    get requestHeaderConfigurationInput(): cdktn.IResolvable | ApplicationGatewayRewriteRuleSetRewriteRuleRequestHeaderConfiguration[] | undefined;
    private _responseHeaderConfiguration;
    get responseHeaderConfiguration(): ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfigurationList;
    putResponseHeaderConfiguration(value: ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfiguration[] | cdktn.IResolvable): void;
    resetResponseHeaderConfiguration(): void;
    get responseHeaderConfigurationInput(): cdktn.IResolvable | ApplicationGatewayRewriteRuleSetRewriteRuleResponseHeaderConfiguration[] | undefined;
    private _url;
    get url(): ApplicationGatewayRewriteRuleSetRewriteRuleUrlOutputReference;
    putUrl(value: ApplicationGatewayRewriteRuleSetRewriteRuleUrl): void;
    resetUrl(): void;
    get urlInput(): ApplicationGatewayRewriteRuleSetRewriteRuleUrl | undefined;
}
export declare class ApplicationGatewayRewriteRuleSetRewriteRuleList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayRewriteRuleSetRewriteRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayRewriteRuleSetRewriteRuleOutputReference;
}
export interface ApplicationGatewayRewriteRuleSet {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * rewrite_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#rewrite_rule ApplicationGateway#rewrite_rule}
    */
    readonly rewriteRule?: ApplicationGatewayRewriteRuleSetRewriteRule[] | cdktn.IResolvable;
}
export declare function applicationGatewayRewriteRuleSetToTerraform(struct?: ApplicationGatewayRewriteRuleSet | cdktn.IResolvable): any;
export declare function applicationGatewayRewriteRuleSetToHclTerraform(struct?: ApplicationGatewayRewriteRuleSet | cdktn.IResolvable): any;
export declare class ApplicationGatewayRewriteRuleSetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayRewriteRuleSet | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayRewriteRuleSet | cdktn.IResolvable | undefined);
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _rewriteRule;
    get rewriteRule(): ApplicationGatewayRewriteRuleSetRewriteRuleList;
    putRewriteRule(value: ApplicationGatewayRewriteRuleSetRewriteRule[] | cdktn.IResolvable): void;
    resetRewriteRule(): void;
    get rewriteRuleInput(): cdktn.IResolvable | ApplicationGatewayRewriteRuleSetRewriteRule[] | undefined;
}
export declare class ApplicationGatewayRewriteRuleSetList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayRewriteRuleSet[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayRewriteRuleSetOutputReference;
}
export interface ApplicationGatewayRoutingRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#backend_address_pool_name ApplicationGateway#backend_address_pool_name}
    */
    readonly backendAddressPoolName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#backend_name ApplicationGateway#backend_name}
    */
    readonly backendName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#listener_name ApplicationGateway#listener_name}
    */
    readonly listenerName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#priority ApplicationGateway#priority}
    */
    readonly priority: number;
}
export declare function applicationGatewayRoutingRuleToTerraform(struct?: ApplicationGatewayRoutingRule | cdktn.IResolvable): any;
export declare function applicationGatewayRoutingRuleToHclTerraform(struct?: ApplicationGatewayRoutingRule | cdktn.IResolvable): any;
export declare class ApplicationGatewayRoutingRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayRoutingRule | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayRoutingRule | cdktn.IResolvable | undefined);
    get backendAddressPoolId(): string;
    private _backendAddressPoolName?;
    get backendAddressPoolName(): string;
    set backendAddressPoolName(value: string);
    get backendAddressPoolNameInput(): string | undefined;
    get backendId(): string;
    private _backendName?;
    get backendName(): string;
    set backendName(value: string);
    get backendNameInput(): string | undefined;
    get id(): string;
    get listenerId(): string;
    private _listenerName?;
    get listenerName(): string;
    set listenerName(value: string);
    get listenerNameInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _priority?;
    get priority(): number;
    set priority(value: number);
    get priorityInput(): number | undefined;
}
export declare class ApplicationGatewayRoutingRuleList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayRoutingRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayRoutingRuleOutputReference;
}
export interface ApplicationGatewaySku {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#capacity ApplicationGateway#capacity}
    */
    readonly capacity?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#tier ApplicationGateway#tier}
    */
    readonly tier: string;
}
export declare function applicationGatewaySkuToTerraform(struct?: ApplicationGatewaySkuOutputReference | ApplicationGatewaySku): any;
export declare function applicationGatewaySkuToHclTerraform(struct?: ApplicationGatewaySkuOutputReference | ApplicationGatewaySku): any;
export declare class ApplicationGatewaySkuOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewaySku | undefined;
    set internalValue(value: ApplicationGatewaySku | undefined);
    private _capacity?;
    get capacity(): number;
    set capacity(value: number);
    resetCapacity(): void;
    get capacityInput(): number | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    get tierInput(): string | undefined;
}
export interface ApplicationGatewaySslCertificate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#data ApplicationGateway#data}
    */
    readonly data?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#key_vault_secret_id ApplicationGateway#key_vault_secret_id}
    */
    readonly keyVaultSecretId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#password ApplicationGateway#password}
    */
    readonly password?: string;
}
export declare function applicationGatewaySslCertificateToTerraform(struct?: ApplicationGatewaySslCertificate | cdktn.IResolvable): any;
export declare function applicationGatewaySslCertificateToHclTerraform(struct?: ApplicationGatewaySslCertificate | cdktn.IResolvable): any;
export declare class ApplicationGatewaySslCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewaySslCertificate | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewaySslCertificate | cdktn.IResolvable | undefined);
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    get id(): string;
    private _keyVaultSecretId?;
    get keyVaultSecretId(): string;
    set keyVaultSecretId(value: string);
    resetKeyVaultSecretId(): void;
    get keyVaultSecretIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _password?;
    get password(): string;
    set password(value: string);
    resetPassword(): void;
    get passwordInput(): string | undefined;
    get publicCertData(): string;
}
export declare class ApplicationGatewaySslCertificateList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewaySslCertificate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewaySslCertificateOutputReference;
}
export interface ApplicationGatewaySslPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#cipher_suites ApplicationGateway#cipher_suites}
    */
    readonly cipherSuites?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#disabled_protocols ApplicationGateway#disabled_protocols}
    */
    readonly disabledProtocols?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#min_protocol_version ApplicationGateway#min_protocol_version}
    */
    readonly minProtocolVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#policy_name ApplicationGateway#policy_name}
    */
    readonly policyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#policy_type ApplicationGateway#policy_type}
    */
    readonly policyType?: string;
}
export declare function applicationGatewaySslPolicyToTerraform(struct?: ApplicationGatewaySslPolicyOutputReference | ApplicationGatewaySslPolicy): any;
export declare function applicationGatewaySslPolicyToHclTerraform(struct?: ApplicationGatewaySslPolicyOutputReference | ApplicationGatewaySslPolicy): any;
export declare class ApplicationGatewaySslPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewaySslPolicy | undefined;
    set internalValue(value: ApplicationGatewaySslPolicy | undefined);
    private _cipherSuites?;
    get cipherSuites(): string[];
    set cipherSuites(value: string[]);
    resetCipherSuites(): void;
    get cipherSuitesInput(): string[] | undefined;
    private _disabledProtocols?;
    get disabledProtocols(): string[];
    set disabledProtocols(value: string[]);
    resetDisabledProtocols(): void;
    get disabledProtocolsInput(): string[] | undefined;
    private _minProtocolVersion?;
    get minProtocolVersion(): string;
    set minProtocolVersion(value: string);
    resetMinProtocolVersion(): void;
    get minProtocolVersionInput(): string | undefined;
    private _policyName?;
    get policyName(): string;
    set policyName(value: string);
    resetPolicyName(): void;
    get policyNameInput(): string | undefined;
    private _policyType?;
    get policyType(): string;
    set policyType(value: string);
    resetPolicyType(): void;
    get policyTypeInput(): string | undefined;
}
export interface ApplicationGatewaySslProfileSslPolicy {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#cipher_suites ApplicationGateway#cipher_suites}
    */
    readonly cipherSuites?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#disabled_protocols ApplicationGateway#disabled_protocols}
    */
    readonly disabledProtocols?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#min_protocol_version ApplicationGateway#min_protocol_version}
    */
    readonly minProtocolVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#policy_name ApplicationGateway#policy_name}
    */
    readonly policyName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#policy_type ApplicationGateway#policy_type}
    */
    readonly policyType?: string;
}
export declare function applicationGatewaySslProfileSslPolicyToTerraform(struct?: ApplicationGatewaySslProfileSslPolicyOutputReference | ApplicationGatewaySslProfileSslPolicy): any;
export declare function applicationGatewaySslProfileSslPolicyToHclTerraform(struct?: ApplicationGatewaySslProfileSslPolicyOutputReference | ApplicationGatewaySslProfileSslPolicy): any;
export declare class ApplicationGatewaySslProfileSslPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewaySslProfileSslPolicy | undefined;
    set internalValue(value: ApplicationGatewaySslProfileSslPolicy | undefined);
    private _cipherSuites?;
    get cipherSuites(): string[];
    set cipherSuites(value: string[]);
    resetCipherSuites(): void;
    get cipherSuitesInput(): string[] | undefined;
    private _disabledProtocols?;
    get disabledProtocols(): string[];
    set disabledProtocols(value: string[]);
    resetDisabledProtocols(): void;
    get disabledProtocolsInput(): string[] | undefined;
    private _minProtocolVersion?;
    get minProtocolVersion(): string;
    set minProtocolVersion(value: string);
    resetMinProtocolVersion(): void;
    get minProtocolVersionInput(): string | undefined;
    private _policyName?;
    get policyName(): string;
    set policyName(value: string);
    resetPolicyName(): void;
    get policyNameInput(): string | undefined;
    private _policyType?;
    get policyType(): string;
    set policyType(value: string);
    resetPolicyType(): void;
    get policyTypeInput(): string | undefined;
}
export interface ApplicationGatewaySslProfile {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#client_authentication_mode ApplicationGateway#client_authentication_mode}
    */
    readonly clientAuthenticationMode?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#trusted_client_certificate_names ApplicationGateway#trusted_client_certificate_names}
    */
    readonly trustedClientCertificateNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#verify_client_certificate_issuer_dn ApplicationGateway#verify_client_certificate_issuer_dn}
    */
    readonly verifyClientCertificateIssuerDn?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#verify_client_certificate_revocation ApplicationGateway#verify_client_certificate_revocation}
    */
    readonly verifyClientCertificateRevocation?: string;
    /**
    * ssl_policy block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#ssl_policy ApplicationGateway#ssl_policy}
    */
    readonly sslPolicy?: ApplicationGatewaySslProfileSslPolicy;
}
export declare function applicationGatewaySslProfileToTerraform(struct?: ApplicationGatewaySslProfile | cdktn.IResolvable): any;
export declare function applicationGatewaySslProfileToHclTerraform(struct?: ApplicationGatewaySslProfile | cdktn.IResolvable): any;
export declare class ApplicationGatewaySslProfileOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewaySslProfile | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewaySslProfile | cdktn.IResolvable | undefined);
    private _clientAuthenticationMode?;
    get clientAuthenticationMode(): string;
    set clientAuthenticationMode(value: string);
    resetClientAuthenticationMode(): void;
    get clientAuthenticationModeInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _trustedClientCertificateNames?;
    get trustedClientCertificateNames(): string[];
    set trustedClientCertificateNames(value: string[]);
    resetTrustedClientCertificateNames(): void;
    get trustedClientCertificateNamesInput(): string[] | undefined;
    private _verifyClientCertificateIssuerDn?;
    get verifyClientCertificateIssuerDn(): boolean | cdktn.IResolvable;
    set verifyClientCertificateIssuerDn(value: boolean | cdktn.IResolvable);
    resetVerifyClientCertificateIssuerDn(): void;
    get verifyClientCertificateIssuerDnInput(): boolean | cdktn.IResolvable | undefined;
    private _verifyClientCertificateRevocation?;
    get verifyClientCertificateRevocation(): string;
    set verifyClientCertificateRevocation(value: string);
    resetVerifyClientCertificateRevocation(): void;
    get verifyClientCertificateRevocationInput(): string | undefined;
    private _sslPolicy;
    get sslPolicy(): ApplicationGatewaySslProfileSslPolicyOutputReference;
    putSslPolicy(value: ApplicationGatewaySslProfileSslPolicy): void;
    resetSslPolicy(): void;
    get sslPolicyInput(): ApplicationGatewaySslProfileSslPolicy | undefined;
}
export declare class ApplicationGatewaySslProfileList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewaySslProfile[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewaySslProfileOutputReference;
}
export interface ApplicationGatewayTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#create ApplicationGateway#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#delete ApplicationGateway#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#read ApplicationGateway#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#update ApplicationGateway#update}
    */
    readonly update?: string;
}
export declare function applicationGatewayTimeoutsToTerraform(struct?: ApplicationGatewayTimeouts | cdktn.IResolvable): any;
export declare function applicationGatewayTimeoutsToHclTerraform(struct?: ApplicationGatewayTimeouts | cdktn.IResolvable): any;
export declare class ApplicationGatewayTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewayTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface ApplicationGatewayTrustedClientCertificate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#data ApplicationGateway#data}
    */
    readonly data: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
}
export declare function applicationGatewayTrustedClientCertificateToTerraform(struct?: ApplicationGatewayTrustedClientCertificate | cdktn.IResolvable): any;
export declare function applicationGatewayTrustedClientCertificateToHclTerraform(struct?: ApplicationGatewayTrustedClientCertificate | cdktn.IResolvable): any;
export declare class ApplicationGatewayTrustedClientCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayTrustedClientCertificate | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayTrustedClientCertificate | cdktn.IResolvable | undefined);
    private _data?;
    get data(): string;
    set data(value: string);
    get dataInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ApplicationGatewayTrustedClientCertificateList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayTrustedClientCertificate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayTrustedClientCertificateOutputReference;
}
export interface ApplicationGatewayTrustedRootCertificate {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#data ApplicationGateway#data}
    */
    readonly data?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#key_vault_secret_id ApplicationGateway#key_vault_secret_id}
    */
    readonly keyVaultSecretId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
}
export declare function applicationGatewayTrustedRootCertificateToTerraform(struct?: ApplicationGatewayTrustedRootCertificate | cdktn.IResolvable): any;
export declare function applicationGatewayTrustedRootCertificateToHclTerraform(struct?: ApplicationGatewayTrustedRootCertificate | cdktn.IResolvable): any;
export declare class ApplicationGatewayTrustedRootCertificateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayTrustedRootCertificate | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayTrustedRootCertificate | cdktn.IResolvable | undefined);
    private _data?;
    get data(): string;
    set data(value: string);
    resetData(): void;
    get dataInput(): string | undefined;
    get id(): string;
    private _keyVaultSecretId?;
    get keyVaultSecretId(): string;
    set keyVaultSecretId(value: string);
    resetKeyVaultSecretId(): void;
    get keyVaultSecretIdInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class ApplicationGatewayTrustedRootCertificateList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayTrustedRootCertificate[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayTrustedRootCertificateOutputReference;
}
export interface ApplicationGatewayUrlPathMapPathRule {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#backend_address_pool_name ApplicationGateway#backend_address_pool_name}
    */
    readonly backendAddressPoolName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#backend_http_settings_name ApplicationGateway#backend_http_settings_name}
    */
    readonly backendHttpSettingsName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#firewall_policy_id ApplicationGateway#firewall_policy_id}
    */
    readonly firewallPolicyId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#paths ApplicationGateway#paths}
    */
    readonly paths: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#redirect_configuration_name ApplicationGateway#redirect_configuration_name}
    */
    readonly redirectConfigurationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#rewrite_rule_set_name ApplicationGateway#rewrite_rule_set_name}
    */
    readonly rewriteRuleSetName?: string;
}
export declare function applicationGatewayUrlPathMapPathRuleToTerraform(struct?: ApplicationGatewayUrlPathMapPathRule | cdktn.IResolvable): any;
export declare function applicationGatewayUrlPathMapPathRuleToHclTerraform(struct?: ApplicationGatewayUrlPathMapPathRule | cdktn.IResolvable): any;
export declare class ApplicationGatewayUrlPathMapPathRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayUrlPathMapPathRule | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayUrlPathMapPathRule | cdktn.IResolvable | undefined);
    get backendAddressPoolId(): string;
    private _backendAddressPoolName?;
    get backendAddressPoolName(): string;
    set backendAddressPoolName(value: string);
    resetBackendAddressPoolName(): void;
    get backendAddressPoolNameInput(): string | undefined;
    get backendHttpSettingsId(): string;
    private _backendHttpSettingsName?;
    get backendHttpSettingsName(): string;
    set backendHttpSettingsName(value: string);
    resetBackendHttpSettingsName(): void;
    get backendHttpSettingsNameInput(): string | undefined;
    private _firewallPolicyId?;
    get firewallPolicyId(): string;
    set firewallPolicyId(value: string);
    resetFirewallPolicyId(): void;
    get firewallPolicyIdInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _paths?;
    get paths(): string[];
    set paths(value: string[]);
    get pathsInput(): string[] | undefined;
    get redirectConfigurationId(): string;
    private _redirectConfigurationName?;
    get redirectConfigurationName(): string;
    set redirectConfigurationName(value: string);
    resetRedirectConfigurationName(): void;
    get redirectConfigurationNameInput(): string | undefined;
    get rewriteRuleSetId(): string;
    private _rewriteRuleSetName?;
    get rewriteRuleSetName(): string;
    set rewriteRuleSetName(value: string);
    resetRewriteRuleSetName(): void;
    get rewriteRuleSetNameInput(): string | undefined;
}
export declare class ApplicationGatewayUrlPathMapPathRuleList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayUrlPathMapPathRule[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayUrlPathMapPathRuleOutputReference;
}
export interface ApplicationGatewayUrlPathMap {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#default_backend_address_pool_name ApplicationGateway#default_backend_address_pool_name}
    */
    readonly defaultBackendAddressPoolName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#default_backend_http_settings_name ApplicationGateway#default_backend_http_settings_name}
    */
    readonly defaultBackendHttpSettingsName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#default_redirect_configuration_name ApplicationGateway#default_redirect_configuration_name}
    */
    readonly defaultRedirectConfigurationName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#default_rewrite_rule_set_name ApplicationGateway#default_rewrite_rule_set_name}
    */
    readonly defaultRewriteRuleSetName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#name ApplicationGateway#name}
    */
    readonly name: string;
    /**
    * path_rule block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#path_rule ApplicationGateway#path_rule}
    */
    readonly pathRule: ApplicationGatewayUrlPathMapPathRule[] | cdktn.IResolvable;
}
export declare function applicationGatewayUrlPathMapToTerraform(struct?: ApplicationGatewayUrlPathMap | cdktn.IResolvable): any;
export declare function applicationGatewayUrlPathMapToHclTerraform(struct?: ApplicationGatewayUrlPathMap | cdktn.IResolvable): any;
export declare class ApplicationGatewayUrlPathMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayUrlPathMap | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayUrlPathMap | cdktn.IResolvable | undefined);
    get defaultBackendAddressPoolId(): string;
    private _defaultBackendAddressPoolName?;
    get defaultBackendAddressPoolName(): string;
    set defaultBackendAddressPoolName(value: string);
    resetDefaultBackendAddressPoolName(): void;
    get defaultBackendAddressPoolNameInput(): string | undefined;
    get defaultBackendHttpSettingsId(): string;
    private _defaultBackendHttpSettingsName?;
    get defaultBackendHttpSettingsName(): string;
    set defaultBackendHttpSettingsName(value: string);
    resetDefaultBackendHttpSettingsName(): void;
    get defaultBackendHttpSettingsNameInput(): string | undefined;
    get defaultRedirectConfigurationId(): string;
    private _defaultRedirectConfigurationName?;
    get defaultRedirectConfigurationName(): string;
    set defaultRedirectConfigurationName(value: string);
    resetDefaultRedirectConfigurationName(): void;
    get defaultRedirectConfigurationNameInput(): string | undefined;
    get defaultRewriteRuleSetId(): string;
    private _defaultRewriteRuleSetName?;
    get defaultRewriteRuleSetName(): string;
    set defaultRewriteRuleSetName(value: string);
    resetDefaultRewriteRuleSetName(): void;
    get defaultRewriteRuleSetNameInput(): string | undefined;
    get id(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _pathRule;
    get pathRule(): ApplicationGatewayUrlPathMapPathRuleList;
    putPathRule(value: ApplicationGatewayUrlPathMapPathRule[] | cdktn.IResolvable): void;
    get pathRuleInput(): cdktn.IResolvable | ApplicationGatewayUrlPathMapPathRule[] | undefined;
}
export declare class ApplicationGatewayUrlPathMapList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayUrlPathMap[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayUrlPathMapOutputReference;
}
export interface ApplicationGatewayWafConfigurationDisabledRuleGroup {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#rule_group_name ApplicationGateway#rule_group_name}
    */
    readonly ruleGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#rules ApplicationGateway#rules}
    */
    readonly rules?: number[];
}
export declare function applicationGatewayWafConfigurationDisabledRuleGroupToTerraform(struct?: ApplicationGatewayWafConfigurationDisabledRuleGroup | cdktn.IResolvable): any;
export declare function applicationGatewayWafConfigurationDisabledRuleGroupToHclTerraform(struct?: ApplicationGatewayWafConfigurationDisabledRuleGroup | cdktn.IResolvable): any;
export declare class ApplicationGatewayWafConfigurationDisabledRuleGroupOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayWafConfigurationDisabledRuleGroup | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayWafConfigurationDisabledRuleGroup | cdktn.IResolvable | undefined);
    private _ruleGroupName?;
    get ruleGroupName(): string;
    set ruleGroupName(value: string);
    get ruleGroupNameInput(): string | undefined;
    private _rules?;
    get rules(): number[];
    set rules(value: number[]);
    resetRules(): void;
    get rulesInput(): number[] | undefined;
}
export declare class ApplicationGatewayWafConfigurationDisabledRuleGroupList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayWafConfigurationDisabledRuleGroup[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayWafConfigurationDisabledRuleGroupOutputReference;
}
export interface ApplicationGatewayWafConfigurationExclusion {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#match_variable ApplicationGateway#match_variable}
    */
    readonly matchVariable: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#selector ApplicationGateway#selector}
    */
    readonly selector?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#selector_match_operator ApplicationGateway#selector_match_operator}
    */
    readonly selectorMatchOperator?: string;
}
export declare function applicationGatewayWafConfigurationExclusionToTerraform(struct?: ApplicationGatewayWafConfigurationExclusion | cdktn.IResolvable): any;
export declare function applicationGatewayWafConfigurationExclusionToHclTerraform(struct?: ApplicationGatewayWafConfigurationExclusion | cdktn.IResolvable): any;
export declare class ApplicationGatewayWafConfigurationExclusionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationGatewayWafConfigurationExclusion | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationGatewayWafConfigurationExclusion | cdktn.IResolvable | undefined);
    private _matchVariable?;
    get matchVariable(): string;
    set matchVariable(value: string);
    get matchVariableInput(): string | undefined;
    private _selector?;
    get selector(): string;
    set selector(value: string);
    resetSelector(): void;
    get selectorInput(): string | undefined;
    private _selectorMatchOperator?;
    get selectorMatchOperator(): string;
    set selectorMatchOperator(value: string);
    resetSelectorMatchOperator(): void;
    get selectorMatchOperatorInput(): string | undefined;
}
export declare class ApplicationGatewayWafConfigurationExclusionList extends cdktn.ComplexList {
    internalValue?: ApplicationGatewayWafConfigurationExclusion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationGatewayWafConfigurationExclusionOutputReference;
}
export interface ApplicationGatewayWafConfiguration {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#enabled ApplicationGateway#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#file_upload_limit_mb ApplicationGateway#file_upload_limit_mb}
    */
    readonly fileUploadLimitMb?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#firewall_mode ApplicationGateway#firewall_mode}
    */
    readonly firewallMode: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#max_request_body_size_kb ApplicationGateway#max_request_body_size_kb}
    */
    readonly maxRequestBodySizeKb?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#request_body_check ApplicationGateway#request_body_check}
    */
    readonly requestBodyCheck?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#rule_set_type ApplicationGateway#rule_set_type}
    */
    readonly ruleSetType?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#rule_set_version ApplicationGateway#rule_set_version}
    */
    readonly ruleSetVersion: string;
    /**
    * disabled_rule_group block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#disabled_rule_group ApplicationGateway#disabled_rule_group}
    */
    readonly disabledRuleGroup?: ApplicationGatewayWafConfigurationDisabledRuleGroup[] | cdktn.IResolvable;
    /**
    * exclusion block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#exclusion ApplicationGateway#exclusion}
    */
    readonly exclusion?: ApplicationGatewayWafConfigurationExclusion[] | cdktn.IResolvable;
}
export declare function applicationGatewayWafConfigurationToTerraform(struct?: ApplicationGatewayWafConfigurationOutputReference | ApplicationGatewayWafConfiguration): any;
export declare function applicationGatewayWafConfigurationToHclTerraform(struct?: ApplicationGatewayWafConfigurationOutputReference | ApplicationGatewayWafConfiguration): any;
export declare class ApplicationGatewayWafConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationGatewayWafConfiguration | undefined;
    set internalValue(value: ApplicationGatewayWafConfiguration | undefined);
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _fileUploadLimitMb?;
    get fileUploadLimitMb(): number;
    set fileUploadLimitMb(value: number);
    resetFileUploadLimitMb(): void;
    get fileUploadLimitMbInput(): number | undefined;
    private _firewallMode?;
    get firewallMode(): string;
    set firewallMode(value: string);
    get firewallModeInput(): string | undefined;
    private _maxRequestBodySizeKb?;
    get maxRequestBodySizeKb(): number;
    set maxRequestBodySizeKb(value: number);
    resetMaxRequestBodySizeKb(): void;
    get maxRequestBodySizeKbInput(): number | undefined;
    private _requestBodyCheck?;
    get requestBodyCheck(): boolean | cdktn.IResolvable;
    set requestBodyCheck(value: boolean | cdktn.IResolvable);
    resetRequestBodyCheck(): void;
    get requestBodyCheckInput(): boolean | cdktn.IResolvable | undefined;
    private _ruleSetType?;
    get ruleSetType(): string;
    set ruleSetType(value: string);
    resetRuleSetType(): void;
    get ruleSetTypeInput(): string | undefined;
    private _ruleSetVersion?;
    get ruleSetVersion(): string;
    set ruleSetVersion(value: string);
    get ruleSetVersionInput(): string | undefined;
    private _disabledRuleGroup;
    get disabledRuleGroup(): ApplicationGatewayWafConfigurationDisabledRuleGroupList;
    putDisabledRuleGroup(value: ApplicationGatewayWafConfigurationDisabledRuleGroup[] | cdktn.IResolvable): void;
    resetDisabledRuleGroup(): void;
    get disabledRuleGroupInput(): cdktn.IResolvable | ApplicationGatewayWafConfigurationDisabledRuleGroup[] | undefined;
    private _exclusion;
    get exclusion(): ApplicationGatewayWafConfigurationExclusionList;
    putExclusion(value: ApplicationGatewayWafConfigurationExclusion[] | cdktn.IResolvable): void;
    resetExclusion(): void;
    get exclusionInput(): cdktn.IResolvable | ApplicationGatewayWafConfigurationExclusion[] | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway azurerm_application_gateway}
*/
export declare class ApplicationGateway extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_application_gateway";
    /**
    * Generates CDKTN code for importing a ApplicationGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationGateway to import
    * @param importFromId The id of the existing ApplicationGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/application_gateway azurerm_application_gateway} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationGatewayConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationGatewayConfig);
    private _fipsEnabled?;
    get fipsEnabled(): boolean | cdktn.IResolvable;
    set fipsEnabled(value: boolean | cdktn.IResolvable);
    resetFipsEnabled(): void;
    get fipsEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _firewallPolicyId?;
    get firewallPolicyId(): string;
    set firewallPolicyId(value: string);
    resetFirewallPolicyId(): void;
    get firewallPolicyIdInput(): string | undefined;
    private _forceFirewallPolicyAssociation?;
    get forceFirewallPolicyAssociation(): boolean | cdktn.IResolvable;
    set forceFirewallPolicyAssociation(value: boolean | cdktn.IResolvable);
    resetForceFirewallPolicyAssociation(): void;
    get forceFirewallPolicyAssociationInput(): boolean | cdktn.IResolvable | undefined;
    private _http2Enabled?;
    get http2Enabled(): boolean | cdktn.IResolvable;
    set http2Enabled(value: boolean | cdktn.IResolvable);
    resetHttp2Enabled(): void;
    get http2EnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _privateEndpointConnection;
    get privateEndpointConnection(): ApplicationGatewayPrivateEndpointConnectionList;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _zones?;
    get zones(): string[];
    set zones(value: string[]);
    resetZones(): void;
    get zonesInput(): string[] | undefined;
    private _autoscaleConfiguration;
    get autoscaleConfiguration(): ApplicationGatewayAutoscaleConfigurationOutputReference;
    putAutoscaleConfiguration(value: ApplicationGatewayAutoscaleConfiguration): void;
    resetAutoscaleConfiguration(): void;
    get autoscaleConfigurationInput(): ApplicationGatewayAutoscaleConfiguration | undefined;
    private _backend;
    get backend(): ApplicationGatewayBackendList;
    putBackend(value: ApplicationGatewayBackend[] | cdktn.IResolvable): void;
    resetBackend(): void;
    get backendInput(): cdktn.IResolvable | ApplicationGatewayBackend[] | undefined;
    private _backendAddressPool;
    get backendAddressPool(): ApplicationGatewayBackendAddressPoolList;
    putBackendAddressPool(value: ApplicationGatewayBackendAddressPool[] | cdktn.IResolvable): void;
    get backendAddressPoolInput(): cdktn.IResolvable | ApplicationGatewayBackendAddressPool[] | undefined;
    private _backendHttpSettings;
    get backendHttpSettings(): ApplicationGatewayBackendHttpSettingsList;
    putBackendHttpSettings(value: ApplicationGatewayBackendHttpSettings[] | cdktn.IResolvable): void;
    resetBackendHttpSettings(): void;
    get backendHttpSettingsInput(): cdktn.IResolvable | ApplicationGatewayBackendHttpSettings[] | undefined;
    private _customErrorConfiguration;
    get customErrorConfiguration(): ApplicationGatewayCustomErrorConfigurationList;
    putCustomErrorConfiguration(value: ApplicationGatewayCustomErrorConfiguration[] | cdktn.IResolvable): void;
    resetCustomErrorConfiguration(): void;
    get customErrorConfigurationInput(): cdktn.IResolvable | ApplicationGatewayCustomErrorConfiguration[] | undefined;
    private _frontendIpConfiguration;
    get frontendIpConfiguration(): ApplicationGatewayFrontendIpConfigurationList;
    putFrontendIpConfiguration(value: ApplicationGatewayFrontendIpConfiguration[] | cdktn.IResolvable): void;
    get frontendIpConfigurationInput(): cdktn.IResolvable | ApplicationGatewayFrontendIpConfiguration[] | undefined;
    private _frontendPort;
    get frontendPort(): ApplicationGatewayFrontendPortList;
    putFrontendPort(value: ApplicationGatewayFrontendPort[] | cdktn.IResolvable): void;
    get frontendPortInput(): cdktn.IResolvable | ApplicationGatewayFrontendPort[] | undefined;
    private _gatewayIpConfiguration;
    get gatewayIpConfiguration(): ApplicationGatewayGatewayIpConfigurationList;
    putGatewayIpConfiguration(value: ApplicationGatewayGatewayIpConfiguration[] | cdktn.IResolvable): void;
    get gatewayIpConfigurationInput(): cdktn.IResolvable | ApplicationGatewayGatewayIpConfiguration[] | undefined;
    private _global;
    get global(): ApplicationGatewayGlobalOutputReference;
    putGlobal(value: ApplicationGatewayGlobal): void;
    resetGlobal(): void;
    get globalInput(): ApplicationGatewayGlobal | undefined;
    private _httpListener;
    get httpListener(): ApplicationGatewayHttpListenerList;
    putHttpListener(value: ApplicationGatewayHttpListener[] | cdktn.IResolvable): void;
    resetHttpListener(): void;
    get httpListenerInput(): cdktn.IResolvable | ApplicationGatewayHttpListener[] | undefined;
    private _identity;
    get identity(): ApplicationGatewayIdentityOutputReference;
    putIdentity(value: ApplicationGatewayIdentity): void;
    resetIdentity(): void;
    get identityInput(): ApplicationGatewayIdentity | undefined;
    private _listener;
    get listener(): ApplicationGatewayListenerList;
    putListener(value: ApplicationGatewayListener[] | cdktn.IResolvable): void;
    resetListener(): void;
    get listenerInput(): cdktn.IResolvable | ApplicationGatewayListener[] | undefined;
    private _privateLinkConfiguration;
    get privateLinkConfiguration(): ApplicationGatewayPrivateLinkConfigurationList;
    putPrivateLinkConfiguration(value: ApplicationGatewayPrivateLinkConfiguration[] | cdktn.IResolvable): void;
    resetPrivateLinkConfiguration(): void;
    get privateLinkConfigurationInput(): cdktn.IResolvable | ApplicationGatewayPrivateLinkConfiguration[] | undefined;
    private _probe;
    get probe(): ApplicationGatewayProbeList;
    putProbe(value: ApplicationGatewayProbe[] | cdktn.IResolvable): void;
    resetProbe(): void;
    get probeInput(): cdktn.IResolvable | ApplicationGatewayProbe[] | undefined;
    private _redirectConfiguration;
    get redirectConfiguration(): ApplicationGatewayRedirectConfigurationList;
    putRedirectConfiguration(value: ApplicationGatewayRedirectConfiguration[] | cdktn.IResolvable): void;
    resetRedirectConfiguration(): void;
    get redirectConfigurationInput(): cdktn.IResolvable | ApplicationGatewayRedirectConfiguration[] | undefined;
    private _requestRoutingRule;
    get requestRoutingRule(): ApplicationGatewayRequestRoutingRuleList;
    putRequestRoutingRule(value: ApplicationGatewayRequestRoutingRule[] | cdktn.IResolvable): void;
    resetRequestRoutingRule(): void;
    get requestRoutingRuleInput(): cdktn.IResolvable | ApplicationGatewayRequestRoutingRule[] | undefined;
    private _rewriteRuleSet;
    get rewriteRuleSet(): ApplicationGatewayRewriteRuleSetList;
    putRewriteRuleSet(value: ApplicationGatewayRewriteRuleSet[] | cdktn.IResolvable): void;
    resetRewriteRuleSet(): void;
    get rewriteRuleSetInput(): cdktn.IResolvable | ApplicationGatewayRewriteRuleSet[] | undefined;
    private _routingRule;
    get routingRule(): ApplicationGatewayRoutingRuleList;
    putRoutingRule(value: ApplicationGatewayRoutingRule[] | cdktn.IResolvable): void;
    resetRoutingRule(): void;
    get routingRuleInput(): cdktn.IResolvable | ApplicationGatewayRoutingRule[] | undefined;
    private _sku;
    get sku(): ApplicationGatewaySkuOutputReference;
    putSku(value: ApplicationGatewaySku): void;
    get skuInput(): ApplicationGatewaySku | undefined;
    private _sslCertificate;
    get sslCertificate(): ApplicationGatewaySslCertificateList;
    putSslCertificate(value: ApplicationGatewaySslCertificate[] | cdktn.IResolvable): void;
    resetSslCertificate(): void;
    get sslCertificateInput(): cdktn.IResolvable | ApplicationGatewaySslCertificate[] | undefined;
    private _sslPolicy;
    get sslPolicy(): ApplicationGatewaySslPolicyOutputReference;
    putSslPolicy(value: ApplicationGatewaySslPolicy): void;
    resetSslPolicy(): void;
    get sslPolicyInput(): ApplicationGatewaySslPolicy | undefined;
    private _sslProfile;
    get sslProfile(): ApplicationGatewaySslProfileList;
    putSslProfile(value: ApplicationGatewaySslProfile[] | cdktn.IResolvable): void;
    resetSslProfile(): void;
    get sslProfileInput(): cdktn.IResolvable | ApplicationGatewaySslProfile[] | undefined;
    private _timeouts;
    get timeouts(): ApplicationGatewayTimeoutsOutputReference;
    putTimeouts(value: ApplicationGatewayTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationGatewayTimeouts | undefined;
    private _trustedClientCertificate;
    get trustedClientCertificate(): ApplicationGatewayTrustedClientCertificateList;
    putTrustedClientCertificate(value: ApplicationGatewayTrustedClientCertificate[] | cdktn.IResolvable): void;
    resetTrustedClientCertificate(): void;
    get trustedClientCertificateInput(): cdktn.IResolvable | ApplicationGatewayTrustedClientCertificate[] | undefined;
    private _trustedRootCertificate;
    get trustedRootCertificate(): ApplicationGatewayTrustedRootCertificateList;
    putTrustedRootCertificate(value: ApplicationGatewayTrustedRootCertificate[] | cdktn.IResolvable): void;
    resetTrustedRootCertificate(): void;
    get trustedRootCertificateInput(): cdktn.IResolvable | ApplicationGatewayTrustedRootCertificate[] | undefined;
    private _urlPathMap;
    get urlPathMap(): ApplicationGatewayUrlPathMapList;
    putUrlPathMap(value: ApplicationGatewayUrlPathMap[] | cdktn.IResolvable): void;
    resetUrlPathMap(): void;
    get urlPathMapInput(): cdktn.IResolvable | ApplicationGatewayUrlPathMap[] | undefined;
    private _wafConfiguration;
    get wafConfiguration(): ApplicationGatewayWafConfigurationOutputReference;
    putWafConfiguration(value: ApplicationGatewayWafConfiguration): void;
    resetWafConfiguration(): void;
    get wafConfigurationInput(): ApplicationGatewayWafConfiguration | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
