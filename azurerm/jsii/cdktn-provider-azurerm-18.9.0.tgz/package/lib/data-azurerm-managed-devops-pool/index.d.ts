/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermManagedDevopsPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/managed_devops_pool#id DataAzurermManagedDevopsPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/managed_devops_pool#name DataAzurermManagedDevopsPool#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/managed_devops_pool#resource_group_name DataAzurermManagedDevopsPool#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/managed_devops_pool#timeouts DataAzurermManagedDevopsPool#timeouts}
    */
    readonly timeouts?: DataAzurermManagedDevopsPoolTimeouts;
}
export interface DataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganization {
}
export declare function dataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganizationToTerraform(struct?: DataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganization): any;
export declare function dataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganizationToHclTerraform(struct?: DataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganization): any;
export declare class DataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganization | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganization | undefined);
    get parallelism(): number;
    get projects(): string[];
    get url(): string;
}
export declare class DataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganizationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganizationOutputReference;
}
export interface DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccount {
}
export declare function dataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccountToTerraform(struct?: DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccount): any;
export declare function dataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccountToHclTerraform(struct?: DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccount): any;
export declare class DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccount | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccount | undefined);
    get groups(): string[];
    get users(): string[];
}
export declare class DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccountList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccountOutputReference;
}
export interface DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermission {
}
export declare function dataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionToTerraform(struct?: DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermission): any;
export declare function dataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionToHclTerraform(struct?: DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermission): any;
export declare class DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermission | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermission | undefined);
    private _administratorAccount;
    get administratorAccount(): DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionAdministratorAccountList;
    get kind(): string;
}
export declare class DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionOutputReference;
}
export interface DataAzurermManagedDevopsPoolAzureDevopsOrganization {
}
export declare function dataAzurermManagedDevopsPoolAzureDevopsOrganizationToTerraform(struct?: DataAzurermManagedDevopsPoolAzureDevopsOrganization): any;
export declare function dataAzurermManagedDevopsPoolAzureDevopsOrganizationToHclTerraform(struct?: DataAzurermManagedDevopsPoolAzureDevopsOrganization): any;
export declare class DataAzurermManagedDevopsPoolAzureDevopsOrganizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolAzureDevopsOrganization | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolAzureDevopsOrganization | undefined);
    private _organization;
    get organization(): DataAzurermManagedDevopsPoolAzureDevopsOrganizationOrganizationList;
    private _permission;
    get permission(): DataAzurermManagedDevopsPoolAzureDevopsOrganizationPermissionList;
}
export declare class DataAzurermManagedDevopsPoolAzureDevopsOrganizationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolAzureDevopsOrganizationOutputReference;
}
export interface DataAzurermManagedDevopsPoolIdentity {
}
export declare function dataAzurermManagedDevopsPoolIdentityToTerraform(struct?: DataAzurermManagedDevopsPoolIdentity): any;
export declare function dataAzurermManagedDevopsPoolIdentityToHclTerraform(struct?: DataAzurermManagedDevopsPoolIdentity): any;
export declare class DataAzurermManagedDevopsPoolIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolIdentity | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolIdentity | undefined);
    get identityIds(): string[];
    get type(): string;
}
export declare class DataAzurermManagedDevopsPoolIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolIdentityOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePrediction {
}
export declare function dataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePredictionToTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePrediction): any;
export declare function dataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePredictionToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePrediction): any;
export declare class DataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePredictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePrediction | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePrediction | undefined);
    get predictionPreference(): string;
}
export declare class DataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePredictionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePredictionOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatefulAgentManualResourcePrediction {
}
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionToTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePrediction): any;
export declare function dataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePrediction): any;
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePrediction | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatefulAgentManualResourcePrediction | undefined);
    get allWeekSchedule(): number;
    private _fridaySchedule;
    get fridaySchedule(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionFridayScheduleList;
    private _mondaySchedule;
    get mondaySchedule(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionMondayScheduleList;
    private _saturdaySchedule;
    get saturdaySchedule(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSaturdayScheduleList;
    private _sundaySchedule;
    get sundaySchedule(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionSundayScheduleList;
    private _thursdaySchedule;
    get thursdaySchedule(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionThursdayScheduleList;
    get timeZoneName(): string;
    private _tuesdaySchedule;
    get tuesdaySchedule(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionTuesdayScheduleList;
    private _wednesdaySchedule;
    get wednesdaySchedule(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionWednesdayScheduleList;
}
export declare class DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatefulAgent {
}
export declare function dataAzurermManagedDevopsPoolStatefulAgentToTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgent): any;
export declare function dataAzurermManagedDevopsPoolStatefulAgentToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatefulAgent): any;
export declare class DataAzurermManagedDevopsPoolStatefulAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatefulAgent | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatefulAgent | undefined);
    private _automaticResourcePrediction;
    get automaticResourcePrediction(): DataAzurermManagedDevopsPoolStatefulAgentAutomaticResourcePredictionList;
    get gracePeriodTimeSpan(): string;
    private _manualResourcePrediction;
    get manualResourcePrediction(): DataAzurermManagedDevopsPoolStatefulAgentManualResourcePredictionList;
    get maximumAgentLifetime(): string;
}
export declare class DataAzurermManagedDevopsPoolStatefulAgentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatefulAgentOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePrediction {
}
export declare function dataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePredictionToTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePrediction): any;
export declare function dataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePredictionToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePrediction): any;
export declare class DataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePredictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePrediction | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePrediction | undefined);
    get predictionPreference(): string;
}
export declare class DataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePredictionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePredictionOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdaySchedule {
}
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdayScheduleToTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdaySchedule): any;
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdayScheduleToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdaySchedule): any;
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdayScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdaySchedule | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdaySchedule | undefined);
    get count(): number;
    get time(): string;
}
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdayScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdayScheduleOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatelessAgentManualResourcePrediction {
}
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionToTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePrediction): any;
export declare function dataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePrediction): any;
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePrediction | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatelessAgentManualResourcePrediction | undefined);
    get allWeekSchedule(): number;
    private _fridaySchedule;
    get fridaySchedule(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionFridayScheduleList;
    private _mondaySchedule;
    get mondaySchedule(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionMondayScheduleList;
    private _saturdaySchedule;
    get saturdaySchedule(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSaturdayScheduleList;
    private _sundaySchedule;
    get sundaySchedule(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionSundayScheduleList;
    private _thursdaySchedule;
    get thursdaySchedule(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionThursdayScheduleList;
    get timeZoneName(): string;
    private _tuesdaySchedule;
    get tuesdaySchedule(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionTuesdayScheduleList;
    private _wednesdaySchedule;
    get wednesdaySchedule(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionWednesdayScheduleList;
}
export declare class DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionOutputReference;
}
export interface DataAzurermManagedDevopsPoolStatelessAgent {
}
export declare function dataAzurermManagedDevopsPoolStatelessAgentToTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgent): any;
export declare function dataAzurermManagedDevopsPoolStatelessAgentToHclTerraform(struct?: DataAzurermManagedDevopsPoolStatelessAgent): any;
export declare class DataAzurermManagedDevopsPoolStatelessAgentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolStatelessAgent | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolStatelessAgent | undefined);
    private _automaticResourcePrediction;
    get automaticResourcePrediction(): DataAzurermManagedDevopsPoolStatelessAgentAutomaticResourcePredictionList;
    private _manualResourcePrediction;
    get manualResourcePrediction(): DataAzurermManagedDevopsPoolStatelessAgentManualResourcePredictionList;
}
export declare class DataAzurermManagedDevopsPoolStatelessAgentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolStatelessAgentOutputReference;
}
export interface DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImage {
}
export declare function dataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImageToTerraform(struct?: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImage): any;
export declare function dataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImageToHclTerraform(struct?: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImage): any;
export declare class DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImage | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImage | undefined);
    get aliases(): string[];
    get buffer(): string;
    get id(): string;
    get wellKnownImageName(): string;
}
export declare class DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImageOutputReference;
}
export interface DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagement {
}
export declare function dataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagementToTerraform(struct?: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagement): any;
export declare function dataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagementToHclTerraform(struct?: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagement): any;
export declare class DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagement | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagement | undefined);
    get certificateStoreLocation(): string;
    get certificateStoreName(): string;
    get keyExportEnabled(): cdktn.IResolvable;
    get keyVaultCertificateIds(): string[];
}
export declare class DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagementOutputReference;
}
export interface DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurity {
}
export declare function dataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityToTerraform(struct?: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurity): any;
export declare function dataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityToHclTerraform(struct?: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurity): any;
export declare class DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurity | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurity | undefined);
    get interactiveLogonEnabled(): cdktn.IResolvable;
    private _keyVaultManagement;
    get keyVaultManagement(): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityKeyVaultManagementList;
}
export declare class DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityOutputReference;
}
export interface DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorage {
}
export declare function dataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorageToTerraform(struct?: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorage): any;
export declare function dataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorageToHclTerraform(struct?: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorage): any;
export declare class DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorage | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorage | undefined);
    get caching(): string;
    get diskSizeInGb(): number;
    get driveLetter(): string;
    get storageAccountType(): string;
}
export declare class DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorageOutputReference;
}
export interface DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabric {
}
export declare function dataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricToTerraform(struct?: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabric): any;
export declare function dataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricToHclTerraform(struct?: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabric): any;
export declare class DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabric | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabric | undefined);
    private _image;
    get image(): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricImageList;
    get osDiskStorageAccountType(): string;
    private _security;
    get security(): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricSecurityList;
    get skuName(): string;
    private _storage;
    get storage(): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricStorageList;
    get subnetId(): string;
}
export declare class DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricOutputReference;
}
export interface DataAzurermManagedDevopsPoolTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/managed_devops_pool#read DataAzurermManagedDevopsPool#read}
    */
    readonly read?: string;
}
export declare function dataAzurermManagedDevopsPoolTimeoutsToTerraform(struct?: DataAzurermManagedDevopsPoolTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermManagedDevopsPoolTimeoutsToHclTerraform(struct?: DataAzurermManagedDevopsPoolTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermManagedDevopsPoolTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermManagedDevopsPoolTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermManagedDevopsPoolTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/managed_devops_pool azurerm_managed_devops_pool}
*/
export declare class DataAzurermManagedDevopsPool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_managed_devops_pool";
    /**
    * Generates CDKTN code for importing a DataAzurermManagedDevopsPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermManagedDevopsPool to import
    * @param importFromId The id of the existing DataAzurermManagedDevopsPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/managed_devops_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermManagedDevopsPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/managed_devops_pool azurerm_managed_devops_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermManagedDevopsPoolConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermManagedDevopsPoolConfig);
    private _azureDevopsOrganization;
    get azureDevopsOrganization(): DataAzurermManagedDevopsPoolAzureDevopsOrganizationList;
    get devCenterProjectId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): DataAzurermManagedDevopsPoolIdentityList;
    get location(): string;
    get maximumConcurrency(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _statefulAgent;
    get statefulAgent(): DataAzurermManagedDevopsPoolStatefulAgentList;
    private _statelessAgent;
    get statelessAgent(): DataAzurermManagedDevopsPoolStatelessAgentList;
    private _tags;
    get tags(): cdktn.StringMap;
    private _virtualMachineScaleSetFabric;
    get virtualMachineScaleSetFabric(): DataAzurermManagedDevopsPoolVirtualMachineScaleSetFabricList;
    get workFolder(): string;
    private _timeouts;
    get timeouts(): DataAzurermManagedDevopsPoolTimeoutsOutputReference;
    putTimeouts(value: DataAzurermManagedDevopsPoolTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermManagedDevopsPoolTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
