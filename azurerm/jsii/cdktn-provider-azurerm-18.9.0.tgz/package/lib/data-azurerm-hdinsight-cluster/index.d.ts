/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermHdinsightClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/hdinsight_cluster#id DataAzurermHdinsightCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/hdinsight_cluster#name DataAzurermHdinsightCluster#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/hdinsight_cluster#resource_group_name DataAzurermHdinsightCluster#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/hdinsight_cluster#timeouts DataAzurermHdinsightCluster#timeouts}
    */
    readonly timeouts?: DataAzurermHdinsightClusterTimeouts;
}
export interface DataAzurermHdinsightClusterGateway {
}
export declare function dataAzurermHdinsightClusterGatewayToTerraform(struct?: DataAzurermHdinsightClusterGateway): any;
export declare function dataAzurermHdinsightClusterGatewayToHclTerraform(struct?: DataAzurermHdinsightClusterGateway): any;
export declare class DataAzurermHdinsightClusterGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermHdinsightClusterGateway | undefined;
    set internalValue(value: DataAzurermHdinsightClusterGateway | undefined);
    get enabled(): cdktn.IResolvable;
    get password(): string;
    get username(): string;
}
export declare class DataAzurermHdinsightClusterGatewayList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermHdinsightClusterGatewayOutputReference;
}
export interface DataAzurermHdinsightClusterTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/hdinsight_cluster#read DataAzurermHdinsightCluster#read}
    */
    readonly read?: string;
}
export declare function dataAzurermHdinsightClusterTimeoutsToTerraform(struct?: DataAzurermHdinsightClusterTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermHdinsightClusterTimeoutsToHclTerraform(struct?: DataAzurermHdinsightClusterTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermHdinsightClusterTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermHdinsightClusterTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermHdinsightClusterTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/hdinsight_cluster azurerm_hdinsight_cluster}
*/
export declare class DataAzurermHdinsightCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_hdinsight_cluster";
    /**
    * Generates CDKTN code for importing a DataAzurermHdinsightCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermHdinsightCluster to import
    * @param importFromId The id of the existing DataAzurermHdinsightCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/hdinsight_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermHdinsightCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/hdinsight_cluster azurerm_hdinsight_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermHdinsightClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermHdinsightClusterConfig);
    get clusterId(): string;
    get clusterVersion(): string;
    private _componentVersions;
    get componentVersions(): cdktn.StringMap;
    get edgeSshEndpoint(): string;
    private _gateway;
    get gateway(): DataAzurermHdinsightClusterGatewayList;
    get httpsEndpoint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kafkaRestProxyEndpoint(): string;
    get kind(): string;
    get location(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    get sshEndpoint(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    get tier(): string;
    get tlsMinVersion(): string;
    private _timeouts;
    get timeouts(): DataAzurermHdinsightClusterTimeoutsOutputReference;
    putTimeouts(value: DataAzurermHdinsightClusterTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermHdinsightClusterTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
