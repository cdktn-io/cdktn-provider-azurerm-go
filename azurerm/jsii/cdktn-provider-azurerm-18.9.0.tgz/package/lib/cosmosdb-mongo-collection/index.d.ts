/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CosmosdbMongoCollectionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#account_name CosmosdbMongoCollection#account_name}
    */
    readonly accountName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#analytical_storage_ttl CosmosdbMongoCollection#analytical_storage_ttl}
    */
    readonly analyticalStorageTtl?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#database_name CosmosdbMongoCollection#database_name}
    */
    readonly databaseName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#default_ttl_seconds CosmosdbMongoCollection#default_ttl_seconds}
    */
    readonly defaultTtlSeconds?: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#id CosmosdbMongoCollection#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#name CosmosdbMongoCollection#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#resource_group_name CosmosdbMongoCollection#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#shard_key CosmosdbMongoCollection#shard_key}
    */
    readonly shardKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#throughput CosmosdbMongoCollection#throughput}
    */
    readonly throughput?: number;
    /**
    * autoscale_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#autoscale_settings CosmosdbMongoCollection#autoscale_settings}
    */
    readonly autoscaleSettings?: CosmosdbMongoCollectionAutoscaleSettings;
    /**
    * index block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#index CosmosdbMongoCollection#index}
    */
    readonly index?: CosmosdbMongoCollectionIndex[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#timeouts CosmosdbMongoCollection#timeouts}
    */
    readonly timeouts?: CosmosdbMongoCollectionTimeouts;
}
export interface CosmosdbMongoCollectionSystemIndexes {
}
export declare function cosmosdbMongoCollectionSystemIndexesToTerraform(struct?: CosmosdbMongoCollectionSystemIndexes): any;
export declare function cosmosdbMongoCollectionSystemIndexesToHclTerraform(struct?: CosmosdbMongoCollectionSystemIndexes): any;
export declare class CosmosdbMongoCollectionSystemIndexesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbMongoCollectionSystemIndexes | undefined;
    set internalValue(value: CosmosdbMongoCollectionSystemIndexes | undefined);
    get keys(): string[];
    get unique(): cdktn.IResolvable;
}
export declare class CosmosdbMongoCollectionSystemIndexesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbMongoCollectionSystemIndexesOutputReference;
}
export interface CosmosdbMongoCollectionAutoscaleSettings {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#max_throughput CosmosdbMongoCollection#max_throughput}
    */
    readonly maxThroughput?: number;
}
export declare function cosmosdbMongoCollectionAutoscaleSettingsToTerraform(struct?: CosmosdbMongoCollectionAutoscaleSettingsOutputReference | CosmosdbMongoCollectionAutoscaleSettings): any;
export declare function cosmosdbMongoCollectionAutoscaleSettingsToHclTerraform(struct?: CosmosdbMongoCollectionAutoscaleSettingsOutputReference | CosmosdbMongoCollectionAutoscaleSettings): any;
export declare class CosmosdbMongoCollectionAutoscaleSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbMongoCollectionAutoscaleSettings | undefined;
    set internalValue(value: CosmosdbMongoCollectionAutoscaleSettings | undefined);
    private _maxThroughput?;
    get maxThroughput(): number;
    set maxThroughput(value: number);
    resetMaxThroughput(): void;
    get maxThroughputInput(): number | undefined;
}
export interface CosmosdbMongoCollectionIndex {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#keys CosmosdbMongoCollection#keys}
    */
    readonly keys: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#unique CosmosdbMongoCollection#unique}
    */
    readonly unique?: boolean | cdktn.IResolvable;
}
export declare function cosmosdbMongoCollectionIndexToTerraform(struct?: CosmosdbMongoCollectionIndex | cdktn.IResolvable): any;
export declare function cosmosdbMongoCollectionIndexToHclTerraform(struct?: CosmosdbMongoCollectionIndex | cdktn.IResolvable): any;
export declare class CosmosdbMongoCollectionIndexOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CosmosdbMongoCollectionIndex | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbMongoCollectionIndex | cdktn.IResolvable | undefined);
    private _keys?;
    get keys(): string[];
    set keys(value: string[]);
    get keysInput(): string[] | undefined;
    private _unique?;
    get unique(): boolean | cdktn.IResolvable;
    set unique(value: boolean | cdktn.IResolvable);
    resetUnique(): void;
    get uniqueInput(): boolean | cdktn.IResolvable | undefined;
}
export declare class CosmosdbMongoCollectionIndexList extends cdktn.ComplexList {
    internalValue?: CosmosdbMongoCollectionIndex[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CosmosdbMongoCollectionIndexOutputReference;
}
export interface CosmosdbMongoCollectionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#create CosmosdbMongoCollection#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#delete CosmosdbMongoCollection#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#read CosmosdbMongoCollection#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#update CosmosdbMongoCollection#update}
    */
    readonly update?: string;
}
export declare function cosmosdbMongoCollectionTimeoutsToTerraform(struct?: CosmosdbMongoCollectionTimeouts | cdktn.IResolvable): any;
export declare function cosmosdbMongoCollectionTimeoutsToHclTerraform(struct?: CosmosdbMongoCollectionTimeouts | cdktn.IResolvable): any;
export declare class CosmosdbMongoCollectionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CosmosdbMongoCollectionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CosmosdbMongoCollectionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection azurerm_cosmosdb_mongo_collection}
*/
export declare class CosmosdbMongoCollection extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_cosmosdb_mongo_collection";
    /**
    * Generates CDKTN code for importing a CosmosdbMongoCollection resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CosmosdbMongoCollection to import
    * @param importFromId The id of the existing CosmosdbMongoCollection that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CosmosdbMongoCollection to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/cosmosdb_mongo_collection azurerm_cosmosdb_mongo_collection} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CosmosdbMongoCollectionConfig
    */
    constructor(scope: Construct, id: string, config: CosmosdbMongoCollectionConfig);
    private _accountName?;
    get accountName(): string;
    set accountName(value: string);
    get accountNameInput(): string | undefined;
    private _analyticalStorageTtl?;
    get analyticalStorageTtl(): number;
    set analyticalStorageTtl(value: number);
    resetAnalyticalStorageTtl(): void;
    get analyticalStorageTtlInput(): number | undefined;
    private _databaseName?;
    get databaseName(): string;
    set databaseName(value: string);
    get databaseNameInput(): string | undefined;
    private _defaultTtlSeconds?;
    get defaultTtlSeconds(): number;
    set defaultTtlSeconds(value: number);
    resetDefaultTtlSeconds(): void;
    get defaultTtlSecondsInput(): number | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _shardKey?;
    get shardKey(): string;
    set shardKey(value: string);
    resetShardKey(): void;
    get shardKeyInput(): string | undefined;
    private _systemIndexes;
    get systemIndexes(): CosmosdbMongoCollectionSystemIndexesList;
    private _throughput?;
    get throughput(): number;
    set throughput(value: number);
    resetThroughput(): void;
    get throughputInput(): number | undefined;
    private _autoscaleSettings;
    get autoscaleSettings(): CosmosdbMongoCollectionAutoscaleSettingsOutputReference;
    putAutoscaleSettings(value: CosmosdbMongoCollectionAutoscaleSettings): void;
    resetAutoscaleSettings(): void;
    get autoscaleSettingsInput(): CosmosdbMongoCollectionAutoscaleSettings | undefined;
    private _index;
    get index(): CosmosdbMongoCollectionIndexList;
    putIndex(value: CosmosdbMongoCollectionIndex[] | cdktn.IResolvable): void;
    resetIndex(): void;
    get indexInput(): cdktn.IResolvable | CosmosdbMongoCollectionIndex[] | undefined;
    private _timeouts;
    get timeouts(): CosmosdbMongoCollectionTimeoutsOutputReference;
    putTimeouts(value: CosmosdbMongoCollectionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CosmosdbMongoCollectionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
