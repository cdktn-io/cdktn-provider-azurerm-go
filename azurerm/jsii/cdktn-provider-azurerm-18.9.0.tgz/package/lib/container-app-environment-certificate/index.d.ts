/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ContainerAppEnvironmentCertificateConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#certificate_blob_base64 ContainerAppEnvironmentCertificate#certificate_blob_base64}
    */
    readonly certificateBlobBase64?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#certificate_password ContainerAppEnvironmentCertificate#certificate_password}
    */
    readonly certificatePassword?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#container_app_environment_id ContainerAppEnvironmentCertificate#container_app_environment_id}
    */
    readonly containerAppEnvironmentId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#id ContainerAppEnvironmentCertificate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#name ContainerAppEnvironmentCertificate#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#tags ContainerAppEnvironmentCertificate#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * certificate_key_vault block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#certificate_key_vault ContainerAppEnvironmentCertificate#certificate_key_vault}
    */
    readonly certificateKeyVault?: ContainerAppEnvironmentCertificateCertificateKeyVault;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#timeouts ContainerAppEnvironmentCertificate#timeouts}
    */
    readonly timeouts?: ContainerAppEnvironmentCertificateTimeouts;
}
export interface ContainerAppEnvironmentCertificateCertificateKeyVault {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#identity ContainerAppEnvironmentCertificate#identity}
    */
    readonly identity?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#key_vault_secret_id ContainerAppEnvironmentCertificate#key_vault_secret_id}
    */
    readonly keyVaultSecretId: string;
}
export declare function containerAppEnvironmentCertificateCertificateKeyVaultToTerraform(struct?: ContainerAppEnvironmentCertificateCertificateKeyVaultOutputReference | ContainerAppEnvironmentCertificateCertificateKeyVault): any;
export declare function containerAppEnvironmentCertificateCertificateKeyVaultToHclTerraform(struct?: ContainerAppEnvironmentCertificateCertificateKeyVaultOutputReference | ContainerAppEnvironmentCertificateCertificateKeyVault): any;
export declare class ContainerAppEnvironmentCertificateCertificateKeyVaultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerAppEnvironmentCertificateCertificateKeyVault | undefined;
    set internalValue(value: ContainerAppEnvironmentCertificateCertificateKeyVault | undefined);
    private _identity?;
    get identity(): string;
    set identity(value: string);
    resetIdentity(): void;
    get identityInput(): string | undefined;
    private _keyVaultSecretId?;
    get keyVaultSecretId(): string;
    set keyVaultSecretId(value: string);
    get keyVaultSecretIdInput(): string | undefined;
}
export interface ContainerAppEnvironmentCertificateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#create ContainerAppEnvironmentCertificate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#delete ContainerAppEnvironmentCertificate#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#read ContainerAppEnvironmentCertificate#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#update ContainerAppEnvironmentCertificate#update}
    */
    readonly update?: string;
}
export declare function containerAppEnvironmentCertificateTimeoutsToTerraform(struct?: ContainerAppEnvironmentCertificateTimeouts | cdktn.IResolvable): any;
export declare function containerAppEnvironmentCertificateTimeoutsToHclTerraform(struct?: ContainerAppEnvironmentCertificateTimeouts | cdktn.IResolvable): any;
export declare class ContainerAppEnvironmentCertificateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ContainerAppEnvironmentCertificateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ContainerAppEnvironmentCertificateTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate azurerm_container_app_environment_certificate}
*/
export declare class ContainerAppEnvironmentCertificate extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_container_app_environment_certificate";
    /**
    * Generates CDKTN code for importing a ContainerAppEnvironmentCertificate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ContainerAppEnvironmentCertificate to import
    * @param importFromId The id of the existing ContainerAppEnvironmentCertificate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ContainerAppEnvironmentCertificate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/container_app_environment_certificate azurerm_container_app_environment_certificate} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ContainerAppEnvironmentCertificateConfig
    */
    constructor(scope: Construct, id: string, config: ContainerAppEnvironmentCertificateConfig);
    private _certificateBlobBase64?;
    get certificateBlobBase64(): string;
    set certificateBlobBase64(value: string);
    resetCertificateBlobBase64(): void;
    get certificateBlobBase64Input(): string | undefined;
    private _certificatePassword?;
    get certificatePassword(): string;
    set certificatePassword(value: string);
    resetCertificatePassword(): void;
    get certificatePasswordInput(): string | undefined;
    private _containerAppEnvironmentId?;
    get containerAppEnvironmentId(): string;
    set containerAppEnvironmentId(value: string);
    get containerAppEnvironmentIdInput(): string | undefined;
    get expirationDate(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get issueDate(): string;
    get issuer(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get subjectName(): string;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    get thumbprint(): string;
    private _certificateKeyVault;
    get certificateKeyVault(): ContainerAppEnvironmentCertificateCertificateKeyVaultOutputReference;
    putCertificateKeyVault(value: ContainerAppEnvironmentCertificateCertificateKeyVault): void;
    resetCertificateKeyVault(): void;
    get certificateKeyVaultInput(): ContainerAppEnvironmentCertificateCertificateKeyVault | undefined;
    private _timeouts;
    get timeouts(): ContainerAppEnvironmentCertificateTimeoutsOutputReference;
    putTimeouts(value: ContainerAppEnvironmentCertificateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ContainerAppEnvironmentCertificateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
