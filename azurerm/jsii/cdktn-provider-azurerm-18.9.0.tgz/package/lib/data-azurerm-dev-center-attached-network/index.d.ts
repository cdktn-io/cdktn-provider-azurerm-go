/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermDevCenterAttachedNetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/dev_center_attached_network#dev_center_id DataAzurermDevCenterAttachedNetwork#dev_center_id}
    */
    readonly devCenterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/dev_center_attached_network#id DataAzurermDevCenterAttachedNetwork#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/dev_center_attached_network#name DataAzurermDevCenterAttachedNetwork#name}
    */
    readonly name: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/dev_center_attached_network#timeouts DataAzurermDevCenterAttachedNetwork#timeouts}
    */
    readonly timeouts?: DataAzurermDevCenterAttachedNetworkTimeouts;
}
export interface DataAzurermDevCenterAttachedNetworkTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/dev_center_attached_network#read DataAzurermDevCenterAttachedNetwork#read}
    */
    readonly read?: string;
}
export declare function dataAzurermDevCenterAttachedNetworkTimeoutsToTerraform(struct?: DataAzurermDevCenterAttachedNetworkTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermDevCenterAttachedNetworkTimeoutsToHclTerraform(struct?: DataAzurermDevCenterAttachedNetworkTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermDevCenterAttachedNetworkTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermDevCenterAttachedNetworkTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermDevCenterAttachedNetworkTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/dev_center_attached_network azurerm_dev_center_attached_network}
*/
export declare class DataAzurermDevCenterAttachedNetwork extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_dev_center_attached_network";
    /**
    * Generates CDKTN code for importing a DataAzurermDevCenterAttachedNetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermDevCenterAttachedNetwork to import
    * @param importFromId The id of the existing DataAzurermDevCenterAttachedNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/dev_center_attached_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermDevCenterAttachedNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/dev_center_attached_network azurerm_dev_center_attached_network} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermDevCenterAttachedNetworkConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermDevCenterAttachedNetworkConfig);
    private _devCenterId?;
    get devCenterId(): string;
    set devCenterId(value: string);
    get devCenterIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get networkConnectionId(): string;
    private _timeouts;
    get timeouts(): DataAzurermDevCenterAttachedNetworkTimeoutsOutputReference;
    putTimeouts(value: DataAzurermDevCenterAttachedNetworkTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermDevCenterAttachedNetworkTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
