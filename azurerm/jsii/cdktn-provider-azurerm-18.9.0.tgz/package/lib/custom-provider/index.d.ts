/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomProviderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#id CustomProvider#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#location CustomProvider#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#name CustomProvider#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#resource_group_name CustomProvider#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#tags CustomProvider#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * action block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#action CustomProvider#action}
    */
    readonly action?: CustomProviderAction[] | cdktn.IResolvable;
    /**
    * resource_type block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#resource_type CustomProvider#resource_type}
    */
    readonly resourceType?: CustomProviderResourceType[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#timeouts CustomProvider#timeouts}
    */
    readonly timeouts?: CustomProviderTimeouts;
    /**
    * validation block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#validation CustomProvider#validation}
    */
    readonly validation?: CustomProviderValidation[] | cdktn.IResolvable;
}
export interface CustomProviderAction {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#endpoint CustomProvider#endpoint}
    */
    readonly endpoint: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#name CustomProvider#name}
    */
    readonly name: string;
}
export declare function customProviderActionToTerraform(struct?: CustomProviderAction | cdktn.IResolvable): any;
export declare function customProviderActionToHclTerraform(struct?: CustomProviderAction | cdktn.IResolvable): any;
export declare class CustomProviderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomProviderAction | cdktn.IResolvable | undefined;
    set internalValue(value: CustomProviderAction | cdktn.IResolvable | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
}
export declare class CustomProviderActionList extends cdktn.ComplexList {
    internalValue?: CustomProviderAction[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomProviderActionOutputReference;
}
export interface CustomProviderResourceType {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#endpoint CustomProvider#endpoint}
    */
    readonly endpoint: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#name CustomProvider#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#routing_type CustomProvider#routing_type}
    */
    readonly routingType?: string;
}
export declare function customProviderResourceTypeToTerraform(struct?: CustomProviderResourceType | cdktn.IResolvable): any;
export declare function customProviderResourceTypeToHclTerraform(struct?: CustomProviderResourceType | cdktn.IResolvable): any;
export declare class CustomProviderResourceTypeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomProviderResourceType | cdktn.IResolvable | undefined;
    set internalValue(value: CustomProviderResourceType | cdktn.IResolvable | undefined);
    private _endpoint?;
    get endpoint(): string;
    set endpoint(value: string);
    get endpointInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _routingType?;
    get routingType(): string;
    set routingType(value: string);
    resetRoutingType(): void;
    get routingTypeInput(): string | undefined;
}
export declare class CustomProviderResourceTypeList extends cdktn.ComplexList {
    internalValue?: CustomProviderResourceType[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomProviderResourceTypeOutputReference;
}
export interface CustomProviderTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#create CustomProvider#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#delete CustomProvider#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#read CustomProvider#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#update CustomProvider#update}
    */
    readonly update?: string;
}
export declare function customProviderTimeoutsToTerraform(struct?: CustomProviderTimeouts | cdktn.IResolvable): any;
export declare function customProviderTimeoutsToHclTerraform(struct?: CustomProviderTimeouts | cdktn.IResolvable): any;
export declare class CustomProviderTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomProviderTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CustomProviderTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
export interface CustomProviderValidation {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#specification CustomProvider#specification}
    */
    readonly specification: string;
}
export declare function customProviderValidationToTerraform(struct?: CustomProviderValidation | cdktn.IResolvable): any;
export declare function customProviderValidationToHclTerraform(struct?: CustomProviderValidation | cdktn.IResolvable): any;
export declare class CustomProviderValidationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomProviderValidation | cdktn.IResolvable | undefined;
    set internalValue(value: CustomProviderValidation | cdktn.IResolvable | undefined);
    private _specification?;
    get specification(): string;
    set specification(value: string);
    get specificationInput(): string | undefined;
}
export declare class CustomProviderValidationList extends cdktn.ComplexList {
    internalValue?: CustomProviderValidation[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomProviderValidationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider azurerm_custom_provider}
*/
export declare class CustomProvider extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_custom_provider";
    /**
    * Generates CDKTN code for importing a CustomProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomProvider to import
    * @param importFromId The id of the existing CustomProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/custom_provider azurerm_custom_provider} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomProviderConfig
    */
    constructor(scope: Construct, id: string, config: CustomProviderConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _action;
    get action(): CustomProviderActionList;
    putAction(value: CustomProviderAction[] | cdktn.IResolvable): void;
    resetAction(): void;
    get actionInput(): cdktn.IResolvable | CustomProviderAction[] | undefined;
    private _resourceType;
    get resourceType(): CustomProviderResourceTypeList;
    putResourceType(value: CustomProviderResourceType[] | cdktn.IResolvable): void;
    resetResourceType(): void;
    get resourceTypeInput(): cdktn.IResolvable | CustomProviderResourceType[] | undefined;
    private _timeouts;
    get timeouts(): CustomProviderTimeoutsOutputReference;
    putTimeouts(value: CustomProviderTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CustomProviderTimeouts | undefined;
    private _validation;
    get validation(): CustomProviderValidationList;
    putValidation(value: CustomProviderValidation[] | cdktn.IResolvable): void;
    resetValidation(): void;
    get validationInput(): cdktn.IResolvable | CustomProviderValidation[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
