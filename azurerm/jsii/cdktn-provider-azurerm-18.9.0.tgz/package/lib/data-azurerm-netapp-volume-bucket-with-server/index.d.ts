/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermNetappVolumeBucketWithServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume_bucket_with_server#id DataAzurermNetappVolumeBucketWithServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume_bucket_with_server#name DataAzurermNetappVolumeBucketWithServer#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume_bucket_with_server#netapp_volume_id DataAzurermNetappVolumeBucketWithServer#netapp_volume_id}
    */
    readonly netappVolumeId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume_bucket_with_server#timeouts DataAzurermNetappVolumeBucketWithServer#timeouts}
    */
    readonly timeouts?: DataAzurermNetappVolumeBucketWithServerTimeouts;
}
export interface DataAzurermNetappVolumeBucketWithServerFileSystemNfsUser {
}
export declare function dataAzurermNetappVolumeBucketWithServerFileSystemNfsUserToTerraform(struct?: DataAzurermNetappVolumeBucketWithServerFileSystemNfsUser): any;
export declare function dataAzurermNetappVolumeBucketWithServerFileSystemNfsUserToHclTerraform(struct?: DataAzurermNetappVolumeBucketWithServerFileSystemNfsUser): any;
export declare class DataAzurermNetappVolumeBucketWithServerFileSystemNfsUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermNetappVolumeBucketWithServerFileSystemNfsUser | undefined;
    set internalValue(value: DataAzurermNetappVolumeBucketWithServerFileSystemNfsUser | undefined);
    get groupId(): number;
    get userId(): number;
}
export declare class DataAzurermNetappVolumeBucketWithServerFileSystemNfsUserList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermNetappVolumeBucketWithServerFileSystemNfsUserOutputReference;
}
export interface DataAzurermNetappVolumeBucketWithServerKeyVault {
}
export declare function dataAzurermNetappVolumeBucketWithServerKeyVaultToTerraform(struct?: DataAzurermNetappVolumeBucketWithServerKeyVault): any;
export declare function dataAzurermNetappVolumeBucketWithServerKeyVaultToHclTerraform(struct?: DataAzurermNetappVolumeBucketWithServerKeyVault): any;
export declare class DataAzurermNetappVolumeBucketWithServerKeyVaultOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermNetappVolumeBucketWithServerKeyVault | undefined;
    set internalValue(value: DataAzurermNetappVolumeBucketWithServerKeyVault | undefined);
    get certificateKeyVaultUri(): string;
    get certificateName(): string;
    get credentialsKeyVaultUri(): string;
    get credentialsSecretName(): string;
}
export declare class DataAzurermNetappVolumeBucketWithServerKeyVaultList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermNetappVolumeBucketWithServerKeyVaultOutputReference;
}
export interface DataAzurermNetappVolumeBucketWithServerServer {
}
export declare function dataAzurermNetappVolumeBucketWithServerServerToTerraform(struct?: DataAzurermNetappVolumeBucketWithServerServer): any;
export declare function dataAzurermNetappVolumeBucketWithServerServerToHclTerraform(struct?: DataAzurermNetappVolumeBucketWithServerServer): any;
export declare class DataAzurermNetappVolumeBucketWithServerServerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermNetappVolumeBucketWithServerServer | undefined;
    set internalValue(value: DataAzurermNetappVolumeBucketWithServerServer | undefined);
    get certificatePem(): string;
    get fqdn(): string;
    get onCertificateConflictAction(): string;
}
export declare class DataAzurermNetappVolumeBucketWithServerServerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermNetappVolumeBucketWithServerServerOutputReference;
}
export interface DataAzurermNetappVolumeBucketWithServerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume_bucket_with_server#read DataAzurermNetappVolumeBucketWithServer#read}
    */
    readonly read?: string;
}
export declare function dataAzurermNetappVolumeBucketWithServerTimeoutsToTerraform(struct?: DataAzurermNetappVolumeBucketWithServerTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermNetappVolumeBucketWithServerTimeoutsToHclTerraform(struct?: DataAzurermNetappVolumeBucketWithServerTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermNetappVolumeBucketWithServerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermNetappVolumeBucketWithServerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermNetappVolumeBucketWithServerTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume_bucket_with_server azurerm_netapp_volume_bucket_with_server}
*/
export declare class DataAzurermNetappVolumeBucketWithServer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_netapp_volume_bucket_with_server";
    /**
    * Generates CDKTN code for importing a DataAzurermNetappVolumeBucketWithServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermNetappVolumeBucketWithServer to import
    * @param importFromId The id of the existing DataAzurermNetappVolumeBucketWithServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume_bucket_with_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermNetappVolumeBucketWithServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/netapp_volume_bucket_with_server azurerm_netapp_volume_bucket_with_server} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermNetappVolumeBucketWithServerConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermNetappVolumeBucketWithServerConfig);
    get fileSystemCifsUsername(): string;
    private _fileSystemNfsUser;
    get fileSystemNfsUser(): DataAzurermNetappVolumeBucketWithServerFileSystemNfsUserList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyVault;
    get keyVault(): DataAzurermNetappVolumeBucketWithServerKeyVaultList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _netappVolumeId?;
    get netappVolumeId(): string;
    set netappVolumeId(value: string);
    get netappVolumeIdInput(): string | undefined;
    get path(): string;
    get permissions(): string;
    private _server;
    get server(): DataAzurermNetappVolumeBucketWithServerServerList;
    get serverCertificateCommonName(): string;
    get serverCertificateExpiryDate(): string;
    get serverIpAddress(): string;
    get status(): string;
    private _timeouts;
    get timeouts(): DataAzurermNetappVolumeBucketWithServerTimeoutsOutputReference;
    putTimeouts(value: DataAzurermNetappVolumeBucketWithServerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermNetappVolumeBucketWithServerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
