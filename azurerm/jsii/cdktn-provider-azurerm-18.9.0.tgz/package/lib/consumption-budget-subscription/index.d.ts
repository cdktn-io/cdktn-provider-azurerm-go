/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConsumptionBudgetSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#amount ConsumptionBudgetSubscription#amount}
    */
    readonly amount: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#etag ConsumptionBudgetSubscription#etag}
    */
    readonly etag?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#id ConsumptionBudgetSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#name ConsumptionBudgetSubscription#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#subscription_id ConsumptionBudgetSubscription#subscription_id}
    */
    readonly subscriptionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#time_grain ConsumptionBudgetSubscription#time_grain}
    */
    readonly timeGrain?: string;
    /**
    * filter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#filter ConsumptionBudgetSubscription#filter}
    */
    readonly filter?: ConsumptionBudgetSubscriptionFilter;
    /**
    * notification block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#notification ConsumptionBudgetSubscription#notification}
    */
    readonly notification: ConsumptionBudgetSubscriptionNotification[] | cdktn.IResolvable;
    /**
    * time_period block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#time_period ConsumptionBudgetSubscription#time_period}
    */
    readonly timePeriod: ConsumptionBudgetSubscriptionTimePeriod;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#timeouts ConsumptionBudgetSubscription#timeouts}
    */
    readonly timeouts?: ConsumptionBudgetSubscriptionTimeouts;
}
export interface ConsumptionBudgetSubscriptionFilterDimension {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#name ConsumptionBudgetSubscription#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#operator ConsumptionBudgetSubscription#operator}
    */
    readonly operator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#values ConsumptionBudgetSubscription#values}
    */
    readonly values: string[];
}
export declare function consumptionBudgetSubscriptionFilterDimensionToTerraform(struct?: ConsumptionBudgetSubscriptionFilterDimension | cdktn.IResolvable): any;
export declare function consumptionBudgetSubscriptionFilterDimensionToHclTerraform(struct?: ConsumptionBudgetSubscriptionFilterDimension | cdktn.IResolvable): any;
export declare class ConsumptionBudgetSubscriptionFilterDimensionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConsumptionBudgetSubscriptionFilterDimension | cdktn.IResolvable | undefined;
    set internalValue(value: ConsumptionBudgetSubscriptionFilterDimension | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class ConsumptionBudgetSubscriptionFilterDimensionList extends cdktn.ComplexList {
    internalValue?: ConsumptionBudgetSubscriptionFilterDimension[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConsumptionBudgetSubscriptionFilterDimensionOutputReference;
}
export interface ConsumptionBudgetSubscriptionFilterTag {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#name ConsumptionBudgetSubscription#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#operator ConsumptionBudgetSubscription#operator}
    */
    readonly operator?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#values ConsumptionBudgetSubscription#values}
    */
    readonly values: string[];
}
export declare function consumptionBudgetSubscriptionFilterTagToTerraform(struct?: ConsumptionBudgetSubscriptionFilterTag | cdktn.IResolvable): any;
export declare function consumptionBudgetSubscriptionFilterTagToHclTerraform(struct?: ConsumptionBudgetSubscriptionFilterTag | cdktn.IResolvable): any;
export declare class ConsumptionBudgetSubscriptionFilterTagOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConsumptionBudgetSubscriptionFilterTag | cdktn.IResolvable | undefined;
    set internalValue(value: ConsumptionBudgetSubscriptionFilterTag | cdktn.IResolvable | undefined);
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    resetOperator(): void;
    get operatorInput(): string | undefined;
    private _values?;
    get values(): string[];
    set values(value: string[]);
    get valuesInput(): string[] | undefined;
}
export declare class ConsumptionBudgetSubscriptionFilterTagList extends cdktn.ComplexList {
    internalValue?: ConsumptionBudgetSubscriptionFilterTag[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConsumptionBudgetSubscriptionFilterTagOutputReference;
}
export interface ConsumptionBudgetSubscriptionFilter {
    /**
    * dimension block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#dimension ConsumptionBudgetSubscription#dimension}
    */
    readonly dimension?: ConsumptionBudgetSubscriptionFilterDimension[] | cdktn.IResolvable;
    /**
    * tag block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#tag ConsumptionBudgetSubscription#tag}
    */
    readonly tag?: ConsumptionBudgetSubscriptionFilterTag[] | cdktn.IResolvable;
}
export declare function consumptionBudgetSubscriptionFilterToTerraform(struct?: ConsumptionBudgetSubscriptionFilterOutputReference | ConsumptionBudgetSubscriptionFilter): any;
export declare function consumptionBudgetSubscriptionFilterToHclTerraform(struct?: ConsumptionBudgetSubscriptionFilterOutputReference | ConsumptionBudgetSubscriptionFilter): any;
export declare class ConsumptionBudgetSubscriptionFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConsumptionBudgetSubscriptionFilter | undefined;
    set internalValue(value: ConsumptionBudgetSubscriptionFilter | undefined);
    private _dimension;
    get dimension(): ConsumptionBudgetSubscriptionFilterDimensionList;
    putDimension(value: ConsumptionBudgetSubscriptionFilterDimension[] | cdktn.IResolvable): void;
    resetDimension(): void;
    get dimensionInput(): cdktn.IResolvable | ConsumptionBudgetSubscriptionFilterDimension[] | undefined;
    private _tag;
    get tag(): ConsumptionBudgetSubscriptionFilterTagList;
    putTag(value: ConsumptionBudgetSubscriptionFilterTag[] | cdktn.IResolvable): void;
    resetTag(): void;
    get tagInput(): cdktn.IResolvable | ConsumptionBudgetSubscriptionFilterTag[] | undefined;
}
export interface ConsumptionBudgetSubscriptionNotification {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#contact_emails ConsumptionBudgetSubscription#contact_emails}
    */
    readonly contactEmails?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#contact_groups ConsumptionBudgetSubscription#contact_groups}
    */
    readonly contactGroups?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#contact_roles ConsumptionBudgetSubscription#contact_roles}
    */
    readonly contactRoles?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#enabled ConsumptionBudgetSubscription#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#operator ConsumptionBudgetSubscription#operator}
    */
    readonly operator: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#threshold ConsumptionBudgetSubscription#threshold}
    */
    readonly threshold: number;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#threshold_type ConsumptionBudgetSubscription#threshold_type}
    */
    readonly thresholdType?: string;
}
export declare function consumptionBudgetSubscriptionNotificationToTerraform(struct?: ConsumptionBudgetSubscriptionNotification | cdktn.IResolvable): any;
export declare function consumptionBudgetSubscriptionNotificationToHclTerraform(struct?: ConsumptionBudgetSubscriptionNotification | cdktn.IResolvable): any;
export declare class ConsumptionBudgetSubscriptionNotificationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConsumptionBudgetSubscriptionNotification | cdktn.IResolvable | undefined;
    set internalValue(value: ConsumptionBudgetSubscriptionNotification | cdktn.IResolvable | undefined);
    private _contactEmails?;
    get contactEmails(): string[];
    set contactEmails(value: string[]);
    resetContactEmails(): void;
    get contactEmailsInput(): string[] | undefined;
    private _contactGroups?;
    get contactGroups(): string[];
    set contactGroups(value: string[]);
    resetContactGroups(): void;
    get contactGroupsInput(): string[] | undefined;
    private _contactRoles?;
    get contactRoles(): string[];
    set contactRoles(value: string[]);
    resetContactRoles(): void;
    get contactRolesInput(): string[] | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _operator?;
    get operator(): string;
    set operator(value: string);
    get operatorInput(): string | undefined;
    private _threshold?;
    get threshold(): number;
    set threshold(value: number);
    get thresholdInput(): number | undefined;
    private _thresholdType?;
    get thresholdType(): string;
    set thresholdType(value: string);
    resetThresholdType(): void;
    get thresholdTypeInput(): string | undefined;
}
export declare class ConsumptionBudgetSubscriptionNotificationList extends cdktn.ComplexList {
    internalValue?: ConsumptionBudgetSubscriptionNotification[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConsumptionBudgetSubscriptionNotificationOutputReference;
}
export interface ConsumptionBudgetSubscriptionTimePeriod {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#end_date ConsumptionBudgetSubscription#end_date}
    */
    readonly endDate?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#start_date ConsumptionBudgetSubscription#start_date}
    */
    readonly startDate: string;
}
export declare function consumptionBudgetSubscriptionTimePeriodToTerraform(struct?: ConsumptionBudgetSubscriptionTimePeriodOutputReference | ConsumptionBudgetSubscriptionTimePeriod): any;
export declare function consumptionBudgetSubscriptionTimePeriodToHclTerraform(struct?: ConsumptionBudgetSubscriptionTimePeriodOutputReference | ConsumptionBudgetSubscriptionTimePeriod): any;
export declare class ConsumptionBudgetSubscriptionTimePeriodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConsumptionBudgetSubscriptionTimePeriod | undefined;
    set internalValue(value: ConsumptionBudgetSubscriptionTimePeriod | undefined);
    private _endDate?;
    get endDate(): string;
    set endDate(value: string);
    resetEndDate(): void;
    get endDateInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    get startDateInput(): string | undefined;
}
export interface ConsumptionBudgetSubscriptionTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#create ConsumptionBudgetSubscription#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#delete ConsumptionBudgetSubscription#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#read ConsumptionBudgetSubscription#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#update ConsumptionBudgetSubscription#update}
    */
    readonly update?: string;
}
export declare function consumptionBudgetSubscriptionTimeoutsToTerraform(struct?: ConsumptionBudgetSubscriptionTimeouts | cdktn.IResolvable): any;
export declare function consumptionBudgetSubscriptionTimeoutsToHclTerraform(struct?: ConsumptionBudgetSubscriptionTimeouts | cdktn.IResolvable): any;
export declare class ConsumptionBudgetSubscriptionTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ConsumptionBudgetSubscriptionTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ConsumptionBudgetSubscriptionTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription azurerm_consumption_budget_subscription}
*/
export declare class ConsumptionBudgetSubscription extends cdktn.TerraformResource {
    static readonly tfResourceType = "azurerm_consumption_budget_subscription";
    /**
    * Generates CDKTN code for importing a ConsumptionBudgetSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ConsumptionBudgetSubscription to import
    * @param importFromId The id of the existing ConsumptionBudgetSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ConsumptionBudgetSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/resources/consumption_budget_subscription azurerm_consumption_budget_subscription} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConsumptionBudgetSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: ConsumptionBudgetSubscriptionConfig);
    private _amount?;
    get amount(): number;
    set amount(value: number);
    get amountInput(): number | undefined;
    private _etag?;
    get etag(): string;
    set etag(value: string);
    resetEtag(): void;
    get etagInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _subscriptionId?;
    get subscriptionId(): string;
    set subscriptionId(value: string);
    get subscriptionIdInput(): string | undefined;
    private _timeGrain?;
    get timeGrain(): string;
    set timeGrain(value: string);
    resetTimeGrain(): void;
    get timeGrainInput(): string | undefined;
    private _filter;
    get filter(): ConsumptionBudgetSubscriptionFilterOutputReference;
    putFilter(value: ConsumptionBudgetSubscriptionFilter): void;
    resetFilter(): void;
    get filterInput(): ConsumptionBudgetSubscriptionFilter | undefined;
    private _notification;
    get notification(): ConsumptionBudgetSubscriptionNotificationList;
    putNotification(value: ConsumptionBudgetSubscriptionNotification[] | cdktn.IResolvable): void;
    get notificationInput(): cdktn.IResolvable | ConsumptionBudgetSubscriptionNotification[] | undefined;
    private _timePeriod;
    get timePeriod(): ConsumptionBudgetSubscriptionTimePeriodOutputReference;
    putTimePeriod(value: ConsumptionBudgetSubscriptionTimePeriod): void;
    get timePeriodInput(): ConsumptionBudgetSubscriptionTimePeriod | undefined;
    private _timeouts;
    get timeouts(): ConsumptionBudgetSubscriptionTimeoutsOutputReference;
    putTimeouts(value: ConsumptionBudgetSubscriptionTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ConsumptionBudgetSubscriptionTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
