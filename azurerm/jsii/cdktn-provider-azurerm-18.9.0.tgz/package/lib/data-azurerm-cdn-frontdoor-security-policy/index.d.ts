/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermCdnFrontdoorSecurityPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cdn_frontdoor_security_policy#id DataAzurermCdnFrontdoorSecurityPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cdn_frontdoor_security_policy#name DataAzurermCdnFrontdoorSecurityPolicy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cdn_frontdoor_security_policy#profile_name DataAzurermCdnFrontdoorSecurityPolicy#profile_name}
    */
    readonly profileName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cdn_frontdoor_security_policy#resource_group_name DataAzurermCdnFrontdoorSecurityPolicy#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cdn_frontdoor_security_policy#timeouts DataAzurermCdnFrontdoorSecurityPolicy#timeouts}
    */
    readonly timeouts?: DataAzurermCdnFrontdoorSecurityPolicyTimeouts;
}
export interface DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomain {
}
export declare function dataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomainToTerraform(struct?: DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomain): any;
export declare function dataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomainToHclTerraform(struct?: DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomain): any;
export declare class DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomainOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomain | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomain | undefined);
    get active(): cdktn.IResolvable;
    get cdnFrontdoorDomainId(): string;
}
export declare class DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomainList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomainOutputReference;
}
export interface DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociation {
}
export declare function dataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationToTerraform(struct?: DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociation): any;
export declare function dataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationToHclTerraform(struct?: DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociation): any;
export declare class DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociation | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociation | undefined);
    private _domain;
    get domain(): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationDomainList;
    get patternsToMatch(): string[];
}
export declare class DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationOutputReference;
}
export interface DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewall {
}
export declare function dataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallToTerraform(struct?: DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewall): any;
export declare function dataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallToHclTerraform(struct?: DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewall): any;
export declare class DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewall | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewall | undefined);
    private _association;
    get association(): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallAssociationList;
    get cdnFrontdoorFirewallPolicyId(): string;
}
export declare class DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallOutputReference;
}
export interface DataAzurermCdnFrontdoorSecurityPolicySecurityPolicies {
}
export declare function dataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesToTerraform(struct?: DataAzurermCdnFrontdoorSecurityPolicySecurityPolicies): any;
export declare function dataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesToHclTerraform(struct?: DataAzurermCdnFrontdoorSecurityPolicySecurityPolicies): any;
export declare class DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCdnFrontdoorSecurityPolicySecurityPolicies | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorSecurityPolicySecurityPolicies | undefined);
    private _firewall;
    get firewall(): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesFirewallList;
}
export declare class DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesOutputReference;
}
export interface DataAzurermCdnFrontdoorSecurityPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cdn_frontdoor_security_policy#read DataAzurermCdnFrontdoorSecurityPolicy#read}
    */
    readonly read?: string;
}
export declare function dataAzurermCdnFrontdoorSecurityPolicyTimeoutsToTerraform(struct?: DataAzurermCdnFrontdoorSecurityPolicyTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermCdnFrontdoorSecurityPolicyTimeoutsToHclTerraform(struct?: DataAzurermCdnFrontdoorSecurityPolicyTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermCdnFrontdoorSecurityPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermCdnFrontdoorSecurityPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermCdnFrontdoorSecurityPolicyTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cdn_frontdoor_security_policy azurerm_cdn_frontdoor_security_policy}
*/
export declare class DataAzurermCdnFrontdoorSecurityPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_cdn_frontdoor_security_policy";
    /**
    * Generates CDKTN code for importing a DataAzurermCdnFrontdoorSecurityPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermCdnFrontdoorSecurityPolicy to import
    * @param importFromId The id of the existing DataAzurermCdnFrontdoorSecurityPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cdn_frontdoor_security_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermCdnFrontdoorSecurityPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cdn_frontdoor_security_policy azurerm_cdn_frontdoor_security_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermCdnFrontdoorSecurityPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermCdnFrontdoorSecurityPolicyConfig);
    get cdnFrontdoorProfileId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _profileName?;
    get profileName(): string;
    set profileName(value: string);
    get profileNameInput(): string | undefined;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    private _securityPolicies;
    get securityPolicies(): DataAzurermCdnFrontdoorSecurityPolicySecurityPoliciesList;
    private _timeouts;
    get timeouts(): DataAzurermCdnFrontdoorSecurityPolicyTimeoutsOutputReference;
    putTimeouts(value: DataAzurermCdnFrontdoorSecurityPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermCdnFrontdoorSecurityPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
