/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzurermCognitiveAccountConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cognitive_account#id DataAzurermCognitiveAccount#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cognitive_account#name DataAzurermCognitiveAccount#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cognitive_account#resource_group_name DataAzurermCognitiveAccount#resource_group_name}
    */
    readonly resourceGroupName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cognitive_account#tags DataAzurermCognitiveAccount#tags}
    */
    readonly tags?: {
        [key: string]: string;
    };
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cognitive_account#timeouts DataAzurermCognitiveAccount#timeouts}
    */
    readonly timeouts?: DataAzurermCognitiveAccountTimeouts;
}
export interface DataAzurermCognitiveAccountCustomerManagedKey {
}
export declare function dataAzurermCognitiveAccountCustomerManagedKeyToTerraform(struct?: DataAzurermCognitiveAccountCustomerManagedKey): any;
export declare function dataAzurermCognitiveAccountCustomerManagedKeyToHclTerraform(struct?: DataAzurermCognitiveAccountCustomerManagedKey): any;
export declare class DataAzurermCognitiveAccountCustomerManagedKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCognitiveAccountCustomerManagedKey | undefined;
    set internalValue(value: DataAzurermCognitiveAccountCustomerManagedKey | undefined);
    get identityClientId(): string;
    get keyVaultKeyId(): string;
}
export declare class DataAzurermCognitiveAccountCustomerManagedKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCognitiveAccountCustomerManagedKeyOutputReference;
}
export interface DataAzurermCognitiveAccountIdentity {
}
export declare function dataAzurermCognitiveAccountIdentityToTerraform(struct?: DataAzurermCognitiveAccountIdentity): any;
export declare function dataAzurermCognitiveAccountIdentityToHclTerraform(struct?: DataAzurermCognitiveAccountIdentity): any;
export declare class DataAzurermCognitiveAccountIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCognitiveAccountIdentity | undefined;
    set internalValue(value: DataAzurermCognitiveAccountIdentity | undefined);
    get identityIds(): string[];
    get principalId(): string;
    get tenantId(): string;
    get type(): string;
}
export declare class DataAzurermCognitiveAccountIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCognitiveAccountIdentityOutputReference;
}
export interface DataAzurermCognitiveAccountNetworkAclsVirtualNetworkRules {
}
export declare function dataAzurermCognitiveAccountNetworkAclsVirtualNetworkRulesToTerraform(struct?: DataAzurermCognitiveAccountNetworkAclsVirtualNetworkRules): any;
export declare function dataAzurermCognitiveAccountNetworkAclsVirtualNetworkRulesToHclTerraform(struct?: DataAzurermCognitiveAccountNetworkAclsVirtualNetworkRules): any;
export declare class DataAzurermCognitiveAccountNetworkAclsVirtualNetworkRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCognitiveAccountNetworkAclsVirtualNetworkRules | undefined;
    set internalValue(value: DataAzurermCognitiveAccountNetworkAclsVirtualNetworkRules | undefined);
    get ignoreMissingVnetServiceEndpoint(): cdktn.IResolvable;
    get subnetId(): string;
}
export declare class DataAzurermCognitiveAccountNetworkAclsVirtualNetworkRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCognitiveAccountNetworkAclsVirtualNetworkRulesOutputReference;
}
export interface DataAzurermCognitiveAccountNetworkAcls {
}
export declare function dataAzurermCognitiveAccountNetworkAclsToTerraform(struct?: DataAzurermCognitiveAccountNetworkAcls): any;
export declare function dataAzurermCognitiveAccountNetworkAclsToHclTerraform(struct?: DataAzurermCognitiveAccountNetworkAcls): any;
export declare class DataAzurermCognitiveAccountNetworkAclsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCognitiveAccountNetworkAcls | undefined;
    set internalValue(value: DataAzurermCognitiveAccountNetworkAcls | undefined);
    get bypass(): string;
    get defaultAction(): string;
    get ipRules(): string[];
    private _virtualNetworkRules;
    get virtualNetworkRules(): DataAzurermCognitiveAccountNetworkAclsVirtualNetworkRulesList;
}
export declare class DataAzurermCognitiveAccountNetworkAclsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCognitiveAccountNetworkAclsOutputReference;
}
export interface DataAzurermCognitiveAccountNetworkInjection {
}
export declare function dataAzurermCognitiveAccountNetworkInjectionToTerraform(struct?: DataAzurermCognitiveAccountNetworkInjection): any;
export declare function dataAzurermCognitiveAccountNetworkInjectionToHclTerraform(struct?: DataAzurermCognitiveAccountNetworkInjection): any;
export declare class DataAzurermCognitiveAccountNetworkInjectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCognitiveAccountNetworkInjection | undefined;
    set internalValue(value: DataAzurermCognitiveAccountNetworkInjection | undefined);
    get scenario(): string;
    get subnetId(): string;
}
export declare class DataAzurermCognitiveAccountNetworkInjectionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCognitiveAccountNetworkInjectionOutputReference;
}
export interface DataAzurermCognitiveAccountStorage {
}
export declare function dataAzurermCognitiveAccountStorageToTerraform(struct?: DataAzurermCognitiveAccountStorage): any;
export declare function dataAzurermCognitiveAccountStorageToHclTerraform(struct?: DataAzurermCognitiveAccountStorage): any;
export declare class DataAzurermCognitiveAccountStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzurermCognitiveAccountStorage | undefined;
    set internalValue(value: DataAzurermCognitiveAccountStorage | undefined);
    get identityClientId(): string;
    get storageAccountId(): string;
}
export declare class DataAzurermCognitiveAccountStorageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzurermCognitiveAccountStorageOutputReference;
}
export interface DataAzurermCognitiveAccountTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cognitive_account#read DataAzurermCognitiveAccount#read}
    */
    readonly read?: string;
}
export declare function dataAzurermCognitiveAccountTimeoutsToTerraform(struct?: DataAzurermCognitiveAccountTimeouts | cdktn.IResolvable): any;
export declare function dataAzurermCognitiveAccountTimeoutsToHclTerraform(struct?: DataAzurermCognitiveAccountTimeouts | cdktn.IResolvable): any;
export declare class DataAzurermCognitiveAccountTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzurermCognitiveAccountTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzurermCognitiveAccountTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cognitive_account azurerm_cognitive_account}
*/
export declare class DataAzurermCognitiveAccount extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azurerm_cognitive_account";
    /**
    * Generates CDKTN code for importing a DataAzurermCognitiveAccount resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzurermCognitiveAccount to import
    * @param importFromId The id of the existing DataAzurermCognitiveAccount that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cognitive_account#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzurermCognitiveAccount to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azurerm/5.10.0/docs/data-sources/cognitive_account azurerm_cognitive_account} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzurermCognitiveAccountConfig
    */
    constructor(scope: Construct, id: string, config: DataAzurermCognitiveAccountConfig);
    get customQuestionAnsweringSearchServiceId(): string;
    get customSubdomainName(): string;
    private _customerManagedKey;
    get customerManagedKey(): DataAzurermCognitiveAccountCustomerManagedKeyList;
    get dynamicThrottlingEnabled(): cdktn.IResolvable;
    get endpoint(): string;
    get fqdns(): string[];
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): DataAzurermCognitiveAccountIdentityList;
    get kind(): string;
    get localAuthEnabled(): cdktn.IResolvable;
    get location(): string;
    get metricsAdvisorAadClientId(): string;
    get metricsAdvisorAadTenantId(): string;
    get metricsAdvisorSuperUserName(): string;
    get metricsAdvisorWebsiteName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkAcls;
    get networkAcls(): DataAzurermCognitiveAccountNetworkAclsList;
    private _networkInjection;
    get networkInjection(): DataAzurermCognitiveAccountNetworkInjectionList;
    get outboundNetworkAccessRestricted(): cdktn.IResolvable;
    get primaryAccessKey(): string;
    get projectManagementEnabled(): cdktn.IResolvable;
    get publicNetworkAccessEnabled(): cdktn.IResolvable;
    get qnaRuntimeEndpoint(): string;
    private _resourceGroupName?;
    get resourceGroupName(): string;
    set resourceGroupName(value: string);
    get resourceGroupNameInput(): string | undefined;
    get secondaryAccessKey(): string;
    get skuName(): string;
    private _storage;
    get storage(): DataAzurermCognitiveAccountStorageList;
    private _tags?;
    get tags(): {
        [key: string]: string;
    };
    set tags(value: {
        [key: string]: string;
    });
    resetTags(): void;
    get tagsInput(): {
        [key: string]: string;
    } | undefined;
    private _timeouts;
    get timeouts(): DataAzurermCognitiveAccountTimeoutsOutputReference;
    putTimeouts(value: DataAzurermCognitiveAccountTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzurermCognitiveAccountTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
